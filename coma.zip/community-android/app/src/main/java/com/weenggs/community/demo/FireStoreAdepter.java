package com.weenggs.community.demo;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.weenggs.community.R;
import com.weenggs.community.widget.DTextView;

import java.util.ArrayList;

import androidx.recyclerview.widget.RecyclerView;

public class FireStoreAdepter extends RecyclerView.Adapter<FireStoreAdepter.ViewHolder> {

    FireStoreActivity deviceListFragment;
    private ArrayList<FierStoreModel> items = new ArrayList<>();

    public FireStoreAdepter(FireStoreActivity context, ArrayList<FierStoreModel> data) {
        this.deviceListFragment = context;
        this.items = data;
    }

    public void addAll(ArrayList<FierStoreModel> data) {
        items.clear();
        items.addAll(data);
        notifyDataSetChanged();
    }

    public void add(FierStoreModel data) {
        items.add(data);
        notifyDataSetChanged();
    }


    @Override
    public FireStoreAdepter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.commitee_member_adepter_row, parent, false);
        return new FireStoreAdepter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(FireStoreAdepter.ViewHolder holder, final int position) {

        final FierStoreModel data = items.get(position);


        holder.txtName.setText(data.getFirstname() + " " + data.getLastname());
        holder.txtMobileno.setText(data.getEmail());
        holder.txtAdd.setText(data.getFathername());

        holder.layoutmain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deviceListFragment.deleteData(data.getKey());
            }
        });

    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public static final class ViewHolder extends RecyclerView.ViewHolder {

        private DTextView txtName, txtMobileno, txtAdd;
        private LinearLayout layoutmain;


        private ViewHolder(View itemView) {
            super(itemView);
            txtName = (DTextView) itemView.findViewById(R.id.txt_name);
            txtMobileno = (DTextView) itemView.findViewById(R.id.txtmobile);
            txtAdd = (DTextView) itemView.findViewById(R.id.txt_add);
            layoutmain = (LinearLayout) itemView.findViewById(R.id.layoutmain);

        }
    }
}
