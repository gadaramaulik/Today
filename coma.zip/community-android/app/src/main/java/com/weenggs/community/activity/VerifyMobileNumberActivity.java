package com.weenggs.community.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.weenggs.community.R;
import com.weenggs.community.model.LoginResponce;
import com.weenggs.community.util.Constant;
import com.weenggs.community.widget.DEditText;
import com.weenggs.community.widget.DTextView;

import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class VerifyMobileNumberActivity extends BaseActivity implements View.OnClickListener {

    private LinearLayout layoutMobileNumber;
    private DEditText txtemail;
    private DTextView btnSendCode;
    private LinearLayout layoutVerification;
    private DEditText txtVerifyCode;
    private DTextView btnVerify;
    private FirebaseAuth mAuth;
    private PhoneAuthProvider.ForceResendingToken mResendToken;
    private PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks;
    private String mVerificationId;
    private String mobileNumber;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.verify_mobile_number_activity);
        mAuth = FirebaseAuth.getInstance();
        findViews();
    }

    private void findViews() {
        layoutMobileNumber = findViewById(R.id.layoutMobileNumber);
        txtemail = findViewById(R.id.txtemail);
        btnSendCode = findViewById(R.id.btn_send_code);
        layoutVerification = findViewById(R.id.layoutVerification);
        txtVerifyCode = findViewById(R.id.txtVerifyCode);
        btnVerify = findViewById(R.id.btn_verify);

        btnSendCode.setOnClickListener(this);
        btnVerify.setOnClickListener(this);

        mCallbacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {

            @Override
            public void onVerificationCompleted(PhoneAuthCredential credential) {

                Log.e(TAG, "onVerificationCompleted:" + credential);
                signInWithPhoneAuthCredential(credential);
            }

            @Override
            public void onVerificationFailed(FirebaseException e) {
                Log.e(TAG, "onVerificationFailed", e);
                showToast(e.getMessage().trim(), true);
                stopprogressdialog();
            }

            @Override
            public void onCodeSent(@NonNull String verificationId, @NonNull PhoneAuthProvider.ForceResendingToken token) {
                Log.e(TAG, "onCodeSent:" + verificationId);
                mVerificationId = verificationId;
                showToast("Code Sent", true);
                layoutMobileNumber.setVisibility(View.GONE);
                layoutVerification.setVisibility(View.VISIBLE);
                stopprogressdialog();
            }
        };

    }

    private void startPhoneNumberVerification(String phoneNumber) {
        PhoneAuthProvider.getInstance().verifyPhoneNumber(
                "+91"+phoneNumber,        // Phone number to verify
                60,                 // Timeout duration
                TimeUnit.SECONDS,   // Unit of timeout
                this,               // Activity (for callback binding)
                mCallbacks);        // OnVerificationStateChangedCallbacks
    }

    private void verifyPhoneNumberWithCode(String verificationId, String code) {
        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(verificationId, code);
        signInWithPhoneAuthCredential(credential);
    }

    private void signInWithPhoneAuthCredential(PhoneAuthCredential credential) {
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                        if (task.isSuccessful()) {
                            showToast("Verification Successfully", true);
                            FirebaseUser user = task.getResult().getUser();
                            checkMobileNumberRegisterOrNot();
                        } else {
                            stopprogressdialog();
                            showToast("Verification Failed", true);
                        }
                    }
                });
    }


    @Override
    public void onStart() {
        super.onStart();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_send_code:
                if (txtemail.getText().toString().trim().equalsIgnoreCase("")) {
                    showToast("Enter Phone Number", true);
                } else {
                    hideSoftKeyboard(VerifyMobileNumberActivity.this);
                    mobileNumber = txtemail.getText().toString().trim();
                       startprogressdialog(this);
                    startPhoneNumberVerification(txtemail.getText().toString().trim());
                }
                break;
            case R.id.btn_verify:
                String code = txtVerifyCode.getText().toString();
                if (TextUtils.isEmpty(code)) {

                    showToast("Code cannot be empty.", true);
                    return;
                }
                hideSoftKeyboard(VerifyMobileNumberActivity.this);
                   startprogressdialog(this);
                verifyPhoneNumberWithCode(mVerificationId, code);
                break;
        }
    }

    public void checkMobileNumberRegisterOrNot() {
        HashMap<String, String> dataParams = new HashMap<>();
        dataParams.put("phone_number", mobileNumber);
        mAPIService.check_phone_no(dataParams).enqueue(new Callback<LoginResponce>() {
            @Override
            public void onResponse(Call<LoginResponce> call, Response<LoginResponce> response) {
                stopprogressdialog();
                if (response.isSuccessful()) {
                    Toast.makeText(VerifyMobileNumberActivity.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    if (response.body().getSuccess().equalsIgnoreCase("1")) {
                        application.setUserLoginData(response.body().getData());
                        Intent intent = new Intent(VerifyMobileNumberActivity.this, HomeActivity.class);
                        startActivity(intent);
                    } else if (response.body().getSuccess().equalsIgnoreCase("2")) {
                        Intent intent = new Intent(VerifyMobileNumberActivity.this, CreatePasswordActivity.class);
                        intent.putExtra(Constant.MOBILE_NO, mobileNumber);
                        startActivity(intent);
                    } else if (response.body().getSuccess().equalsIgnoreCase("3")) {
                        Constant.loginData_registered_member = response.body().getData();
                        Intent intent = new Intent(VerifyMobileNumberActivity.this, CreatePasswordActivity.class);

                        intent.putExtra(Constant.MOBILE_NO, mobileNumber);
                        intent.putExtra(Constant.MEMBER_REGISTERED, true);
                        startActivity(intent);
                    }
                    finish();
                }
            }

            @Override
            public void onFailure(Call<LoginResponce> call, Throwable t) {
                stopprogressdialog();
                Constant.ErrorMessage(VerifyMobileNumberActivity.this, t);
            }
        });

    }


}
