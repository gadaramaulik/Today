package com.weenggs.community.fragment;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.weenggs.community.R;
import com.weenggs.community.activity.AddMarkshetActivity;
import com.weenggs.community.adepter.MarkSheetAdepter;
import com.weenggs.community.model.MarkSheetListData;
import com.weenggs.community.model.MarkSheetListResponce;
import com.weenggs.community.util.Constant;
import com.weenggs.community.widget.DTextView;

import java.util.ArrayList;
import java.util.HashMap;

import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.app.Activity.RESULT_OK;

public class MarkSheetFragment extends BaseFragment implements View.OnClickListener {

    private RecyclerView recycleview;
    LinearLayoutManager mLayoutManager;
    ArrayList<MarkSheetListData> memberDataArrayList;
    MarkSheetAdepter adapter;
    DTextView btnaddnew;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.committee_member_fragment, container, false);

        findViews(view);

        if (Constant.markSheetListDataArrayList == null) {
            getMarksheet();
        } else {
            setMember();
        }

        return view;
    }

    private void findViews(View view) {
        recycleview = (RecyclerView) view.findViewById(R.id.recycleview);
        btnaddnew = view.findViewById(R.id.btnaddnew);
        recycleview.addItemDecoration(new DividerItemDecoration(recycleview.getContext(), DividerItemDecoration.VERTICAL));

        mLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        recycleview.setLayoutManager(mLayoutManager);
        btnaddnew.setVisibility(View.VISIBLE);
        btnaddnew.setOnClickListener(this);
        btnaddnew.setText("Add New Marksheet");
    }

    public void setMember() {
        memberDataArrayList = new ArrayList<>();
        memberDataArrayList.addAll(Constant.markSheetListDataArrayList);
        adapter = new MarkSheetAdepter(MarkSheetFragment.this, memberDataArrayList);
        recycleview.setAdapter(adapter);

    }

    public void editMember(MarkSheetListData data) {
        if (data.getMarksheet_status().equalsIgnoreCase("2")) {
            Constant.markSheetListData = data;
            Intent intent = new Intent(getActivity(), AddMarkshetActivity.class);
            intent.putExtra(Constant.ADDNEW, false);
            ((Activity) context).startActivityForResult(intent, 10);
        } else {
            Toast.makeText(getActivity(), "Uploaded Marksheet not edited", Toast.LENGTH_SHORT).show();
        }

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 10 && resultCode == RESULT_OK) {
            getMarksheet();
        }
    }


    public void getMarksheet() {

        startprogressdialog(getActivity());
        HashMap<String, String> dataParams = new HashMap<>();
        dataParams.put("user_id", data.getMemberInfo().get(0).getUser_id());
        mAPIService.user_wise_marksheet_list(dataParams).enqueue(new Callback<MarkSheetListResponce>() {
            @Override
            public void onResponse(Call<MarkSheetListResponce> call, Response<MarkSheetListResponce> response) {
                stopprogressdialog();
                if (response.isSuccessful()) {
                    //Toast.makeText(getActivity(), response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    if (response.body().getSuccess().equalsIgnoreCase("1")) {
                        Constant.markSheetListDataArrayList = response.body().getData();
                        setMember();
                    }
                }
            }

            @Override
            public void onFailure(Call<MarkSheetListResponce> call, Throwable t) {
                stopprogressdialog();
                Constant.ErrorMessage(getActivity(), t);
            }
        });
    }

    @Override
    public void onClick(View view) {
        if (view == btnaddnew) {
            Intent intent = new Intent(getActivity(), AddMarkshetActivity.class);
            intent.putExtra(Constant.ADDNEW, true);
            ((Activity) context).startActivityForResult(intent, 10);
        }
    }
}
