package com.weenggs.community.fragment;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;

import com.google.gson.Gson;
import com.victor.loading.rotate.RotateLoading;
import com.weenggs.community.Application;
import com.weenggs.community.BuildConfig;
import com.weenggs.community.R;
import com.weenggs.community.model.LoginData;
import com.weenggs.community.retrofit.APIService;
import com.weenggs.community.util.Constant;
import com.weenggs.community.util.Preferences;

import java.io.File;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;



public class BaseFragment extends Fragment {
    public static final int REQUEST_CODE_GALLERY = 0x1;
    public static final String TEMP_PHOTO_FILE_NAME = "temp_photo.jpg";
    public static final int CAMERA_CODE = 3;
    public static final int CALL_PHONE_CODE = 11;
    public static final int READ_EXTERNAL_STORAGE_CODE = 23;
    public static final int WRITE_EXTERNAL_STORAGE_CODE = 24;
    public static File mFileTemp;
    public Preferences pref;
    AlertDialog progressdialog;
    private Toast toast;
    public Gson gson;
    private static final String TAG = "BaseFragment";
    AlertDialog dialog;
    public APIService mAPIService;
    LoginData data;
    Application application;
    Context context;
    public static final int REQ_ALL_PERMISSIONS_GALLARY = 101;
    public static final int REQ_ALL_PERMISSIONS_CAMERA = 102;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        this.context = context;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        toast = Toast.makeText(getActivity(), "", Toast.LENGTH_LONG);
        pref = new Preferences(getActivity());
        gson = new Gson();
        mAPIService = Constant.getAPIService();
        application = (Application) context.getApplicationContext();
        if (application.getUserLoginData() != null) {
            data = application.getUserLoginData();
        }
    }


    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

    }

    public void startprogressdialog(Activity activity) {
        View v = LayoutInflater.from(getActivity()).inflate(R.layout.progress_dialog, null);
        dialog = new AlertDialog.Builder(activity)
                .setView(v)
                .create();
        dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        dialog.setCancelable(false);
        RotateLoading rotateLoading = v.findViewById(R.id.rotateloading);
        rotateLoading.start();
        dialog.show();

    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    public boolean checkAndRequestPermissionsGallary() {
        int read = ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.READ_EXTERNAL_STORAGE);
        int write = ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.WRITE_EXTERNAL_STORAGE);

        List<String> listPermissionsNeeded = new ArrayList<>();

        if (read != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        }
        if (write != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }

        if (!listPermissionsNeeded.isEmpty()) {
            requestPermissions(listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]), REQ_ALL_PERMISSIONS_GALLARY);

            return false;
        }
        return true;
    }


    public void stopprogressdialog() {
        if (dialog != null)
            dialog.hide();
    }
    public String getDeviceType() {
        return "A";
    }

    public String getRefferCode() {
        return "";
    }

    public String bindView(String str) {
        if (str == null) {
            return "";
        }
        return str;
    }

    public String bindView(int Integer) {

        return String.valueOf(Integer);
    }

    public String bindView(float Integer) {

        return String.valueOf(Integer);

    }

    public String bindView(double Integer) {

        return String.valueOf(Integer);
    }


    public void launchMarket(String pakage) {
        Uri uri = Uri.parse("market://details?id=" + pakage);
        Intent myAppLinkToMarket = new Intent(Intent.ACTION_VIEW, uri);
        try {
            startActivity(myAppLinkToMarket);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(getActivity(), " unable to find market app", Toast.LENGTH_LONG).show();
        }
    }

    public void clearData() {

        pref.clear();


    }


    public void hideSoftKeyboard(Activity activity) {
        InputMethodManager inputMethodManager = null;
        try {
            inputMethodManager = (InputMethodManager) activity.getSystemService(getActivity().INPUT_METHOD_SERVICE);
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            if (inputMethodManager != null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    inputMethodManager.hideSoftInputFromWindow(Objects.requireNonNull(activity.getCurrentFocus()).getWindowToken(), 0);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void initState() {
        String state = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(state)) {
            mFileTemp = new File(Environment.getExternalStorageDirectory(), TEMP_PHOTO_FILE_NAME);
        } else {
            mFileTemp = new File(getActivity().getFilesDir(), TEMP_PHOTO_FILE_NAME);
        }
    }

    public boolean checkAndRequestPermissionsCamera() {
        int read = ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.READ_EXTERNAL_STORAGE);
        int write = ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.WRITE_EXTERNAL_STORAGE);
        int camera = ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.CAMERA);

        List<String> listPermissionsNeeded = new ArrayList<>();

        if (read != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        }
        if (write != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
        if (camera != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.CAMERA);
        }

        if (!listPermissionsNeeded.isEmpty()) {
            requestPermissions( listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]), REQ_ALL_PERMISSIONS_CAMERA);

            return false;
        }
        return true;
    }


    public void openGallery() {
        if (!checkPermissionForReadExternalStorage()) {
            requestPermissionForReadExternalStorage();
        } else {
            final String[] ACCEPT_MIME_TYPES = {
                    "image/*"
            };
            Intent photoPickerIntent = new Intent();
            photoPickerIntent.setAction(Intent.ACTION_GET_CONTENT);
            photoPickerIntent.addCategory(Intent.CATEGORY_OPENABLE);
            photoPickerIntent.setType("*/*");//image/*|application/pdf
            photoPickerIntent.putExtra(Intent.EXTRA_MIME_TYPES, ACCEPT_MIME_TYPES);
            startActivityForResult(photoPickerIntent, REQUEST_CODE_GALLERY);
        }
    }


    public String getAndroidID() {
        String m_androidId = Settings.Secure.getString(getActivity().getContentResolver(), Settings.Secure.ANDROID_ID);
        return m_androidId;
    }

    public String getAppVersion() {
        int versionCode = BuildConfig.VERSION_CODE;
        String versionName = BuildConfig.VERSION_NAME;
        return versionName;
    }

    public String getDirKey(String id) {
        String[] parts = id.split("-");
        String first = parts[1];
        String second = parts[4];
        return first + second;
    }

    public String getDirectory(final String s) {
        final String MD5 = "MD5";
        try {
            MessageDigest digest = MessageDigest.getInstance(MD5);
            digest.update(s.getBytes());
            byte messageDigest[] = digest.digest();

            StringBuilder hexString = new StringBuilder();
            for (byte aMessageDigest : messageDigest) {
                String h = Integer.toHexString(0xFF & aMessageDigest);
                while (h.length() < 2)
                    h = "0" + h;
                hexString.append(h);
            }
            return hexString.toString();

        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return "";
    }

    public void hideKeyboard() {
        try {
            InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(getActivity().getCurrentFocus().getWindowToken(), 0);
        } catch (Exception e) {
        }
    }

    public void showToast(final int text, final boolean isShort) {
        getActivity().runOnUiThread(new Runnable() {

            @Override
            public void run() {
                toast.setText(getString(text).toString());
                toast.setDuration(isShort ? Toast.LENGTH_SHORT : Toast.LENGTH_LONG);
                toast.show();
            }
        });
    }

    public void showToast(final String text, final boolean isShort) {
        getActivity().runOnUiThread(new Runnable() {

            @Override
            public void run() {
                toast.setText(text);
                toast.setDuration(isShort ? Toast.LENGTH_SHORT : Toast.LENGTH_LONG);
                toast.show();
            }
        });
    }

    public void showDialog() {
        View v = LayoutInflater.from(getActivity()).inflate(R.layout.progress_dialog, null);
        progressdialog = new AlertDialog.Builder(getActivity())
                .setView(v)
                .create();
        progressdialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        RotateLoading rotateLoading = v.findViewById(R.id.rotateloading);
        rotateLoading.start();
        progressdialog.setCancelable(false);
        progressdialog.show();
    }

    public void dismissDialog() {
        progressdialog.dismiss();
    }

    public void showNoInternetDialog() {
        AlertDialog dialog = new AlertDialog.Builder(getActivity())
                .setMessage(getString(R.string.title_no_internet))
                .setCancelable(false)
                .setPositiveButton(getString(R.string.hint_ok), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
//                        getActivity().finish();
                    }
                }).create();
        dialog.show();
    }


    public boolean isCallPhoneAllowed() {
        //Getting the permission status
        int result = ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.CALL_PHONE);

        //If permission is granted returning true
        if (result == PackageManager.PERMISSION_GRANTED)
            return true;

        //If permission is not granted returning false
        return false;
    }


    public boolean checkPermissionForCamera() {
        int result = ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.CAMERA);
        if (result == PackageManager.PERMISSION_GRANTED) {
            return true;
        } else {
            return false;
        }
    }
    public boolean checkPermissionForReadExternalStorage() {
        int result = ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.READ_EXTERNAL_STORAGE);
        if (result == PackageManager.PERMISSION_GRANTED) {
            return true;
        } else {
            return false;
        }
    }

    //
    public boolean checkPermissionForWriteExternalStorage() {
        int result = ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.WRITE_EXTERNAL_STORAGE);
        if (result == PackageManager.PERMISSION_GRANTED) {
            return true;
        } else {
            return false;
        }
    }

    public void requestPermissionForCamera() {
        if (shouldShowRequestPermissionRationale(Manifest.permission.CAMERA)) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_CODE);
        } else {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_CODE);
        }
    }

    public void requestPermissionForCallPhone() {
        if (shouldShowRequestPermissionRationale(Manifest.permission.CALL_PHONE)) {
            requestPermissions(new String[]{Manifest.permission.CALL_PHONE}, CALL_PHONE_CODE);
        } else {
            requestPermissions(new String[]{Manifest.permission.CALL_PHONE}, CALL_PHONE_CODE);
        }
    }

    public void requestPermissionForWriteExternalStorage() {
        if (shouldShowRequestPermissionRationale(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, WRITE_EXTERNAL_STORAGE_CODE);
        } else {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, WRITE_EXTERNAL_STORAGE_CODE);
        }
    }

    //
    public void requestPermissionForReadExternalStorage() {
        if (shouldShowRequestPermissionRationale(Manifest.permission.READ_EXTERNAL_STORAGE)) {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, READ_EXTERNAL_STORAGE_CODE);
        } else {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, READ_EXTERNAL_STORAGE_CODE);
        }
    }


}
