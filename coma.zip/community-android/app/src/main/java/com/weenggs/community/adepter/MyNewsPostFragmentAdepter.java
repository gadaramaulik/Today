package com.weenggs.community.adepter;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;

import com.borjabravo.readmoretextview.ReadMoreTextView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.Target;
import com.github.vivchar.viewpagerindicator.ViewPagerIndicator;
import com.mikhaellopez.circularimageview.CircularImageView;
import com.weenggs.community.Application;
import com.weenggs.community.R;
import com.weenggs.community.fragment.MyNewsPostFragment;
import com.weenggs.community.model.LoginData;
import com.weenggs.community.model.MediaData;
import com.weenggs.community.model.PostData;
import com.weenggs.community.util.Constant;
import com.weenggs.community.widget.DTextView;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

public class MyNewsPostFragmentAdepter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static int TYPE_VIDEO = 1;
    private static int TYPE_IMAGE = 2;
    private Context context;
    private ArrayList<PostData> postDataArrayList;
    MyPagerAdapter myPagerAdapter;
    MyNewsPostFragment mainFragment;
    Application application;
    LoginData data;

    public MyNewsPostFragmentAdepter(MyNewsPostFragment mainFragment, ArrayList<PostData> employees, Context context) {
        this.context = context;
        this.mainFragment = mainFragment;
        this.postDataArrayList = employees;
        application = (Application) context.getApplicationContext();
        if (application.getUserLoginData() != null) {
            data = application.getUserLoginData();
        }
    }


    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View view;
        if (viewType == TYPE_IMAGE) { // for video layout
            view = LayoutInflater.from(context).inflate(R.layout.item_image, viewGroup, false);
            return new ImageViewHolder(view);

        } else {
            view = LayoutInflater.from(context).inflate(R.layout.item_video, viewGroup, false);
            return new VideoViewHolder(view);
        }
    }

    @Override
    public int getItemViewType(int position) {
        if (postDataArrayList.get(position).getMedia_type().equalsIgnoreCase("video")) {
            return TYPE_VIDEO;
        } else {
            return TYPE_IMAGE;
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int position) {
        if (getItemViewType(position) == TYPE_IMAGE) {
            ((ImageViewHolder) viewHolder).setImageDetails(postDataArrayList.get(position));
        } else {
            ((VideoViewHolder) viewHolder).setVideoDetails(postDataArrayList.get(position));
        }
    }

    @Override
    public int getItemCount() {
        return postDataArrayList.size();
    }

    class ImageViewHolder extends RecyclerView.ViewHolder {

        private LinearLayout displayNameLayout;
        private CircularImageView profilePhoto;
        private DTextView userName, txt_status, txt_title;
        private RelativeLayout mediaViews;
        private ImageView mediaPost;
        ViewPagerIndicator viewPagerIndicator;
        ReadMoreTextView readMoreTextView;
        ViewPager pager;

        ImageViewHolder(@NonNull View itemView) {
            super(itemView);
            displayNameLayout = (LinearLayout) itemView.findViewById(R.id.display_name_layout);
            profilePhoto = (CircularImageView) itemView.findViewById(R.id.profile_photo);
            userName = (DTextView) itemView.findViewById(R.id.user_name);
            txt_status = (DTextView) itemView.findViewById(R.id.txt_status);
            mediaViews = (RelativeLayout) itemView.findViewById(R.id.media_views);
            mediaPost = (ImageView) itemView.findViewById(R.id.media_post);
            readMoreTextView = (ReadMoreTextView) itemView.findViewById(R.id.txt_desribtion);
            txt_title = itemView.findViewById(R.id.txt_title);
            pager = itemView.findViewById(R.id.pager);
            viewPagerIndicator = itemView.findViewById(R.id.view_pager_indicator);
        }

        void setImageDetails(final PostData employee) {
            userName.setText(employee.getFullName());

            Glide.with(context).load(Constant.BASE_IMAGE_URL + employee.getProfile_image()).into(profilePhoto);

            if (employee.getMediaImage() != null) {
                myPagerAdapter = new MyPagerAdapter(employee.getMediaImage(), mainFragment, employee);
                pager.setAdapter(myPagerAdapter);
                pager.setCurrentItem(0);
                viewPagerIndicator.setupWithViewPager(pager);


                @NonNull final ViewPager.OnPageChangeListener mOnPageChangeListener = new ViewPager.OnPageChangeListener() {
                    @Override
                    public void onPageScrolled(final int position, final float positionOffset, final int positionOffsetPixels) {

                    }

                    @Override
                    public void onPageSelected(final int position) {
                    }

                    @Override
                    public void onPageScrollStateChanged(final int state) {

                    }
                };
                viewPagerIndicator.addOnPageChangeListener(mOnPageChangeListener);
            }

            readMoreTextView.setText(employee.getDescription());
            txt_title.setText(employee.getTitle());


            if (!employee.getIs_approved().equalsIgnoreCase("1")) {
                txt_status.setVisibility(View.VISIBLE);
                txt_status.setText("Pending");
                txt_status.setTextColor(context.getResources().getColor(R.color.red));
            } else if (employee.getPosted_by().equalsIgnoreCase(data.getMemberInfo().get(0).getMembers_id())) {
                txt_status.setVisibility(View.VISIBLE);
                txt_status.setText("MY POST");
                txt_status.setTextColor(context.getResources().getColor(R.color.bg_green));
            } else {
                txt_status.setVisibility(View.GONE);
                txt_status.setText("");
            }
        }
    }

    private class MyPagerAdapter extends PagerAdapter {
        ArrayList<MediaData> mdata;
        MyNewsPostFragment context1;
        PostData data;

        @SuppressWarnings("unused")
        public MyPagerAdapter(ArrayList<MediaData> mdat, MyNewsPostFragment context, PostData postData) {
            // TODO Auto-generated constructor stub
            mdata = mdat;
            context1 = context;
            data = postData;

        }


        @Override
        public int getCount() {
            return mdata.size();
        }

        @Override
        public boolean isViewFromObject(View view, Object object) {
            return view == object;
        }

        @Override
        public Object instantiateItem(ViewGroup container1, int position) {

            final ViewHolderNotification holder = new ViewHolderNotification();

            View container;

            container = context1.getLayoutInflater().inflate(R.layout.detail, null);
            holder.mediaPost = (ImageView) container.findViewById(R.id.media_post);
            holder.progressBar = (ProgressBar) container.findViewById(R.id.progressBar);
            container.setTag(R.layout.detail, holder);
            holder.mediaPost.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    mainFragment.viewFulldetail(data);
                }
            });
            container.setTag(position);

            final MediaData employee = mdata.get(position);

            if (employee.getMedia() != null) {
                if (holder.progressBar != null)
                    holder.progressBar.setVisibility(View.VISIBLE);
                Glide.with(context)
                        .load(Constant.BASE_IMAGE_URL + employee.getMedia())
                        .transition(DrawableTransitionOptions.withCrossFade())
                        .apply(new RequestOptions()
                                .placeholder(R.color.streat_line))
                        .listener(new RequestListener<Drawable>() {
                            @Override
                            public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                                if (holder.progressBar != null)
                                    holder.progressBar.setVisibility(View.GONE);
                                return false;
                            }

                            @Override
                            public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                                if (holder.progressBar != null)
                                    holder.progressBar.setVisibility(View.GONE);
                                return false;
                            }
                        }).into(holder.mediaPost);
            }


            container1.addView(container);

            return container;
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            container.removeView((RelativeLayout) object);
        }

        class ViewHolderNotification {

            private ImageView mediaPost;
            private ProgressBar progressBar;

        }

    }


    class VideoViewHolder extends RecyclerView.ViewHolder {

        private LinearLayout displayNameLayout;
        private CircularImageView profilePhoto;
        private DTextView userName, txt_status, txt_title;
        private RelativeLayout mediaViews;
        private ImageView mediaPost;
        private ProgressBar progressBar;
        private ImageView videoIndicater;
        ReadMoreTextView readMoreTextView;

        VideoViewHolder(@NonNull View itemView) {
            super(itemView);
            displayNameLayout = (LinearLayout) itemView.findViewById(R.id.display_name_layout);
            profilePhoto = (CircularImageView) itemView.findViewById(R.id.profile_photo);
            userName = (DTextView) itemView.findViewById(R.id.user_name);
            txt_status = (DTextView) itemView.findViewById(R.id.txt_status);
            mediaViews = (RelativeLayout) itemView.findViewById(R.id.media_views);
            mediaPost = (ImageView) itemView.findViewById(R.id.media_post);
            progressBar = (ProgressBar) itemView.findViewById(R.id.progressBar);
            videoIndicater = (ImageView) itemView.findViewById(R.id.video_indicater);
            readMoreTextView = (ReadMoreTextView) itemView.findViewById(R.id.txt_desribtion);
            txt_title = itemView.findViewById(R.id.txt_title);
        }

        void setVideoDetails(final PostData employee) {
            userName.setText(employee.getFullName());
            Glide.with(context).load(Constant.BASE_IMAGE_URL + employee.getProfile_image()).into(profilePhoto);

            readMoreTextView.setText(employee.getDescription());
            txt_title.setText(employee.getTitle());

            if (employee.getVideo_thumb() != null && !employee.getVideo_thumb().equalsIgnoreCase("")) {
                if (progressBar != null)
                    progressBar.setVisibility(View.VISIBLE);
                Glide.with(context)
                        .load(Constant.BASE_IMAGE_URL + employee.getVideo_thumb())
                        .transition(DrawableTransitionOptions.withCrossFade())
                        .centerCrop()
                        .apply(new RequestOptions()
                                .placeholder(R.color.streat_line))
                        .listener(new RequestListener<Drawable>() {
                            @Override
                            public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                                if (progressBar != null)
                                    progressBar.setVisibility(View.GONE);
                                return false;
                            }

                            @Override
                            public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                                if (progressBar != null)
                                    progressBar.setVisibility(View.GONE);
                                return false;
                            }
                        }).into(mediaPost);
            }
            if (!employee.getIs_approved().equalsIgnoreCase("1")) {
                txt_status.setVisibility(View.VISIBLE);
                txt_status.setText("Pending");
                txt_status.setTextColor(context.getResources().getColor(R.color.red));
            } else if (employee.getPosted_by().equalsIgnoreCase(data.getMemberInfo().get(0).getMembers_id())) {
                txt_status.setVisibility(View.VISIBLE);
                txt_status.setText("MY POST");
                txt_status.setTextColor(context.getResources().getColor(R.color.bg_green));
            } else {
                txt_status.setVisibility(View.GONE);
                txt_status.setText("");
            }
            mediaPost.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    mainFragment.viewFulldetail(employee);
                }
            });

        }
    }

}


