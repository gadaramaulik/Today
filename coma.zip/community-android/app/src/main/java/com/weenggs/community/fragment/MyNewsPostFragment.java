package com.weenggs.community.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import com.weenggs.community.R;
import com.weenggs.community.activity.AddNewsPostActivity;
import com.weenggs.community.activity.PostFullDetailActivity;
import com.weenggs.community.adepter.MyNewsPostFragmentAdepter;
import com.weenggs.community.model.PostData;
import com.weenggs.community.model.PostResponce;
import com.weenggs.community.util.Constant;

import java.util.ArrayList;
import java.util.HashMap;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.app.Activity.RESULT_OK;

public class MyNewsPostFragment extends BaseFragment implements View.OnClickListener {

    private RecyclerView recycleview;
    LinearLayoutManager mLayoutManager;
    ArrayList<PostData> postDataArrayList;
    MyNewsPostFragmentAdepter adapter;
    int pastVisiblesItems, visibleItemCount, totalItemCount;

    boolean isApiCall;
    int index = 1;
    ImageView imgAdd;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.main_fragment, container, false);
        findViews(view);
        postDataArrayList = new ArrayList<>();
        // if (Constant.postDataArrayList == null) {
        getPost();
        //} else {
        //    setPost();
        //}
        return view;
    }

    private void findViews(View view) {
        recycleview = view.findViewById(R.id.recycleview);
        imgAdd = view.findViewById(R.id.imgAdd);
        mLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        recycleview.setLayoutManager(mLayoutManager);


        recycleview.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                if (dy > 0) //check for scroll down
                {
                    visibleItemCount = mLayoutManager.getChildCount();
                    totalItemCount = mLayoutManager.getItemCount();
                    pastVisiblesItems = mLayoutManager.findFirstVisibleItemPosition();

                    if (!isApiCall && index != -1) {

                        if ((visibleItemCount + pastVisiblesItems) >= totalItemCount) {
                            getPost();
                        }
                    }
                }
            }
        });

        imgAdd.setOnClickListener(this);
    }

    public void setPost() {

        for (int i = 0; i < Constant.postDataArrayList.size(); i++) {
            PostData postData = Constant.postDataArrayList.get(i);
            if (postData.getPosted_by().equalsIgnoreCase(data.getMemberInfo().get(0).getMembers_id()) || !postData.getIs_approved().equalsIgnoreCase("1")) {
                postDataArrayList.add(postData);
            }

        }


        //postDataArrayList.addAll(Constant.postDataArrayList);
        adapter = new MyNewsPostFragmentAdepter(MyNewsPostFragment.this, postDataArrayList, getActivity());
        recycleview.setAdapter(adapter);

    }

    public void viewFulldetail(PostData postData) {
        Constant.postData = postData;
        Intent intent = new Intent(context, PostFullDetailActivity.class);
        startActivityForResult(intent, 10);

    }


    public void getPost() {
        try {
            if (index == -1) {
                return;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        isApiCall = true;
        startprogressdialog(getActivity());
        HashMap<String, String> dataParams = new HashMap<>();
        dataParams.put("user_id", data.getMemberInfo().get(0).getUser_id());
        dataParams.put("pageNo", index + "");
        dataParams.put("members_id", data.getMemberInfo().get(0).getMembers_id());
        mAPIService.news_post_list(dataParams).enqueue(new Callback<PostResponce>() {
            @Override
            public void onResponse(Call<PostResponce> call, Response<PostResponce> response) {
                stopprogressdialog();
                isApiCall = false;
                if (response.isSuccessful()) {
                    Toast.makeText(getActivity(), response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    if (response.body().getData() != null && response.body().getData().size() > 0) {
                        if (response.body().getSuccess().equalsIgnoreCase("1")) {
                            index++;
                            Constant.postDataArrayList = response.body().getData();
                            setPost();
                        } else {
                            index = -1;
                        }

                    } else {
                        index = -1;
                    }
                }
            }

            @Override
            public void onFailure(Call<PostResponce> call, Throwable t) {
                stopprogressdialog();
                Constant.ErrorMessage(getActivity(), t);
            }
        });
    }

    @Override
    public void onClick(View v) {
        if (v == imgAdd) {
            Intent intent = new Intent(getActivity(), AddNewsPostActivity.class);
            startActivityForResult(intent, 10);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 10 && resultCode == RESULT_OK) {
            index = 1;
            postDataArrayList = new ArrayList<>();
            getPost();
        }
    }
}

