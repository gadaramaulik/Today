package com.weenggs.community.model;

import java.io.Serializable;

import okhttp3.RequestBody;

public class RegistationMemberRequest implements Serializable {

    private RequestBody first_name;
    private RequestBody father_name;
    private RequestBody surname;
    private RequestBody gender;
    private RequestBody date_of_birth;
    private RequestBody address;
    private RequestBody password;
    private RequestBody phone_number;
    private RequestBody family_sr_id;
    private RequestBody members_id;
    private RequestBody business_categroy_id;
    private RequestBody business_or_job_or_any;
    private RequestBody business_details;
    private RequestBody education;
    private RequestBody blood_group;
    private RequestBody marital_status;
    private RequestBody email_id;
    private RequestBody profile_image;
    private RequestBody id_proof;
    private RequestBody number_of_members;
    private RequestBody relation_ship;
    private RequestBody user_id;

    public RequestBody getRelation_ship() {
        return relation_ship;
    }

    public void setRelation_ship(RequestBody relation_ship) {
        this.relation_ship = relation_ship;
    }

    public RequestBody getMembers_id() {
        return members_id;
    }

    public void setMembers_id(RequestBody members_id) {
        this.members_id = members_id;
    }

    public RequestBody getUser_id() {
        return user_id;
    }

    public void setUser_id(RequestBody user_id) {
        this.user_id = user_id;
    }

    public RequestBody getNumber_of_members() {
        return number_of_members;
    }

    public void setNumber_of_members(RequestBody number_of_members) {
        this.number_of_members = number_of_members;
    }

    public RequestBody getPassword() {
        return password;
    }

    public void setPassword(RequestBody password) {
        this.password = password;
    }

    public RequestBody getFirst_name() {
        return first_name;
    }

    public void setFirst_name(RequestBody first_name) {
        this.first_name = first_name;
    }

    public RequestBody getFather_name() {
        return father_name;
    }

    public void setFather_name(RequestBody father_name) {
        this.father_name = father_name;
    }

    public RequestBody getSurname() {
        return surname;
    }

    public void setSurname(RequestBody surname) {
        this.surname = surname;
    }

    public RequestBody getGender() {
        return gender;
    }

    public void setGender(RequestBody gender) {
        this.gender = gender;
    }

    public RequestBody getDate_of_birth() {
        return date_of_birth;
    }

    public void setDate_of_birth(RequestBody date_of_birth) {
        this.date_of_birth = date_of_birth;
    }

    public RequestBody getAddress() {
        return address;
    }

    public void setAddress(RequestBody address) {
        this.address = address;
    }

    public RequestBody getPhone_number() {
        return phone_number;
    }

    public void setPhone_number(RequestBody phone_number) {
        this.phone_number = phone_number;
    }

    public RequestBody getFamily_sr_id() {
        return family_sr_id;
    }

    public void setFamily_sr_id(RequestBody family_sr_id) {
        this.family_sr_id = family_sr_id;
    }

    public RequestBody getBusiness_categroy_id() {
        return business_categroy_id;
    }

    public void setBusiness_categroy_id(RequestBody business_categroy_id) {
        this.business_categroy_id = business_categroy_id;
    }

    public RequestBody getBusiness_or_job_or_any() {
        return business_or_job_or_any;
    }

    public void setBusiness_or_job_or_any(RequestBody business_or_job_or_any) {
        this.business_or_job_or_any = business_or_job_or_any;
    }

    public RequestBody getBusiness_details() {
        return business_details;
    }

    public void setBusiness_details(RequestBody business_details) {
        this.business_details = business_details;
    }

    public RequestBody getEducation() {
        return education;
    }

    public void setEducation(RequestBody education) {
        this.education = education;
    }

    public RequestBody getBlood_group() {
        return blood_group;
    }

    public void setBlood_group(RequestBody blood_group) {
        this.blood_group = blood_group;
    }

    public RequestBody getMarital_status() {
        return marital_status;
    }

    public void setMarital_status(RequestBody marital_status) {
        this.marital_status = marital_status;
    }

    public RequestBody getEmail_id() {
        return email_id;
    }

    public void setEmail_id(RequestBody email_id) {
        this.email_id = email_id;
    }

    public RequestBody getProfile_image() {
        return profile_image;
    }

    public void setProfile_image(RequestBody profile_image) {
        this.profile_image = profile_image;
    }

    public RequestBody getId_proof() {
        return id_proof;
    }

    public void setId_proof(RequestBody id_proof) {
        this.id_proof = id_proof;
    }
}
