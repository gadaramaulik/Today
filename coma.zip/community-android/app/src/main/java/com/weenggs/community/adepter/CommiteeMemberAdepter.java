package com.weenggs.community.adepter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.weenggs.community.R;
import com.weenggs.community.fragment.CommitteememberFragment;
import com.weenggs.community.model.LoginUserFamilyMemberInfo;
import com.weenggs.community.widget.DTextView;

import java.util.ArrayList;

import androidx.recyclerview.widget.RecyclerView;

public class CommiteeMemberAdepter extends RecyclerView.Adapter<CommiteeMemberAdepter.ViewHolder> {

    CommitteememberFragment deviceListFragment;
    private ArrayList<LoginUserFamilyMemberInfo> items = new ArrayList<>();

    public CommiteeMemberAdepter(CommitteememberFragment context, ArrayList<LoginUserFamilyMemberInfo> data) {
        this.deviceListFragment = context;
        this.items = data;
    }

    public void addAll(ArrayList<LoginUserFamilyMemberInfo> data) {
        items.clear();
        items.addAll(data);
        notifyDataSetChanged();
    }

    public void add(LoginUserFamilyMemberInfo data) {
        items.add(data);
        notifyDataSetChanged();
    }


    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.commitee_member_adepter_row, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {

        final LoginUserFamilyMemberInfo data = items.get(position);


        holder.txtName.setText(data.getFirst_name() + " " + data.getSurname());
        holder.txtMobileno.setText(data.getPhone_number());
        holder.txtAdd.setText(data.getAddress());

        holder.layoutmain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public static final class ViewHolder extends RecyclerView.ViewHolder {

        private DTextView txtName, txtMobileno, txtAdd;
        private LinearLayout layoutmain;


        private ViewHolder(View itemView) {
            super(itemView);
            txtName = (DTextView) itemView.findViewById(R.id.txt_name);
            txtMobileno = (DTextView) itemView.findViewById(R.id.txtmobile);
            txtAdd = (DTextView) itemView.findViewById(R.id.txt_add);
            layoutmain = (LinearLayout) itemView.findViewById(R.id.layoutmain);

        }
    }
}

