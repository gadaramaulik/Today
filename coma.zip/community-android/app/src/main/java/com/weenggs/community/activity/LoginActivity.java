package com.weenggs.community.activity;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.weenggs.community.R;
import com.weenggs.community.model.LoginResponce;
import com.weenggs.community.util.Constant;

import java.util.HashMap;
import java.util.Locale;

import androidx.annotation.Nullable;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class LoginActivity extends BaseActivity implements View.OnClickListener {

    private EditText txtemail;
    private EditText txtpassword;
    private CheckBox logInSwitch;
    private TextView txtResetPassword;
    private TextView txtsingUp;
    private TextView submitsignin, txtEnglish, txtGujrati;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (pref.getBoolean(Constant.ISGUJARATI, false)) {
            setLagGujarati();
        } else {
            setLagEnglish();
        }
        setContentView(R.layout.login_activity);
        findViews();
    }

    private void findViews() {
        txtemail = (EditText) findViewById(R.id.txtemail);
        txtpassword = (EditText) findViewById(R.id.txtpassword);
        logInSwitch = (CheckBox) findViewById(R.id.logInSwitch);
        txtResetPassword = (TextView) findViewById(R.id.txtResetPassword);
        submitsignin = (TextView) findViewById(R.id.submitsignin);
        txtsingUp = (TextView) findViewById(R.id.txtsingUp);
        txtEnglish = (TextView) findViewById(R.id.txtEnglish);
        txtGujrati = (TextView) findViewById(R.id.txtGujrati);

        submitsignin.setOnClickListener(this);
        txtsingUp.setOnClickListener(this);
        txtGujrati.setOnClickListener(this);
        txtEnglish.setOnClickListener(this);

        if (application.getUserLoginData() != null) {
            Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
            startActivity(intent);
            finish();
        }

    }

    @Override
    public void onClick(View view) {
        if (view == submitsignin) {
            if (txtemail.getText().toString().trim().equalsIgnoreCase("")) {
                Toast.makeText(LoginActivity.this, "Please Enter your Mobile Number", Toast.LENGTH_SHORT).show();
            } else if (txtpassword.getText().toString().trim().equalsIgnoreCase("")) {
                Toast.makeText(LoginActivity.this, "Please enter password", Toast.LENGTH_SHORT).show();
            } else {
                hideSoftKeyboard(LoginActivity.this);
                loginUser();
            }
        } else if (view == txtsingUp) {
            Intent intent = new Intent(LoginActivity.this, VerifyMobileNumberActivity.class);
            startActivity(intent);
        } else if (view == txtEnglish) {
            pref.putBoolean(Constant.ISGUJARATI,false);
            setLagEnglish();
            finish();
            startActivity(getIntent());
        } else if (view == txtGujrati) {
            pref.putBoolean(Constant.ISGUJARATI,true);
            setLagGujarati();
            finish();
            startActivity(getIntent());
        }
    }

    public void setLagGujarati() {
        Locale locale = new Locale("gu");
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.locale = locale;
        getResources().updateConfiguration(config, getResources().getDisplayMetrics());
    }

    public void setLagEnglish() {
        Locale locale = new Locale("en");
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.locale = locale;
        getResources().updateConfiguration(config, getResources().getDisplayMetrics());
    }

    public void loginUser() {

           startprogressdialog(this);
        HashMap<String, String> dataParams = new HashMap<>();

        dataParams.put("phone_number", txtemail.getText().toString().trim());
        dataParams.put("password", txtpassword.getText().toString().trim());


        mAPIService.login_user(dataParams).enqueue(new Callback<LoginResponce>() {
            @Override
            public void onResponse(Call<LoginResponce> call, Response<LoginResponce> response) {
                stopprogressdialog();
                if (response.isSuccessful()) {
                    Toast.makeText(LoginActivity.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    if (response.body().getSuccess().equalsIgnoreCase("1")) {
                        application.setUserLoginData(response.body().getData());
                        Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
                        startActivity(intent);
                        finish();

                    }


                }
            }

            @Override
            public void onFailure(Call<LoginResponce> call, Throwable t) {
                stopprogressdialog();
                Constant.ErrorMessage(LoginActivity.this, t);
            }
        });
    }


}
