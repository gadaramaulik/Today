package com.weenggs.community;

import android.content.SharedPreferences;

import com.facebook.FacebookSdk;
import com.google.gson.Gson;
import com.weenggs.community.model.LoginData;
import com.weenggs.community.util.Constant;

import androidx.multidex.MultiDexApplication;

public class Application extends MultiDexApplication {
    SharedPreferences prefs;
    SharedPreferences.Editor editor;
    Constant constant;

    @Override
    public void onCreate() {
        super.onCreate();
        constant = new Constant(this);
        FacebookSdk.sdkInitialize(getApplicationContext());



    }


    public SharedPreferences getSharePre() {
        if (prefs == null)
            prefs = getSharedPreferences("user_Pref", 0);
        return prefs;
    }

    public SharedPreferences.Editor getSharePreEditor() {
        if (editor == null)
            editor = getSharePre().edit();
        return editor;
    }

    public void setUserLoginData(LoginData loginData) {
        getSharePreEditor().putString("logindata", new Gson().toJson(loginData));
        getSharePreEditor().commit();
    }

    public LoginData getUserLoginData() {
        return new Gson().fromJson(getSharePre().getString("logindata", null), LoginData.class);
    }


}
