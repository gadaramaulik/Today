package com.weenggs.community.logically;

public class SetGet {

    boolean isRed = false;
    boolean isblue = false;
    boolean isdisable = false;
    int position;

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    public boolean isRed() {
        return isRed;
    }

    public void setRed(boolean red) {
        isRed = red;
    }

    public boolean isIsblue() {
        return isblue;
    }

    public void setIsblue(boolean isblue) {
        this.isblue = isblue;
    }

    public boolean isIsdisable() {
        return isdisable;
    }

    public void setIsdisable(boolean isdisable) {
        this.isdisable = isdisable;
    }
}
