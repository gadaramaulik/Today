package com.weenggs.community.activity;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.telephony.TelephonyManager;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.victor.loading.rotate.RotateLoading;
import com.weenggs.community.Application;
import com.weenggs.community.R;
import com.weenggs.community.model.LoginData;
import com.weenggs.community.retrofit.APIService;
import com.weenggs.community.util.Constant;
import com.weenggs.community.util.Preferences;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import okhttp3.MediaType;


public class BaseActivity extends AppCompatActivity {

    public static final int REQUEST_CODE_GALLERY = 1;
    public static final int REQUEST_CODE_TAKE_PICTURE = 2;
    public MediaType MEDIA_TYPE_TEXT_PLAIN = MediaType.parse("text/plain");
    public MediaType MEDIA_TYPE_FORM_DATA = MediaType.parse("image/jpeg");
    public static final String TEMP_PHOTO_FILE_NAME = "temp_photo.jpg";
    public static File mFileTemp;
    public Toolbar toolbar;
    public TextView txtTitle;
    public Preferences pref;
    AlertDialog dialog;
    Uri mImageCaptureUri = null;
    public Toast toast;
    public TelephonyManager telephonyManager;
    public static final String TAG = "BaseActivity";
    public Resources mResources;
    public APIService mAPIService;
    public static final int REQ_ALL_PERMISSIONS_GALLARY = 101;
    public static final int REQ_ALL_PERMISSIONS_CAMERA = 102;
    LoginData data;
    Application application;
    public void startprogressdialog(Activity activity) {
        View v = LayoutInflater.from(getApplicationContext()).inflate(R.layout.progress_dialog, null);
        dialog = new AlertDialog.Builder(activity)
                .setView(v)
                .create();
        dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        dialog.setCancelable(false);
        RotateLoading rotateLoading = v.findViewById(R.id.rotateloading);
        rotateLoading.start();
        dialog.show();

    }

    public String returnText(TextView textView) {
        return textView.getText().toString().trim();

    }

    public String returnText(EditText textView) {
        return textView.getText().toString().trim();

    }

    public String getDeviceType() {
        return "A";
    }

    public String getRefferCode() {
        return "";
    }

    public String bindView(String str) {
        if (str == null) {
            return "";
        }
        return str;
    }

    public String bindView(int Integer) {

        return String.valueOf(Integer);
    }

    public String bindView(float Integer) {

        return String.valueOf(Integer);

    }

    public String bindView(double Integer) {
        return String.valueOf(Integer);
    }

    public void stopprogressdialog() {
        if (dialog != null)
            dialog.hide();
    }

    public void setFullScreen() {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        toast = Toast.makeText(getActivity(), "", Toast.LENGTH_LONG);
        mAPIService = Constant.getAPIService();
        pref = new Preferences(getActivity());
        application = (Application) getApplicationContext();
        if (application.getUserLoginData() != null) {
            data = application.getUserLoginData();
        }

    }


    public void initState() {
        String state = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(state)) {
            mFileTemp = new File(Environment.getExternalStorageDirectory(), TEMP_PHOTO_FILE_NAME);
        } else {
            mFileTemp = new File(getFilesDir(), TEMP_PHOTO_FILE_NAME);
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    public String formatDeciPoint(double value) {
        DecimalFormat formatVal = new DecimalFormat("##.##");
        return formatVal.format(value);
    }

    public String getDirKey(String id) {
        String[] parts = id.split("-");
        String first = parts[1];
        String second = parts[4];
        return first + second;
    }

    public String getDirectory(final String s) {
        final String MD5 = "MD5";
        try {
            MessageDigest digest = MessageDigest.getInstance(MD5);
            digest.update(s.getBytes());
            byte messageDigest[] = digest.digest();

            StringBuilder hexString = new StringBuilder();
            for (byte aMessageDigest : messageDigest) {
                String h = Integer.toHexString(0xFF & aMessageDigest);
                while (h.length() < 2)
                    h = "0" + h;
                hexString.append(h);
            }
            return hexString.toString();

        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return "";
    }

    public static ArrayList<String> addAssetsImages(Context mContext, String folderPath) {
        ArrayList<String> pathList = new ArrayList<>();
        try {
            String[] files = mContext.getAssets().list(folderPath);
            for (String name : files) {
                pathList.add(folderPath + File.separator + name);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return pathList;
    }

    public void hideKeyboard() {
        try {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        } catch (Exception e) {
        }
    }

    public static int calculateNoOfColumns(Context context, float columnWidthDp) { // For example columnWidthdp=180
        DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
        float screenWidthDp = displayMetrics.widthPixels / displayMetrics.density;
        int noOfColumns = (int) (screenWidthDp / columnWidthDp + 0.5); // +0.5 for correct rounding to int.
        return noOfColumns;
    }

    public void showToast(final int text, final boolean isShort) {
        runOnUiThread(new Runnable() {

            @Override
            public void run() {
                toast.setText(getString(text).toString());
                toast.setDuration(isShort ? Toast.LENGTH_SHORT : Toast.LENGTH_LONG);
                toast.show();
            }
        });
    }

    public void showToast(final String text, final boolean isShort) {
        runOnUiThread(new Runnable() {

            @Override
            public void run() {
                toast.setText(text);
                toast.setDuration(isShort ? Toast.LENGTH_SHORT : Toast.LENGTH_LONG);
                toast.show();
            }
        });
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    public boolean checkAndRequestPermissionsGallary() {
        int read = ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.READ_EXTERNAL_STORAGE);
        int write = ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.WRITE_EXTERNAL_STORAGE);

        List<String> listPermissionsNeeded = new ArrayList<>();

        if (read != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        }
        if (write != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }

        if (!listPermissionsNeeded.isEmpty()) {
            requestPermissions(listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]), REQ_ALL_PERMISSIONS_GALLARY);

            return false;
        }
        return true;
    }


    public void hideSoftKeyboard(Activity activity) {
        InputMethodManager inputMethodManager = null;
        try {
            inputMethodManager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            if (inputMethodManager != null) {
                inputMethodManager.hideSoftInputFromWindow(Objects.requireNonNull(activity.getCurrentFocus()).getWindowToken(), 0);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public BaseActivity getActivity() {
        return this;
    }


    public void saveImageToGallery(@NonNull File file, @NonNull Bitmap bmp) {
        if (bmp == null) {
            throw new IllegalArgumentException("bmp should not be null");
        }
        try {
            FileOutputStream fos = new FileOutputStream(file);

            bmp.setHasAlpha(true);
            bmp.compress(Bitmap.CompressFormat.JPEG, 100, fos);
            fos.flush();
            fos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        Log.e(TAG, "saveImageToGallery: >>>> " + file.getAbsolutePath());

    }


    private void shareApp(File image, Activity activity) {

        try {

            Uri uri = FileProvider.getUriForFile(activity, getPackageName() + ".provider", image);

            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("image/*");
            intent.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.app_name));
            if (uri != null) {
                intent.putExtra(Intent.EXTRA_STREAM, uri);
                intent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

                startActivity(Intent.createChooser(intent, "Share Image"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public boolean appInstalledOrNot(String uri) {
        PackageManager pm = getPackageManager();
        try {
            pm.getPackageInfo(uri, PackageManager.GET_ACTIVITIES);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
        }

        return false;
    }


    public boolean checkAndRequestPermissionsCamera() {
        int read = ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.READ_EXTERNAL_STORAGE);
        int write = ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.WRITE_EXTERNAL_STORAGE);
        int camera = ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.CAMERA);

        List<String> listPermissionsNeeded = new ArrayList<>();

        if (read != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        }
        if (write != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
        if (camera != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.CAMERA);
        }

        if (!listPermissionsNeeded.isEmpty()) {
            requestPermissions( listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]), REQ_ALL_PERMISSIONS_CAMERA);

            return false;
        }
        return true;
    }

    public static void setLocale(Context context, String lang, Boolean redirect) {
        Locale myLocale = new Locale(lang);
        Resources res = context.getResources();
        DisplayMetrics dm = res.getDisplayMetrics();
        Configuration conf = res.getConfiguration();
        conf.locale = myLocale;
        res.updateConfiguration(conf, dm);

    }


}
