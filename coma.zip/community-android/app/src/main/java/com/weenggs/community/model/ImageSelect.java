package com.weenggs.community.model;

public class ImageSelect {

    boolean isNew;
    boolean isVideo;
    String path;
    String id;
    String news_id;
    String video_thaum_url;
    String url;

    public String getVideo_thaum_url() {
        return video_thaum_url;
    }

    public void setVideo_thaum_url(String video_thaum_url) {
        this.video_thaum_url = video_thaum_url;
    }

    public String getNews_id() {
        return news_id;
    }

    public void setNews_id(String news_id) {
        this.news_id = news_id;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public boolean isVideo() {
        return isVideo;
    }

    public void setVideo(boolean video) {
        isVideo = video;
    }

    public boolean isNew() {
        return isNew;
    }

    public void setNew(boolean aNew) {
        isNew = aNew;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
