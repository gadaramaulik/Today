package com.weenggs.community.model;

public class LoginUserFamilyMemberInfo {

    String email_id="";
    String address="";
    String education="";
    String gender="";
    String date_of_birth="";
    String id_proof="";
    String registered_on="";
    String business_or_job_or_any="";
    String member_type="";
    String business_details="";
    String marital_status="";
    String profile_image="";
    String father_name="";
    String user_id="";
    String surname="";
    String is_commitee_member="";
    String blood_group="";
    String phone_number="";
    String business_categroy_id="";
    String members_id="";
    String first_name="";
    String family_sr_id="";
    String relation_ship="";

    public String getRelation_ship() {
        return relation_ship;
    }

    public void setRelation_ship(String relation_ship) {
        this.relation_ship = relation_ship;
    }

    public String getMember_type() {
        return member_type;
    }

    public void setMember_type(String member_type) {
        this.member_type = member_type;
    }

    public String getEmail_id() {
        return email_id;
    }

    public void setEmail_id(String email_id) {
        this.email_id = email_id;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getEducation() {
        return education;
    }

    public void setEducation(String education) {
        this.education = education;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getDate_of_birth() {
        return date_of_birth;
    }

    public void setDate_of_birth(String date_of_birth) {
        this.date_of_birth = date_of_birth;
    }

    public String getId_proof() {
        return id_proof;
    }

    public void setId_proof(String id_proof) {
        this.id_proof = id_proof;
    }

    public String getRegistered_on() {
        return registered_on;
    }

    public void setRegistered_on(String registered_on) {
        this.registered_on = registered_on;
    }

    public String getBusiness_or_job_or_any() {
        return business_or_job_or_any;
    }

    public void setBusiness_or_job_or_any(String business_or_job_or_any) {
        this.business_or_job_or_any = business_or_job_or_any;
    }

    public String getBusiness_details() {
        return business_details;
    }

    public void setBusiness_details(String business_details) {
        this.business_details = business_details;
    }

    public String getMarital_status() {
        return marital_status;
    }

    public void setMarital_status(String marital_status) {
        this.marital_status = marital_status;
    }

    public String getProfile_image() {
        return profile_image;
    }

    public void setProfile_image(String profile_image) {
        this.profile_image = profile_image;
    }

    public String getFather_name() {
        return father_name;
    }

    public void setFather_name(String father_name) {
        this.father_name = father_name;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getIs_commitee_member() {
        return is_commitee_member;
    }

    public void setIs_commitee_member(String is_commitee_member) {
        this.is_commitee_member = is_commitee_member;
    }

    public String getBlood_group() {
        return blood_group;
    }

    public void setBlood_group(String blood_group) {
        this.blood_group = blood_group;
    }

    public String getPhone_number() {
        return phone_number;
    }

    public void setPhone_number(String phone_number) {
        this.phone_number = phone_number;
    }

    public String getBusiness_categroy_id() {
        return business_categroy_id;
    }

    public void setBusiness_categroy_id(String business_categroy_id) {
        this.business_categroy_id = business_categroy_id;
    }

    public String getMembers_id() {
        return members_id;
    }

    public void setMembers_id(String members_id) {
        this.members_id = members_id;
    }

    public String getFirst_name() {
        return first_name;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public String getFamily_sr_id() {
        return family_sr_id;
    }

    public void setFamily_sr_id(String family_sr_id) {
        this.family_sr_id = family_sr_id;
    }
}
