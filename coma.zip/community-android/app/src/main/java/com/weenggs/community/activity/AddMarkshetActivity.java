package com.weenggs.community.activity;

import android.Manifest;
import android.app.Dialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.weenggs.community.R;
import com.weenggs.community.camera.CameraActivity;
import com.weenggs.community.model.AddMarksheetRequest;
import com.weenggs.community.model.CommitteeMemberResponce;
import com.weenggs.community.model.LoginResponce;
import com.weenggs.community.model.LoginUserFamilyMemberInfo;
import com.weenggs.community.model.MarkSheetListData;
import com.weenggs.community.model.StandardData;
import com.weenggs.community.model.StandardMediumResponce;
import com.weenggs.community.spinneradepter.BoradAdapter;
import com.weenggs.community.spinneradepter.GradeAdapter;
import com.weenggs.community.spinneradepter.MediumAdapter;
import com.weenggs.community.spinneradepter.SpinnerMemberAdapter;
import com.weenggs.community.spinneradepter.StandardAdapter;
import com.weenggs.community.util.Constant;
import com.weenggs.community.widget.DEditText;
import com.weenggs.community.widget.DTextView;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddMarkshetActivity extends BaseActivity implements View.OnClickListener {

    private static final String TAG = "MarkSheetFragment";

    Spinner spinnerSelectMember;
    DTextView txtMember;
    ImageView cancel;
    Spinner spinnerStandard;
    DTextView txtStandard;
    Spinner spinnerMedium;
    DTextView txtMedium;
    DTextView txtresoun;
    Spinner spinnerGrade;
    Spinner spinnerBord;
    DTextView txtGrade;
    DEditText editPercentage;
    DTextView btnUploadMarksheet;
    ImageView imagMarksheet;
    DTextView btnSubmit;
    DTextView txtBord;
    Bitmap bitmap;
    String selectedImagePath;
    String selectedPicImagepath;

    public static final int PICK_CAMERA = 1;
    public static final int PICK_PHOTO_FOR_AVATAR = 0;

    StandardData selectedStandardData;
    StandardData selectedmediumData;
    StandardData selectedGradeData;
    StandardData selectedBord;
    LoginUserFamilyMemberInfo selectedMember;

    ArrayList<StandardData> standardArrayList;
    ArrayList<StandardData> mediumArrayList;
    ArrayList<StandardData> gradeArrayList;
    ArrayList<StandardData> bordArrayList;
    ArrayList<LoginUserFamilyMemberInfo> memberArrayList;

    boolean isNew = false;
    MarkSheetListData markSheetListData;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_marksheet_activity);
        isNew = getIntent().getBooleanExtra(Constant.ADDNEW, false);
        findViews();
        if (!isNew) {
            markSheetListData = Constant.markSheetListData;
            txtresoun.setVisibility(View.VISIBLE);
            txtresoun.setText(markSheetListData.getMarksheet_decline_reason());
            txtTitle.setText(R.string.update_marksheet);
        }
        if (Constant.standardMediumData != null) {
            setCategory();
        } else {
            getStandard();
        }


    }

    public void findViews() {

        spinnerSelectMember = findViewById(R.id.spinnerSelectMember);
        txtMember = findViewById(R.id.txtMember);
        cancel = findViewById(R.id.cancel);
        spinnerStandard = findViewById(R.id.spinnerStandard);
        txtTitle = findViewById(R.id.txtTitle);
        txtStandard = findViewById(R.id.txtStandard);
        txtBord = findViewById(R.id.txtBord);
        spinnerMedium = findViewById(R.id.spinnerMedium);
        spinnerBord = findViewById(R.id.spinnerBord);
        txtMedium = findViewById(R.id.txtMedium);
        txtresoun = findViewById(R.id.txtresoun);
        spinnerGrade = findViewById(R.id.spinnerGrade);
        txtGrade = findViewById(R.id.txtGrade);
        editPercentage = findViewById(R.id.editPercentage);
        btnUploadMarksheet = findViewById(R.id.btnUploadMarksheet);
        imagMarksheet = findViewById(R.id.imagMarksheet);
        btnSubmit = findViewById(R.id.btnSubmit);

        btnSubmit.setOnClickListener(this);
        btnUploadMarksheet.setOnClickListener(this);
        txtBord.setOnClickListener(this);
        txtGrade.setOnClickListener(this);
        txtMedium.setOnClickListener(this);
        txtMember.setOnClickListener(this);
        cancel.setOnClickListener(this);
        txtStandard.setOnClickListener(this);
    }


    @Override
    public void onClick(View view) {
        if (view == btnSubmit) {
            AddMarksheet();

        } else if (view == btnUploadMarksheet) {
            hideSoftKeyboard(getActivity());
            ProfileimagesetDialog();
        } else if (view == cancel) {
            finish();
        } else if (view == txtBord) {
            hideSoftKeyboard(getActivity());
            spinnerBord.performClick();
        } else if (view == txtGrade) {
            hideSoftKeyboard(getActivity());
            spinnerGrade.performClick();
        } else if (view == txtMedium) {
            hideSoftKeyboard(getActivity());
            spinnerMedium.performClick();
        } else if (view == txtStandard) {
            hideSoftKeyboard(getActivity());
            spinnerStandard.performClick();
        } else if (view == txtMember) {
            hideSoftKeyboard(getActivity());
            spinnerSelectMember.performClick();
        }
    }

    private void ProfileimagesetDialog() {

        final Dialog dialog = new Dialog(getActivity());
        dialog.setCancelable(true);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.setContentView(R.layout.changeprofilepic_dialog);

        Button buttoncamera = dialog.findViewById(R.id.buttoncamera);
        Button buttongallery = dialog.findViewById(R.id.buttongallery);
        Button buttoncancel = dialog.findViewById(R.id.buttoncancel);

        buttoncamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                if (checkAndRequestPermissionsCamera()) {
                    //openCamera();
                    openCamera();
                }
            }
        });
        buttongallery.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                if (checkAndRequestPermissionsGallary()) {
                    pickImage();
                }
            }
        });
        buttoncancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        try {
            dialog.show();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    public void openCamera() {

        Intent intent = new Intent(getActivity(), CameraActivity.class);
        intent.putExtra("isFountCamera", false);
        startActivityForResult(intent, PICK_CAMERA);
    }

    public void pickImage() {

        Intent pictureActionIntent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(pictureActionIntent, PICK_PHOTO_FOR_AVATAR);
    }

    public void setCategory() {

        if (Constant.familyMemberDataArrayList == null) {
            getMemberList();
        } else {
            setMember();
        }

        standardArrayList = new ArrayList<>();
        standardArrayList.addAll(Constant.standardMediumData.getStandardData());

        mediumArrayList = new ArrayList<>();
        mediumArrayList.addAll(Constant.standardMediumData.getMediumData());

        gradeArrayList = new ArrayList<>();
        gradeArrayList.addAll(Constant.standardMediumData.getGradeData());

        bordArrayList = new ArrayList<>();
        bordArrayList.addAll(Constant.standardMediumData.getBoardData());

        StandardData categoryData = new StandardData();
        categoryData.setStandard_id("");
        categoryData.setStandard_name("Select Standard");
        standardArrayList.add(0, categoryData);

        categoryData = new StandardData();
        categoryData.setMedium_id("");
        categoryData.setMedium_name("Select Medium");
        mediumArrayList.add(0, categoryData);

        categoryData = new StandardData();
        categoryData.setGrade_id("");
        categoryData.setGrade_name("Select Grade");
        gradeArrayList.add(0, categoryData);

        categoryData = new StandardData();
        categoryData.setBu_id("");
        categoryData.setTitle("Select Board");
        bordArrayList.add(0, categoryData);

        StandardAdapter tatusAdapter = new StandardAdapter(getActivity(), standardArrayList);
        spinnerStandard.setAdapter(tatusAdapter);

        spinnerStandard.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                txtStandard.setText("" + standardArrayList.get(i).getStandard_name());
                selectedStandardData = standardArrayList.get(i);

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        MediumAdapter mediumAdapter = new MediumAdapter(getActivity(), mediumArrayList);
        spinnerMedium.setAdapter(mediumAdapter);

        spinnerMedium.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                txtMedium.setText("" + mediumArrayList.get(i).getMedium_name());
                selectedmediumData = mediumArrayList.get(i);

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        GradeAdapter gradeAdapter = new GradeAdapter(getActivity(), gradeArrayList);
        spinnerGrade.setAdapter(gradeAdapter);

        spinnerGrade.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                txtGrade.setText("" + gradeArrayList.get(i).getGrade_name());
                selectedGradeData = gradeArrayList.get(i);

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        BoradAdapter boradAdapter = new BoradAdapter(getActivity(), bordArrayList);
        spinnerBord.setAdapter(boradAdapter);

        spinnerBord.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                txtBord.setText("" + bordArrayList.get(i).getTitle());
                selectedBord = bordArrayList.get(i);

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        if (!isNew) {
            for (int i = 0; i < standardArrayList.size(); i++) {
                if (standardArrayList.get(i).getStandard_id().equalsIgnoreCase(markSheetListData.getStandard_id())) {
                    spinnerStandard.setSelection(i);
                }
            }
            for (int i = 0; i < mediumArrayList.size(); i++) {
                if (mediumArrayList.get(i).getMedium_id().equalsIgnoreCase(markSheetListData.getMedium_id())) {
                    spinnerMedium.setSelection(i);
                }
            }
            for (int i = 0; i < gradeArrayList.size(); i++) {
                if (gradeArrayList.get(i).getGrade_id().equalsIgnoreCase(markSheetListData.getGrade_id())) {
                    spinnerGrade.setSelection(i);
                }
            }
            for (int i = 0; i < bordArrayList.size(); i++) {
                if (bordArrayList.get(i).getBu_id().equalsIgnoreCase(markSheetListData.getBu_id())) {
                    spinnerBord.setSelection(i);
                }
            }

            editPercentage.setText(markSheetListData.getPercentage());

            if (!markSheetListData.getMarksheet_image().equalsIgnoreCase("")) {
                Glide.with(getApplicationContext()).load(Constant.BASE_IMAGE_URL + markSheetListData.getMarksheet_image())
                        .into(imagMarksheet);
            }
        }

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        bitmap = null;
        selectedImagePath = null;
        switch (requestCode) {
            case 0:
                if (data != null) {

                    Uri selectedImage = data.getData();
                    String[] filePath = {MediaStore.Images.Media.DATA};
                    Cursor c = getActivity().getContentResolver().query(selectedImage, filePath,
                            null, null, null);
                    c.moveToFirst();
                    int columnIndex = c.getColumnIndex(filePath[0]);
                    selectedImagePath = c.getString(columnIndex);
                    c.close();

                    bitmap = BitmapFactory.decodeFile(selectedImagePath); // load
                    bitmap = Bitmap.createScaledBitmap(bitmap, 400, 400, false);

                    if (bitmap != null) {

                        imagMarksheet.setImageBitmap(bitmap);
                        selectedPicImagepath = selectedImagePath;

                    }

                } else {
                    Toast.makeText(getActivity(), "Cancelled", Toast.LENGTH_SHORT).show();
                }


                break;
            case 1:

                if (Constant.bitmap != null) {
                    bitmap = Constant.bitmap;

                    imagMarksheet.setImageBitmap(bitmap);
                    selectedPicImagepath = Constant.path;

                    Constant.path = "";
                    Constant.bitmap = null;
                }

                break;
        }
    }

    public void getStandard() {
        startprogressdialog(this);
        HashMap<String, String> dataParams = new HashMap<>();
        dataParams.put("user_id", data.getMemberInfo().get(0).getUser_id());
        mAPIService.get_standard(dataParams).enqueue(new Callback<StandardMediumResponce>() {
            @Override
            public void onResponse(Call<StandardMediumResponce> call, Response<StandardMediumResponce> response) {
                stopprogressdialog();
                if (response.isSuccessful()) {
                    if (response.body().getSuccess().equalsIgnoreCase("1")) {
                        Constant.standardMediumData = response.body().getData();
                        setCategory();
                    }
                }
            }

            @Override
            public void onFailure(Call<StandardMediumResponce> call, Throwable t) {
                stopprogressdialog();
                Constant.ErrorMessage(getActivity(), t);
            }
        });
    }

    public void getMemberList() {

        startprogressdialog(this);
        HashMap<String, String> dataParams = new HashMap<>();
        dataParams.put("user_id", data.getMemberInfo().get(0).getUser_id());
        mAPIService.get_member_list(dataParams).enqueue(new Callback<CommitteeMemberResponce>() {
            @Override
            public void onResponse(Call<CommitteeMemberResponce> call, Response<CommitteeMemberResponce> response) {
                stopprogressdialog();
                if (response.isSuccessful()) {
                    //Toast.makeText(getActivity(), response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    if (response.body().getSuccess().equalsIgnoreCase("1")) {
                        Constant.familyMemberDataArrayList = response.body().getData();
                        setMember();
                    }
                }
            }

            @Override
            public void onFailure(Call<CommitteeMemberResponce> call, Throwable t) {
                stopprogressdialog();
                Constant.ErrorMessage(getActivity(), t);
            }
        });
    }


    public void setMember() {
        memberArrayList = new ArrayList<>();
        memberArrayList.addAll(Constant.familyMemberDataArrayList);

        LoginUserFamilyMemberInfo categoryData = new LoginUserFamilyMemberInfo();
        categoryData.setUser_id("");
        categoryData.setFirst_name("Select Member");
        memberArrayList.add(0, categoryData);

        SpinnerMemberAdapter tatusAdapter = new SpinnerMemberAdapter(getActivity(), memberArrayList);
        spinnerSelectMember.setAdapter(tatusAdapter);

        spinnerSelectMember.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                txtMember.setText("" + memberArrayList.get(i).getFirst_name() + " " + memberArrayList.get(i).getSurname());
                selectedMember = memberArrayList.get(i);

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        if (!isNew) {
            for (int i = 0; i < memberArrayList.size(); i++) {
                if (memberArrayList.get(i).getUser_id().equalsIgnoreCase(markSheetListData.getUser_id())) {
                    spinnerSelectMember.setSelection(i);
                }
            }
        }

    }


    public void AddMarksheet() {
        startprogressdialog(this);
        if (selectedMember.getUser_id().equalsIgnoreCase("")) {
            Toast.makeText(this, "Select member", Toast.LENGTH_SHORT).show();
        } else if (selectedBord.getBu_id().equalsIgnoreCase("")) {
            Toast.makeText(this, "Select bord", Toast.LENGTH_SHORT).show();
        } else if (selectedGradeData.getGrade_id().equalsIgnoreCase("")) {
            Toast.makeText(this, "Select grade", Toast.LENGTH_SHORT).show();
        } else if (selectedStandardData.getStandard_id().equalsIgnoreCase("")) {
            Toast.makeText(this, "Select standard", Toast.LENGTH_SHORT).show();
        } else if (selectedmediumData.getMedium_id().equalsIgnoreCase("")) {
            Toast.makeText(this, "Select medium", Toast.LENGTH_SHORT).show();
        } else if (editPercentage.getText().toString().trim().equalsIgnoreCase("")) {
            Toast.makeText(this, "Select percentage", Toast.LENGTH_SHORT).show();
        } else {

            AddMarksheetRequest addMarksheetRequest = new AddMarksheetRequest();
            addMarksheetRequest.setBu_id(RequestBody.create(MEDIA_TYPE_TEXT_PLAIN, selectedBord.getBu_id()));
            addMarksheetRequest.setGrade_id(RequestBody.create(MEDIA_TYPE_TEXT_PLAIN, selectedGradeData.getGrade_id()));
            addMarksheetRequest.setMedium_id(RequestBody.create(MEDIA_TYPE_TEXT_PLAIN, selectedmediumData.getMedium_id()));
            addMarksheetRequest.setStandard_id(RequestBody.create(MEDIA_TYPE_TEXT_PLAIN, selectedStandardData.getStandard_id()));
            addMarksheetRequest.setMembers_id(RequestBody.create(MEDIA_TYPE_TEXT_PLAIN, selectedMember.getUser_id()));
            addMarksheetRequest.setYears(RequestBody.create(MEDIA_TYPE_TEXT_PLAIN, "2020"));
            addMarksheetRequest.setUser_id(RequestBody.create(MEDIA_TYPE_TEXT_PLAIN, application.getUserLoginData().getLogins().getUser_id()));
            addMarksheetRequest.setPercentage(RequestBody.create(MEDIA_TYPE_TEXT_PLAIN, editPercentage.getText().toString().trim()));
            if (selectedPicImagepath != null) {
                addMarksheetRequest.setMarksheet_image(RequestBody.create(MEDIA_TYPE_FORM_DATA, new File(selectedPicImagepath)));
            }
            if (!isNew) {
                addMarksheetRequest.setMarksheet_id(RequestBody.create(MEDIA_TYPE_TEXT_PLAIN, markSheetListData.getMarksheet_id()));
            }

            if (isNew) {
                mAPIService.add_marksheet(addMarksheetRequest.getUser_id(), addMarksheetRequest.getMembers_id(),
                        addMarksheetRequest.getStandard_id(), addMarksheetRequest.getMedium_id(),
                        addMarksheetRequest.getPercentage(), addMarksheetRequest.getGrade_id(),
                        addMarksheetRequest.getBu_id(), addMarksheetRequest.getYears(),
                        addMarksheetRequest.getMarksheet_image()).enqueue(new Callback<LoginResponce>() {
                    @Override
                    public void onResponse(Call<LoginResponce> call, Response<LoginResponce> response) {
                        stopprogressdialog();
                        if (response.isSuccessful()) {
                            Toast.makeText(AddMarkshetActivity.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();

                            if (response.body().getSuccess().equalsIgnoreCase("1")) {

                                setResult(RESULT_OK);
                                finish();
                            }

                        }
                    }

                    @Override
                    public void onFailure(Call<LoginResponce> call, Throwable t) {
                        stopprogressdialog();
                        Constant.ErrorMessage(AddMarkshetActivity.this, t);
                    }
                });
            } else {
                mAPIService.edit_marksheet(addMarksheetRequest.getMarksheet_id(), addMarksheetRequest.getUser_id(), addMarksheetRequest.getMembers_id(),
                        addMarksheetRequest.getStandard_id(), addMarksheetRequest.getMedium_id(),
                        addMarksheetRequest.getPercentage(), addMarksheetRequest.getGrade_id(),
                        addMarksheetRequest.getBu_id(), addMarksheetRequest.getYears(),
                        addMarksheetRequest.getMarksheet_image()).enqueue(new Callback<LoginResponce>() {
                    @Override
                    public void onResponse(Call<LoginResponce> call, Response<LoginResponce> response) {
                        stopprogressdialog();
                        if (response.isSuccessful()) {
                            Toast.makeText(AddMarkshetActivity.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();

                            if (response.body().getSuccess().equalsIgnoreCase("1")) {

                                setResult(RESULT_OK);
                                finish();
                            }

                        }
                    }

                    @Override
                    public void onFailure(Call<LoginResponce> call, Throwable t) {
                        stopprogressdialog();
                        Constant.ErrorMessage(AddMarkshetActivity.this, t);
                    }
                });
            }


        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case REQ_ALL_PERMISSIONS_GALLARY:
                if (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(), Manifest.permission.WRITE_EXTERNAL_STORAGE)) {

                    } else {
                        Log.e(TAG, "onRequestPermissionsResult: WRITE_EXTERNAL_STORAGE >> dont ask again");
                    }
                } else {
                    pickImage();
                }

                break;
            case REQ_ALL_PERMISSIONS_CAMERA:
                if (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(), Manifest.permission.WRITE_EXTERNAL_STORAGE)) {


                    } else {

                    }
                } else if (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {

                } else {

                    openCamera();
                }

                break;
        }

    }

}
