package com.weenggs.community.adepter;

/**
 * Created by pratap.kesaboyina on 24-12-2014.
 */

import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;

import com.bumptech.glide.Glide;
import com.squareup.picasso.Picasso;
import com.weenggs.community.R;
import com.weenggs.community.activity.AddNewsPostActivity;
import com.weenggs.community.model.ImageSelect;
import com.weenggs.community.util.Constant;

import java.util.ArrayList;

import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

public class ImageSliderIncidentAdapter extends RecyclerView.Adapter<ImageSliderIncidentAdapter.SingleItemRowHolder> {

    private ArrayList<ImageSelect> itemsList;
    private AddNewsPostActivity context;
    public int selected = 1;

    //    String deleteId="";
    public ImageSliderIncidentAdapter(AddNewsPostActivity context, ArrayList<ImageSelect> itemsList) {
        this.itemsList = itemsList;
        this.context = context;
        notifyDataSetChanged();
    }

    @Override
    public SingleItemRowHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.image_load, null);
        SingleItemRowHolder mh = new SingleItemRowHolder(v);
        return mh;
    }

    @Override
    public void onBindViewHolder(final SingleItemRowHolder holder, final int position) {

        final ImageSelect horizontalList = itemsList.get(position);
        if (horizontalList.isNew() && horizontalList.isVideo()) {

            Glide.with(context).load("file:///" + horizontalList.getPath()) // or URI/path
                    .into(holder.profilePic);

        } else if (!horizontalList.isNew() && horizontalList.isVideo()) {

            Glide.with(context).load(Constant.BASE_IMAGE_URL +horizontalList.getVideo_thaum_url()) // or URI/path
                    .into(holder.profilePic);

        } else if (!horizontalList.isNew() && !horizontalList.getUrl().equalsIgnoreCase("")) {
            holder.progressBarImage.setVisibility(View.VISIBLE);
            Picasso.with(context).load(Constant.BASE_IMAGE_URL +horizontalList.getUrl()).into(holder.profilePic, new com.squareup.picasso.Callback() {
                @Override
                public void onSuccess() {
                    holder.progressBarImage.setVisibility(View.GONE);
                }

                @Override
                public void onError() {
                    holder.progressBarImage.setVisibility(View.GONE);
                }
            });
        } else {
            holder.progressBarImage.setVisibility(View.VISIBLE);
            Picasso.with(context).load("file:///" + horizontalList.getPath()).into(holder.profilePic, new com.squareup.picasso.Callback() {
                @Override
                public void onSuccess() {
                    holder.progressBarImage.setVisibility(View.GONE);
                }

                @Override
                public void onError() {
                    holder.progressBarImage.setVisibility(View.GONE);
                }
            });

        }

        holder.close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder adb = new AlertDialog.Builder(context);
                adb.setTitle("Delete?");
                adb.setMessage("Are you sure you want to delete? ");
                adb.setNegativeButton("Cancel", null);
                adb.setPositiveButton("Ok", new AlertDialog.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        context.imageDelete(position);
                    }
                });
                adb.show();
            }
        });


        holder.profilePic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //ConstantData.imageSelectArrayListZoom = itemsList;
                //Intent intent = new Intent(context, ZoomPhotoActivty.class);
                //intent.putExtra("position", position);
                //intent.putExtra("isEdit", context.canSave);
                //context.startActivityForResult(intent, 90);

            }
        });
        holder.close.setVisibility(View.VISIBLE);


    }

    @Override
    public int getItemCount() {
        return (null != itemsList ? itemsList.size() : 0);
    }

    public class SingleItemRowHolder extends RecyclerView.ViewHolder {


        ProgressBar progressBarImage;
        ImageView profilePic;
        RelativeLayout imageviewLayout;
        ImageView close;

        public SingleItemRowHolder(View view) {
            super(view);

            profilePic = view.findViewById(R.id.profilePic);
            progressBarImage = view.findViewById(R.id.progressBar);
            imageviewLayout = view.findViewById(R.id.imageviewLayout);
            close = view.findViewById(R.id.close);

        }

    }

}