package com.weenggs.community.logically;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.weenggs.community.R;
import com.weenggs.community.widget.DTextView;

import java.util.ArrayList;
import java.util.Random;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

public class logicalyAdepter extends RecyclerView.Adapter<logicalyAdepter.ViewHolder> {

    logicallyActivity deviceListFragment;
    private ArrayList<SetGet> items = new ArrayList<>();
    int lastClickposition = -1;
    boolean isLastPosition = true;

    public logicalyAdepter(logicallyActivity context, ArrayList<SetGet> data) {
        this.deviceListFragment = context;
        this.items = data;
    }

    public void addAll(ArrayList<SetGet> data) {
        items.clear();
        items.addAll(data);
        notifyDataSetChanged();
    }

    public void add(SetGet data) {
        items.add(data);
        notifyDataSetChanged();
    }


    @Override
    public logicalyAdepter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.logicaly_adpter_row, parent, false);
        return new logicalyAdepter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(logicalyAdepter.ViewHolder holder, final int position) {

        final SetGet data = items.get(position);
        if (data.isblue && !data.isRed && !data.isdisable) {
            holder.txtDot.setTextColor(Color.BLUE);
            holder.txtDot.setVisibility(View.VISIBLE);
        } else if (data.isblue && data.isRed && !data.isdisable) {
            holder.txtDot.setTextColor(Color.RED);
            holder.txtDot.setVisibility(View.VISIBLE);
        } else if (data.isblue && data.isRed && data.isdisable) {
            holder.txtDot.setTextColor(Color.GREEN);
            holder.txtDot.setVisibility(View.VISIBLE);
        } else {
            holder.txtDot.setVisibility(View.GONE);
        }

        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!data.isdisable) {
                    if (data.isblue) {

                        items.get(position).setRed(true);
                        int a = getRendom(position);


                        if (a > -1) {
                            items.get(a).setIsblue(true);
                            if (lastClickposition != -1) {
                                items.get(lastClickposition).setIsdisable(true);
                                lastClickposition = position;
                            } else {
                                lastClickposition = position;
                            }
                            notifyDataSetChanged();
                        }
                    }

                }
            }
        });


    }

    public int getRendom(int position) {
        ArrayList<SetGet> temp = new ArrayList<>();
        for (int j = 0; j < items.size(); j++) {
            if (!items.get(j).isRed && !items.get(j).isblue && !items.get(j).isdisable) {
                SetGet setGet = new SetGet();
                setGet.setPosition(j);
                temp.add(setGet);
            }
        }

        if (temp.size() > 0) {
            int random = new Random().nextInt(temp.size());
            return temp.get(random).getPosition();
        } else {
            if (isLastPosition) {
                isLastPosition=false;
                items.get(lastClickposition).setIsdisable(true);
            } else {
                items.get(position).setIsdisable(true);
            }

            notifyDataSetChanged();
            Toast.makeText(deviceListFragment, "Completed", Toast.LENGTH_SHORT).show();
            return -1;
        }
    }


    @Override
    public int getItemCount() {
        return items.size();
    }

    public static final class ViewHolder extends RecyclerView.ViewHolder {

        private CardView cardView;
        private DTextView txtDot;

        private ViewHolder(View itemView) {
            super(itemView);
            cardView = (CardView) itemView.findViewById(R.id.card_view);
            txtDot = (DTextView) itemView.findViewById(R.id.txtDot);

        }
    }
}


