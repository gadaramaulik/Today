package com.weenggs.community.demo;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseAppLifecycleListener;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.weenggs.community.R;
import com.weenggs.community.activity.BaseActivity;
import com.weenggs.community.util.Constant;
import com.weenggs.community.widget.DEditText;
import com.weenggs.community.widget.DTextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class FireStoreActivity extends BaseActivity implements View.OnClickListener {
    FirebaseFirestore db;
    private ImageView cancel;
    private DTextView txtTitle;
    private DEditText editFname;
    private DEditText editLname;
    private DEditText editFathername;
    private DEditText editemail;
    private DTextView btnSubmit;
    RecyclerView recycleview;
    LinearLayoutManager mLayoutManager;
    ArrayList<FierStoreModel> fierStoreModelArrayList;
    FireStoreAdepter adapter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.firestore);
        db = FirebaseFirestore.getInstance();
        findViews();

    }

    private void findViews() {
        fierStoreModelArrayList = new ArrayList<>();
        cancel = findViewById(R.id.cancel);
        txtTitle = findViewById(R.id.txtTitle);
        editFname = findViewById(R.id.editFname);
        editLname = findViewById(R.id.editLname);
        editFathername = findViewById(R.id.editFathername);
        editemail = findViewById(R.id.editemail);
        btnSubmit = findViewById(R.id.btnSubmit);
        recycleview = findViewById(R.id.recycleview);

        mLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        recycleview.setLayoutManager(mLayoutManager);

        btnSubmit.setOnClickListener(this);
        getData();
        realtimeUpdate();
    }

    public void deleteData(String key) {
        db.collection("users").document(key)
                .delete()
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d(TAG, "DocumentSnapshot successfully deleted!");
                        getData();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Error deleting document", e);
                    }
                });
    }


    public void addData() {

        Map<String, Object> user = new HashMap<>();
        user.put(Constant.FIRSTNAME, editFname.getText().toString().trim());
        user.put(Constant.LASTNAME, editLname.getText().toString().trim());
        user.put(Constant.FATHERNAME, editFathername.getText().toString().trim());
        user.put(Constant.EMAIL, editemail.getText().toString().trim());


        db.collection("users")
                .add(user)
                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference) {
                        Log.d(TAG, "DocumentSnapshot added with ID: " + documentReference.getId());
                        getData();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Error adding document", e);
                    }
                });


      /*  //update any document
        Map<String, Object> city = new HashMap<>();
        city.put("name", "Los Angeles");
        city.put("state", "CA");
        city.put("country", "USA");

        db.collection("users").document("123")
                .set(city)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d(TAG, "DocumentSnapshot successfully written!");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Error writing document", e);
                    }
                });*/

    }

    public void setdata() {
        if (adapter == null) {
            adapter = new FireStoreAdepter(FireStoreActivity.this, fierStoreModelArrayList);
            recycleview.setAdapter(adapter);
        } else {
            adapter.notifyDataSetChanged();
        }

    }

    public void realtimeUpdate(){
        CollectionReference docRef = db.collection("users");

        docRef.addSnapshotListener(new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@javax.annotation.Nullable QuerySnapshot queryDocumentSnapshots, @javax.annotation.Nullable FirebaseFirestoreException e) {
                Log.d(TAG, "onEvent() called with: queryDocumentSnapshots = [" + queryDocumentSnapshots + "], e = [" + e + "]");


            }
        });




    }

    public void getData() {

        db.collection("users")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            fierStoreModelArrayList.clear();
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                Log.d(TAG, document.getId() + " => " + document.getData());
                                FierStoreModel fierStoreModel = new FierStoreModel();
                                fierStoreModel.setEmail(document.getData().get(Constant.EMAIL).toString());
                                fierStoreModel.setFirstname(document.getData().get(Constant.FIRSTNAME).toString());
                                fierStoreModel.setLastname(document.getData().get(Constant.LASTNAME).toString());
                                fierStoreModel.setFathername(document.getData().get(Constant.FATHERNAME).toString());
                                fierStoreModel.setKey(document.getId());
                                fierStoreModelArrayList.add(fierStoreModel);
                            }
                            setdata();
                        } else {
                            Log.d(TAG, "Error getting documents: ", task.getException());
                        }
                    }
                });

    }

    @Override
    public void onClick(View view) {
        if (view == btnSubmit) {
            addData();
        }
    }
}
