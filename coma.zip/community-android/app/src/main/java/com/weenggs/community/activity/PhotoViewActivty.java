package com.weenggs.community.activity;

import android.content.Context;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.OrientationEventListener;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;

import com.github.chrisbanes.photoview.PhotoView;
import com.github.vivchar.viewpagerindicator.ViewPagerIndicator;
import com.squareup.picasso.Picasso;
import com.weenggs.community.R;
import com.weenggs.community.model.MediaData;
import com.weenggs.community.util.Constant;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

public class PhotoViewActivty extends BaseActivity {

    public static Context context;
    public ArrayList<MediaData> Detail;
    ImageView cancel;
    ViewPager mPager;
    MyPagerAdapter myPagerAdapter;
    WindowManager mWindowManager;
    RelativeLayout topLayout;
    ViewPagerIndicator viewPagerIndicator;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.zoom_photo_screen);
        context = this;

        if (Constant.mediaDataArrayList != null) {
            Detail = Constant.mediaDataArrayList;
        }

        mPager = findViewById(R.id.pager);
        mPager.setOffscreenPageLimit(1);

        topLayout = findViewById(R.id.topLayout);
        viewPagerIndicator = findViewById(R.id.view_pager_indicator);

        cancel = findViewById(R.id.cancel);
        cancel.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                onBackPressed();
            }
        });
        mPager.addOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener() {

            // optional
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
            }

            // optional
            @Override
            public void onPageSelected(int position) {

            }

            // optional
            @Override
            public void onPageScrollStateChanged(int state) {
            }
        });


        loaddata();

        mWindowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        OrientationEventListener orientationEventListener = new OrientationEventListener(this,
                SensorManager.SENSOR_DELAY_NORMAL) {
            @Override
            public void onOrientationChanged(int orientation) {

            }
        };
        if (orientationEventListener.canDetectOrientation()) {
            orientationEventListener.enable();
        }
    }


    @Override
    public void onBackPressed() {
        setResult(102);
        finish();
    }

    public void loaddata() {

        ArrayList<MediaData> image_array = null;
        try {
            image_array = Detail;
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        if (image_array != null) {
            myPagerAdapter = new MyPagerAdapter(image_array);
            mPager.setAdapter(myPagerAdapter);
            mPager.setCurrentItem(0);
            viewPagerIndicator.setupWithViewPager(mPager);


            @NonNull final ViewPager.OnPageChangeListener mOnPageChangeListener = new ViewPager.OnPageChangeListener() {
                @Override
                public void onPageScrolled(final int position, final float positionOffset, final int positionOffsetPixels) {

                }

                @Override
                public void onPageSelected(final int position) {
                }

                @Override
                public void onPageScrollStateChanged(final int state) {

                }
            };
            viewPagerIndicator.addOnPageChangeListener(mOnPageChangeListener);
        }
    }


    private class MyPagerAdapter extends PagerAdapter {
        ArrayList<MediaData> mdata;

        @SuppressWarnings("unused")
        public MyPagerAdapter(ArrayList<MediaData> mdat) {
            // TODO Auto-generated constructor stub
            mdata = mdat;
        }

        public void refresAdapter(ArrayList<MediaData> data) {

            mdata = data;
            notifyDataSetChanged();
        }

        @Override
        public int getCount() {
            return mdata.size();
        }

        @Override
        public boolean isViewFromObject(View view, Object object) {
            return view == object;
        }

        @Override
        public Object instantiateItem(ViewGroup container1, int position) {

            final ViewHolderNotification holder = new ViewHolderNotification();

            View container;

//				if (container == null) {
            container = getLayoutInflater().inflate(R.layout.detail_photo, null);
            holder.product_img = container.findViewById(R.id.product_img);


            holder.progressBar_image = container.findViewById(R.id.progressBar);
            container.setTag(R.layout.detail, holder);

            container.setTag(position);
            final ViewHolderNotification holder1 = holder;


            final MediaData horizontalList = mdata.get(position);

            Picasso.with(PhotoViewActivty.this).load(Constant.BASE_IMAGE_URL + horizontalList.getMedia()).noFade().into(holder1.product_img, new com.squareup.picasso.Callback() {
                @Override
                public void onSuccess() {
                    holder1.progressBar_image.setVisibility(View.GONE);
                }

                @Override
                public void onError() {
                    holder1.progressBar_image.setVisibility(View.GONE);
                }
            });


            container1.addView(container);

            return container;
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            container.removeView((RelativeLayout) object);
        }

        class ViewHolderNotification {

            PhotoView product_img;
            ProgressBar progressBar_image;

        }

    }


}