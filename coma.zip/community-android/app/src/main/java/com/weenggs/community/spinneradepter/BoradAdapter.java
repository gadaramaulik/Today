package com.weenggs.community.spinneradepter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.weenggs.community.R;
import com.weenggs.community.model.StandardData;

import java.util.ArrayList;

public class BoradAdapter extends BaseAdapter {
    private Context mContext;
    ArrayList<StandardData> data;

    public BoradAdapter(Context c, ArrayList<StandardData> data) {
        this.mContext = c;
        this.data = data;
    }

    public synchronized void refresAdapter(ArrayList<StandardData> data) {
        this.data.clear();

        this.data.addAll(data);
//		this.mdata = new ArrayList<Request_dictionary>(pendingrequest);
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        // TODO Auto-generated method stub
        return data.size();
//        return 10;
    }

    @Override
    public Object getItem(int position) {
        // TODO Auto-generated method stub
        return this.data.get(position);
    }

    @Override
    public long getItemId(int position) {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        // TODO Auto-generated method stub

        final ViewHolder holder;
        LayoutInflater mInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.dialog_row, null);
            holder = new ViewHolder();
            holder.txtname = convertView.findViewById(R.id.txtname);
            convertView.setTag(holder);

        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        try {
            holder.txtname.setText(""+data.get(position).getTitle());
        } catch (Exception e) {
            e.printStackTrace();
        }



        return convertView;
    }

    static class ViewHolder {
         TextView txtname;
    }

}