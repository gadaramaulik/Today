package com.weenggs.community.retrofit;


import com.weenggs.community.model.CategoryResponce;
import com.weenggs.community.model.CommitteeMemberResponce;
import com.weenggs.community.model.LoginResponce;
import com.weenggs.community.model.MarkSheetListResponce;
import com.weenggs.community.model.PostResponce;
import com.weenggs.community.model.StandardMediumResponce;

import java.util.List;
import java.util.Map;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.FieldMap;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;

/**
 * Created by iweenggs on 24/03/17.
 */

public interface APIService {


    String login = "service/login";
    String signup = "service/signup";
    String get_user_detail = "service/get_user_profile";
    String member_add_edit = "service/member_add_edit";
    String add_marksheet = "service/upload_marksheet";
    String news_post = "service/news_post";
    String news_post_edit = "service/news_post_edit";
    String news_image_delete = "service/news_image_delete";
    String news_delete = "service/news_delete";
    String get_category = "service/get_category";
    String check_phone_no = "service/check_phone_no";
    String approved_pending = "service/approved_pending";
    String get_committee_member = "service/get_commitee_member_list";
    String news_list = "service/news_list";
    String news_post_list = "service/news_post_list";
    String get_member_list = "service/get_member_list";
    String user_wise_marksheet_list = "service/user_wise_marksheet_list";
    String get_standard_medium = "service/get_standard_medium";

    @FormUrlEncoded
    @POST(login)
    Call<LoginResponce> login_user(@FieldMap Map<String, String> params);

    @FormUrlEncoded
    @POST(news_image_delete)
    Call<LoginResponce> news_image_delete(@FieldMap Map<String, String> params);


    @FormUrlEncoded
    @POST(news_delete)
    Call<LoginResponce> news_delete(@FieldMap Map<String, String> params);

    @FormUrlEncoded
    @POST(get_user_detail)
    Call<LoginResponce> get_user_detail(@FieldMap Map<String, String> params);

    @FormUrlEncoded
    @POST(get_category)
    Call<CategoryResponce> get_category(@FieldMap Map<String, String> params);

    @FormUrlEncoded
    @POST(check_phone_no)
    Call<LoginResponce> check_phone_no(@FieldMap Map<String, String> params);

    @FormUrlEncoded
    @POST(approved_pending)
    Call<LoginResponce> approved_pending(@FieldMap Map<String, String> params);

    @FormUrlEncoded
    @POST(get_committee_member)
    Call<CommitteeMemberResponce> get_committee_member(@FieldMap Map<String, String> params);

    @FormUrlEncoded
    @POST(news_list)
    Call<PostResponce> news_list(@FieldMap Map<String, String> params);

    @FormUrlEncoded
    @POST(news_post_list)
    Call<PostResponce> news_post_list(@FieldMap Map<String, String> params);

    @FormUrlEncoded
    @POST(get_member_list)
    Call<CommitteeMemberResponce> get_member_list(@FieldMap Map<String, String> params);

    @FormUrlEncoded
    @POST(user_wise_marksheet_list)
    Call<MarkSheetListResponce> user_wise_marksheet_list(@FieldMap Map<String, String> params);

   @FormUrlEncoded
    @POST(get_standard_medium)
    Call<StandardMediumResponce> get_standard(@FieldMap Map<String, String> params);


    @Multipart
    @POST(signup)
    Call<LoginResponce> add_member(@Part("relation_ship") RequestBody relation_ship,
                                   @Part("first_name") RequestBody first_name,
                                   @Part("father_name") RequestBody father_name,
                                   @Part("surname") RequestBody surname,
                                   @Part("gender") RequestBody gender,
                                   @Part("date_of_birth") RequestBody date_of_birth,
                                   @Part("address") RequestBody address,
                                   @Part("phone_number") RequestBody phone_number,
                                   @Part("business_categroy_id") RequestBody business_categroy_id,
                                   @Part("business_or_job_or_any") RequestBody business_or_job_or_any,
                                   @Part("business_details") RequestBody business_details,
                                   @Part("education") RequestBody education,
                                   @Part("blood_group") RequestBody blood_group,
                                   @Part("marital_status") RequestBody marital_status,
                                   @Part("password") RequestBody password,
                                   @Part("number_of_members") RequestBody number_of_members,
                                   @Part("email_id") RequestBody email_id,
                                   @Part("profile_image\"; filename=\"job_profile_pic7.jpg\" ") RequestBody image_url,
                                   @Part("id_proof\"; filename=\"job_profile_pic7.jpg\" ") RequestBody proof);

    @Multipart
    @POST(member_add_edit)
    Call<LoginResponce> member_add_edit(@Part("relation_ship") RequestBody relation_ship,
                                        @Part("members_id") RequestBody members_id,
                                        @Part("family_sr_id") RequestBody family_sr_id,
                                        @Part("user_id") RequestBody user_id,
                                        @Part("first_name") RequestBody first_name,
                                        @Part("father_name") RequestBody father_name,
                                        @Part("surname") RequestBody surname,
                                        @Part("gender") RequestBody gender,
                                        @Part("date_of_birth") RequestBody date_of_birth,
                                        @Part("address") RequestBody address,
                                        @Part("phone_number") RequestBody phone_number,
                                        @Part("business_categroy_id") RequestBody business_categroy_id,
                                        @Part("business_or_job_or_any") RequestBody business_or_job_or_any,
                                        @Part("business_details") RequestBody business_details,
                                        @Part("education") RequestBody education,
                                        @Part("blood_group") RequestBody blood_group,
                                        @Part("marital_status") RequestBody marital_status,
                                        @Part("email_id") RequestBody email_id,
                                        @Part("profile_image\"; filename=\"job_profile_pic7.jpg\" ") RequestBody image_url,
                                        @Part("id_proof\"; filename=\"job_profile_pic7.jpg\" ") RequestBody proof);


    @Multipart
    @POST(add_marksheet)
    Call<LoginResponce> add_marksheet(@Part("user_id") RequestBody user_id,
                                      @Part("members_id") RequestBody members_id,
                                      @Part("standard_id") RequestBody standard_id,
                                      @Part("medium_id") RequestBody medium_id,
                                      @Part("percentage") RequestBody percentage,
                                      @Part("grade_id") RequestBody grade_id,
                                      @Part("bu_id") RequestBody bu_id,
                                      @Part("years") RequestBody years,
                                      @Part("marksheet_image\"; filename=\"job_profile_pic7.jpg\" ") RequestBody proof);


    @Multipart
    @POST(add_marksheet)
    Call<LoginResponce> edit_marksheet(@Part("marksheet_id") RequestBody marksheet_id, @Part("user_id") RequestBody user_id,
                                       @Part("members_id") RequestBody members_id,
                                       @Part("standard_id") RequestBody standard_id,
                                       @Part("medium_id") RequestBody medium_id,
                                       @Part("percentage") RequestBody percentage,
                                       @Part("grade_id") RequestBody grade_id,
                                       @Part("bu_id") RequestBody bu_id,
                                       @Part("years") RequestBody years,
                                       @Part("marksheet_image\"; filename=\"job_profile_pic7.jpg\" ") RequestBody proof);


    @Multipart
    @POST(news_post)
    Call<LoginResponce> add_post(@Part("user_id") RequestBody user_id,
                                 @Part("members_id") RequestBody members_id,
                                 @Part("title") RequestBody title,
                                 @Part("description") RequestBody description,
                                 @Part("media_type") RequestBody media_type,
                                 @Part("video_thumb\"; filename=\"job_profile_pic7.jpg\" ") RequestBody video_thumb,
                                 @Part("media\"; filename=\"job_profile_pic7.jpg\" ") RequestBody media,
                                 @Part List<MultipartBody.Part> files);


    @Multipart
    @POST(news_post_edit)
    Call<LoginResponce> edit_post(@Part("news_id") RequestBody news_id,
                                  @Part("user_id") RequestBody user_id,
                                  @Part("members_id") RequestBody members_id,
                                  @Part("title") RequestBody title,
                                  @Part("description") RequestBody description,
                                  @Part("media_type") RequestBody media_type,
                                  @Part("video_thumb\"; filename=\"job_profile_pic7.jpg\" ") RequestBody video_thumb,
                                  @Part("media\"; filename=\"job_profile_pic7.jpg\" ") RequestBody media,
                                  @Part List<MultipartBody.Part> files);









}
