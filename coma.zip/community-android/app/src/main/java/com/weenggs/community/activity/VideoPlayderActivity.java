package com.weenggs.community.activity;

import android.os.Bundle;

import com.khizar1556.mkvideoplayer.MKPlayer;
import com.weenggs.community.R;

import androidx.annotation.Nullable;

public class VideoPlayderActivity extends BaseActivity {

    String url = "";
    MKPlayer mkplayer;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.video_player_activity);
        url = getIntent().getStringExtra("url");
        mkplayer = new MKPlayer(this);
        mkplayer.play(url);
        mkplayer.setPlayerCallbacks(new MKPlayer.playerCallbacks() {
            @Override
            public void onNextClick() {
                //It is the method for next song.It is called when you pressed the next icon
                //Do according to your requirement
            }

            @Override
            public void onPreviousClick() {
                //It is the method for previous song.It is called when you pressed the previous icon
                //Do according to your requirement
            }
        });
    }

    @Override
    public void onBackPressed() {
        if (mkplayer != null)
            mkplayer.stop();
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (mkplayer != null)
            mkplayer.stop();
        super.onDestroy();
    }
}
