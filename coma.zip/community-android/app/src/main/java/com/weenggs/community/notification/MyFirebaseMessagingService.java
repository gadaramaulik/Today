package com.weenggs.community.notification;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import com.weenggs.community.activity.LoginActivity;

import org.json.JSONObject;

import java.util.Map;

import androidx.annotation.RequiresApi;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

public class MyFirebaseMessagingService extends FirebaseMessagingService {

    private static final String TAG = MyFirebaseMessagingService.class.getSimpleName();

    private NotificationUtils notificationUtils;

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        Log.e(TAG, "From: " + remoteMessage.getFrom());

        if (remoteMessage == null)
            return;

        try {
            if (remoteMessage.getData().size() > 0) {
                Bundle extras = new Bundle();
                for (Map.Entry<String, String> entry : remoteMessage.getData().entrySet()) {
                    extras.putString(entry.getKey(), entry.getValue());
                }

                if (remoteMessage.getNotification() != null) {
                    Log.e(TAG, "Notification Body: " + remoteMessage.getNotification().getBody());
                    handleNotification(remoteMessage.getNotification().getBody());
                }

                // Check if message contains a data payload.
                if (remoteMessage.getData().size() > 0) {
                    Log.e(TAG, "Data Payload: " + remoteMessage.getData().toString());

                    try {
                        JSONObject json = null;
                        try {
                            String ss = remoteMessage.getData().toString();
                            Log.d(TAG, "msg " + remoteMessage.getData().toString() + "]");
                            json = new JSONObject(remoteMessage.getData().toString());
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        handleDataMessage(json, remoteMessage.getData());
                    } catch (Exception e) {
                        Log.e(TAG, "Exception: " + e.getMessage());
                    }
                }
            }
            //}
        } catch (Throwable t) {
            Log.d("MYFCMLIST", "Error parsing FCM message", t);
        }


    }

    private void handleNotification(String message) {
        if (!NotificationUtils.isAppIsInBackground(getApplicationContext())) {
            // app is in foreground, broadcast the push message
            Intent pushNotification = new Intent("pushNotification");
            pushNotification.putExtra("message", message);
            LocalBroadcastManager.getInstance(this).sendBroadcast(pushNotification);

            // play notification sound
            NotificationUtils notificationUtils = new NotificationUtils(getApplicationContext());
            notificationUtils.playNotificationSound();
        } else {
            // If the app is in background, firebase itself handles the notification
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void handleDataMessage(JSONObject json, Map<String, String> dataHash) {

        try {
            String title = "";
            try {
                title = dataHash.get("title");
            } catch (Exception e) {
                e.printStackTrace();
            }

            String extra = "";
            try {
                extra = dataHash.get("extra");
                extra = extra.replace("[", "");
                extra = extra.replace("]", "");
            } catch (Exception e) {
                e.printStackTrace();
            }
            String module_id = "";
            String item_id = "";
            if (!extra.equalsIgnoreCase("")) {
                String[] data = extra.split(",");
                module_id = data[0];
                item_id = data[1];

            }


            String message = "";
            try {
                message = dataHash.get("message");
                if (message == null) {
                    message = "";
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (title.equalsIgnoreCase("")) {
                title = message;
                message = "";
            }
//            boolean isBackground = false;
            String imageUrl = "";
            String timestamp = "" + System.currentTimeMillis();

            {
                Intent resultIntent = new Intent(getApplicationContext(), LoginActivity.class);

                if (TextUtils.isEmpty(imageUrl)) {
                    showNotificationMessage(getApplicationContext(), title, message, timestamp, resultIntent);
                } else {
                    // image is present, show notification with image
                    showNotificationMessageWithBigImage(getApplicationContext(), title, message, timestamp, resultIntent, imageUrl);
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Json Exception: " + e.getMessage());
        }
    }


    /**
     * Showing notification with text only
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    private void showNotificationMessage(Context context, String title, String message, String timeStamp, Intent intent) {
        notificationUtils = new NotificationUtils(context);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        notificationUtils.showNotificationMessage(title, message, timeStamp, intent);
    }

    /**
     * Showing notification with text and image
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    private void showNotificationMessageWithBigImage(Context context, String title, String message, String timeStamp, Intent intent, String imageUrl) {
        notificationUtils = new NotificationUtils(context);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        notificationUtils.showNotificationMessage(title, message, timeStamp, intent, imageUrl);
    }
}
