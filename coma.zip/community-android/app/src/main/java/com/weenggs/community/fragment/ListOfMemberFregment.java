package com.weenggs.community.fragment;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.weenggs.community.R;
import com.weenggs.community.activity.RegistationActivity;
import com.weenggs.community.spinneradepter.MemberAdepter;
import com.weenggs.community.model.CommitteeMemberResponce;
import com.weenggs.community.model.LoginUserFamilyMemberInfo;
import com.weenggs.community.util.Constant;
import com.weenggs.community.widget.DTextView;

import java.util.ArrayList;
import java.util.HashMap;

import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.app.Activity.RESULT_OK;

public class ListOfMemberFregment extends BaseFragment implements View.OnClickListener {

    private RecyclerView recycleview;
    LinearLayoutManager mLayoutManager;
    ArrayList<LoginUserFamilyMemberInfo> memberDataArrayList;
    MemberAdepter adapter;
    DTextView btnaddnew;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.committee_member_fragment, container, false);

        findViews(view);
        getCommiteeMember();
        //if (Constant.familyMemberDataArrayList == null) {
        //
        //} else {
        //    setPost();
        //}

        return view;
    }

    private void findViews(View view) {
        recycleview = (RecyclerView) view.findViewById(R.id.recycleview);
        btnaddnew = view.findViewById(R.id.btnaddnew);
        recycleview.addItemDecoration(new DividerItemDecoration(recycleview.getContext(), DividerItemDecoration.VERTICAL));

        mLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        recycleview.setLayoutManager(mLayoutManager);
        btnaddnew.setVisibility(View.VISIBLE);
        btnaddnew.setOnClickListener(this);

    }

    public void setMember() {
        memberDataArrayList = new ArrayList<>();
        memberDataArrayList.addAll(Constant.familyMemberDataArrayList);
        adapter = new MemberAdepter(ListOfMemberFregment.this, memberDataArrayList);
        recycleview.setAdapter(adapter);

    }

    public void editMember(LoginUserFamilyMemberInfo data) {
        Constant.committeeMemberData = data;
        Intent intent = new Intent(getActivity(), RegistationActivity.class);
        intent.putExtra(Constant.EDITMEMBER, true);
        intent.putExtra(Constant.ADDUPDATEMEMBER, true);
        ((Activity) context).startActivityForResult(intent, 10);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 10 && resultCode == RESULT_OK) {
            getCommiteeMember();
        }
    }


    public void getCommiteeMember() {

           startprogressdialog(getActivity());
        HashMap<String, String> dataParams = new HashMap<>();
        dataParams.put("user_id", data.getMemberInfo().get(0).getUser_id());
        mAPIService.get_member_list(dataParams).enqueue(new Callback<CommitteeMemberResponce>() {
            @Override
            public void onResponse(Call<CommitteeMemberResponce> call, Response<CommitteeMemberResponce> response) {
                stopprogressdialog();
                if (response.isSuccessful()) {
                    //Toast.makeText(getActivity(), response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    if (response.body().getSuccess().equalsIgnoreCase("1")) {
                        Constant.familyMemberDataArrayList = response.body().getData();
                        setMember();
                    }
                }
            }

            @Override
            public void onFailure(Call<CommitteeMemberResponce> call, Throwable t) {
                stopprogressdialog();
                Constant.ErrorMessage(getActivity(), t);
            }
        });
    }

    @Override
    public void onClick(View view) {
        if (view == btnaddnew) {
            Intent intent = new Intent(getActivity(), RegistationActivity.class);
            intent.putExtra(Constant.ADDUPDATEMEMBER, true);
            intent.putExtra(Constant.EDITMEMBER, false);
            ((Activity) context).startActivityForResult(intent, 10);
        }
    }
}
