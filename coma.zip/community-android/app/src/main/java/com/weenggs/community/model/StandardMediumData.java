package com.weenggs.community.model;

import java.util.ArrayList;

public class StandardMediumData {

    ArrayList<StandardData> standardData;
    ArrayList<StandardData> boardData;
    ArrayList<StandardData> mediumData;
    ArrayList<StandardData> gradeData;

    public ArrayList<StandardData> getGradeData() {
        return gradeData;
    }

    public void setGradeData(ArrayList<StandardData> gradeData) {
        this.gradeData = gradeData;
    }

    public ArrayList<StandardData> getStandardData() {
        return standardData;
    }

    public void setStandardData(ArrayList<StandardData> standardData) {
        this.standardData = standardData;
    }

    public ArrayList<StandardData> getBoardData() {
        return boardData;
    }

    public void setBoardData(ArrayList<StandardData> boardData) {
        this.boardData = boardData;
    }

    public ArrayList<StandardData> getMediumData() {
        return mediumData;
    }

    public void setMediumData(ArrayList<StandardData> mediumData) {
        this.mediumData = mediumData;
    }
}
