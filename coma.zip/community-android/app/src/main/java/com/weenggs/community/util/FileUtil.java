package com.weenggs.community.util;

import android.content.Context;
import android.os.Environment;
import android.text.TextUtils;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class FileUtil {
    private static final String TAG = "TAG FileUtil";

    public static String getFolderName(Context context, String folderName) {
//        File filepath = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), name);

//        File filepath = new File(Environment.getExternalStorageDirectory().getPath() + File.separator + folderName);
        File filepath = new File(context.getFilesDir().getAbsolutePath() + File.separator + folderName);

        if (!filepath.exists()) {
            if (!filepath.mkdirs()) {
                return filepath.getAbsolutePath();
            }
        }
        return filepath.getAbsolutePath();
    }

    public static boolean isSDAvailable() {
        return Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED);
    }

    public static File getNewFile(Context context, String folderName) {

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault());
        String timeStamp = simpleDateFormat.format(new Date());
//        long timeStamp = new Date().getTime();

        String path;
//        if (isSDAvailable()) {
//            path = getFolderName(folderName) + File.separator  + timeStamp + ".jpg";
//        } else {
//        path = context.getFilesDir().getPath() + File.separator + folderName + File.separator + timeStamp + ".jpg";
        path = getFolderName(context, folderName) + File.separator + "IMG_" + timeStamp + ".jpg";
//        }

        if (TextUtils.isEmpty(path)) {
            return null;
        }

        return new File(path);
    }
}
