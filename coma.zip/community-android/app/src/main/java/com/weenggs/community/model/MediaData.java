package com.weenggs.community.model;

public class MediaData {
    private String news_image_id;
    private String media;
    private String news_id;

    public String getMedia() {
        return media;
    }

    public void setMedia(String media) {
        this.media = media;
    }

    public String getNews_id() {
        return news_id;
    }

    public void setNews_id(String news_id) {
        this.news_id = news_id;
    }

    public String getNews_image_id() {
        return news_image_id;
    }

    public void setNews_image_id(String news_image_id) {
        this.news_image_id = news_image_id;
    }
}
