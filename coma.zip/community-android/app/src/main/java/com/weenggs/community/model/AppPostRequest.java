package com.weenggs.community.model;

import java.util.List;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;

public class AppPostRequest {

    private RequestBody user_id;
    private RequestBody members_id;
    private RequestBody title;
    private RequestBody description;
    private RequestBody media_type;
    private RequestBody video_thumb;
    private RequestBody news_id;
    private RequestBody media;
    private List<MultipartBody.Part> files;

    public RequestBody getNews_id() {
        return news_id;
    }

    public void setNews_id(RequestBody news_id) {
        this.news_id = news_id;
    }

    public RequestBody getMedia() {
        return media;
    }

    public void setMedia(RequestBody media) {
        this.media = media;
    }

    public RequestBody getVideo_thumb() {
        return video_thumb;
    }

    public void setVideo_thumb(RequestBody video_thumb) {
        this.video_thumb = video_thumb;
    }

    public RequestBody getMedia_type() {
        return media_type;
    }

    public void setMedia_type(RequestBody media_type) {
        this.media_type = media_type;
    }

    public RequestBody getUser_id() {
        return user_id;
    }

    public void setUser_id(RequestBody user_id) {
        this.user_id = user_id;
    }

    public RequestBody getMembers_id() {
        return members_id;
    }

    public void setMembers_id(RequestBody members_id) {
        this.members_id = members_id;
    }

    public RequestBody getTitle() {
        return title;
    }

    public void setTitle(RequestBody title) {
        this.title = title;
    }

    public RequestBody getDescription() {
        return description;
    }

    public void setDescription(RequestBody description) {
        this.description = description;
    }

    public List<MultipartBody.Part> getFiles() {
        return files;
    }

    public void setFiles(List<MultipartBody.Part> files) {
        this.files = files;
    }
}
