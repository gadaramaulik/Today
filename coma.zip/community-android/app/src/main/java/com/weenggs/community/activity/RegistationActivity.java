package com.weenggs.community.activity;

import android.Manifest;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.weenggs.community.R;
import com.weenggs.community.spinneradepter.DialogAdapter;
import com.weenggs.community.spinneradepter.DialogReletionAdapter;
import com.weenggs.community.camera.CameraActivity;
import com.weenggs.community.model.CategoryData;
import com.weenggs.community.model.CategoryResponce;
import com.weenggs.community.model.LoginResponce;
import com.weenggs.community.model.LoginUserFamilyMemberInfo;
import com.weenggs.community.model.RegistationMemberRequest;
import com.weenggs.community.util.Constant;
import com.weenggs.community.widget.DEditText;
import com.weenggs.community.widget.DTextView;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.widget.NestedScrollView;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RegistationActivity extends BaseActivity implements View.OnClickListener {

    private RelativeLayout topLayout;
    private ImageView cancel;
    private DTextView textTitle;
    private NestedScrollView scrollview;
    private LinearLayout layoutDetail, layoutReletion;
    private DEditText editFname;
    private DEditText editLname;
    private DEditText editFathername;
    private DTextView editDOB;
    private DEditText editAddress;
    private DEditText editPhonenumber;
    private DEditText editNumberOfMember;
    private Spinner spinnerBusinessCategroy, spinnereletionShip;
    private DTextView txtBusinessCategroy;
    private RadioGroup rgBusinessType;
    private RadioButton rbbusiness;
    private RadioButton rbFemale;
    private RadioButton rbMale;
    private RadioButton rbjob;
    private RadioButton rbother;
    private DEditText editBusinessDetail;
    private DEditText txtStandard;
    private DEditText editEmail;
    private RadioGroup rgMaritalStatus;
    private RadioButton rbsingle;
    private RadioButton rbmarried;
    private RadioGroup rgBloodGroupP;
    private RadioButton rbAp;
    private RadioButton rbBp;
    private RadioButton rbABp;
    private RadioButton rbOp;
    private RadioGroup rgBloodGroupM;
    private RadioButton rbAm;
    private RadioButton rbBm;
    private RadioButton rbABm;
    private RadioButton rbOm;
    private DTextView btnUploadProfilePic, btnSubmit;
    private ImageView imagProfilePic;
    private DTextView btnIdProof, txtreletionShip;
    private ImageView imagIdProof;

    public static final int PICK_CAMERA = 1;
    public static final int PICK_PHOTO_FOR_AVATAR = 0;


    Bitmap bitmap;
    String selectedImagePath;
    String selectedPicImagepath;
    String selectedProofImagepath;
    int selectedReletionShipPosition = 0;

    boolean isClickProof = false;
    boolean isClickProfileId = false;

    CategoryData selectedCategoryData;

    ArrayList<CategoryData> categoryArrayList;

    private DatePickerDialog dobDatePickerDialog;

    private SimpleDateFormat dateFormatter;

    LinearLayout layoutNumberOfMember;

    String mobile_no = "";
    String password = "";
    boolean editMember;
    boolean addUpdateMember;
    boolean verifyMember;
    String number_of_member = "";
    String[] reletionArray;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registation_activity);

        mobile_no = getIntent().getStringExtra(Constant.MOBILE_NO);
        password = getIntent().getStringExtra(Constant.PASSWORD);
        number_of_member = getIntent().getStringExtra(Constant.NUMBEROFMEMBER);
        editMember = getIntent().getBooleanExtra(Constant.EDITMEMBER, false);
        addUpdateMember = getIntent().getBooleanExtra(Constant.ADDUPDATEMEMBER, false);
        verifyMember = getIntent().getBooleanExtra(Constant.VERIFIYMEMBER, false);

        findViews();

        if (pref.getBoolean(Constant.ISGUJARATI, false)) {
            reletionArray = Constant.reletion_guj;
        } else {
            reletionArray = Constant.reletion_eng;
        }

        if (Constant.categoryDataArrayList == null) {
            getCategory();
        } else {
            setCategory();
        }

        if (addUpdateMember && editMember) {
            txtTitle.setText("Edit Member");
            setMemberData(Constant.committeeMemberData);

        } else if (addUpdateMember) {
            txtTitle.setText("Add Member");

        }
        if (number_of_member != null) {
            editNumberOfMember.setText(number_of_member);
            layoutReletion.setVisibility(View.GONE);
        }

        layoutNumberOfMember.setVisibility(View.GONE);
    }

    private void setDOBDateTimeField() {

        Calendar newCalendar = Calendar.getInstance();
        dobDatePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {

            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                Calendar newDate = Calendar.getInstance();
                newDate.set(year, monthOfYear, dayOfMonth);
                editDOB.setText(dateFormatter.format(newDate.getTime()));
            }

        }, newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH), newCalendar.get(Calendar.DAY_OF_MONTH));

    }

    private void findViews() {
        dateFormatter = new SimpleDateFormat("yyyy/MM/dd", Locale.US);
        topLayout = findViewById(R.id.topLayout);
        cancel = findViewById(R.id.cancel);

        btnSubmit = findViewById(R.id.btnSubmit);
        txtTitle = findViewById(R.id.txtTitle);
        scrollview = findViewById(R.id.scrollview);
        layoutDetail = findViewById(R.id.layoutDetail);
        layoutReletion = findViewById(R.id.layoutReletion);
        editFname = findViewById(R.id.editFname);
        editLname = findViewById(R.id.editLname);
        editFathername = findViewById(R.id.editFathername);
        editDOB = findViewById(R.id.editDOB);
        editAddress = findViewById(R.id.editAddress);
        editPhonenumber = findViewById(R.id.editPhonenumber);
        editNumberOfMember = findViewById(R.id.editNumberOfMember);
        spinnerBusinessCategroy = findViewById(R.id.spinnerBusinessCategroy);
        txtBusinessCategroy = findViewById(R.id.txtBusinessCategroy);
        rgBusinessType = findViewById(R.id.rgBusinessType);
        layoutNumberOfMember = findViewById(R.id.layoutNumberOfMember);
        rbbusiness = findViewById(R.id.rbbusiness);
        rbFemale = findViewById(R.id.rbFemale);
        rbMale = findViewById(R.id.rbMale);
        rbjob = findViewById(R.id.rbjob);
        rbother = findViewById(R.id.rbother);
        editBusinessDetail = findViewById(R.id.editBusinessDetail);
        txtStandard = findViewById(R.id.txtStandard);
        editEmail = findViewById(R.id.editEmail);
        rgMaritalStatus = findViewById(R.id.rgMaritalStatus);
        rbsingle = findViewById(R.id.rbsingle);
        rbmarried = findViewById(R.id.rbmarried);
        rgBloodGroupP = findViewById(R.id.rgBloodGroupP);
        rbAp = findViewById(R.id.rbAp);
        rbBp = findViewById(R.id.rbBp);
        rbABp = findViewById(R.id.rbABp);
        rbOp = findViewById(R.id.rbOp);
        rgBloodGroupM = findViewById(R.id.rgBloodGroupM);
        rbAm = findViewById(R.id.rbAm);
        rbBm = findViewById(R.id.rbBm);
        rbABm = findViewById(R.id.rbABm);
        rbOm = findViewById(R.id.rbOm);
        btnUploadProfilePic = findViewById(R.id.btnUploadProfilePic);
        imagProfilePic = findViewById(R.id.imagProfilePic);
        btnIdProof = findViewById(R.id.btnIdProof);
        txtreletionShip = findViewById(R.id.txtreletionShip);
        spinnereletionShip = findViewById(R.id.spinnereletionShip);
        imagIdProof = findViewById(R.id.imagIdProof);

        btnSubmit.setOnClickListener(this);
        btnIdProof.setOnClickListener(this);
        btnUploadProfilePic.setOnClickListener(this);
        txtBusinessCategroy.setOnClickListener(this);
        editDOB.setOnClickListener(this);
        cancel.setOnClickListener(this);
        txtreletionShip.setOnClickListener(this);

        rgBloodGroupM.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                if (i != -1)
                    rgBloodGroupP.check(-1);
            }
        });

        rbAp.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b) {
                    rgBloodGroupM.check(-1);
                }
            }
        });
        rbBp.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b) {
                    rgBloodGroupM.check(-1);
                }
            }
        });
        rbABp.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b) {
                    rgBloodGroupM.check(-1);
                }
            }
        });
        rbOp.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b) {
                    rgBloodGroupM.check(-1);
                }
            }
        });
        setDOBDateTimeField();
        if (mobile_no != null) {
            editPhonenumber.setText(mobile_no);
            editPhonenumber.setEnabled(false);
        }
    }


    @Override
    public void onClick(View v) {
        if (v == btnSubmit) {
            if (checkVelidation()) {
                AddMember();
                hideSoftKeyboard(RegistationActivity.this);
            }
        } else if (v == btnUploadProfilePic) {
            isClickProfileId = true;
            hideSoftKeyboard(RegistationActivity.this);
            ProfileimagesetDialog();
        } else if (v == btnIdProof) {
            isClickProfileId = false;
            isClickProof = true;
            hideSoftKeyboard(RegistationActivity.this);
            ProfileimagesetDialog();
        } else if (v == txtBusinessCategroy) {
            hideSoftKeyboard(RegistationActivity.this);
            spinnerBusinessCategroy.performClick();
        } else if (v == editDOB) {
            hideSoftKeyboard(RegistationActivity.this);
            dobDatePickerDialog.show();
        } else if (v == txtreletionShip) {
            hideSoftKeyboard(RegistationActivity.this);
            spinnereletionShip.performClick();
        } else if (v == cancel) {
            hideSoftKeyboard(RegistationActivity.this);
            onBackPressed();
        }
    }

    public void AddMember() {
        startprogressdialog(this);

        String selectedBloodGroup = "";
        if (checkBoxChecked(rbAp)) {
            selectedBloodGroup = "A+";
        } else if (checkBoxChecked(rbAm)) {
            selectedBloodGroup = "A-";
        } else if (checkBoxChecked(rbBp)) {
            selectedBloodGroup = "B+";
        } else if (checkBoxChecked(rbBm)) {
            selectedBloodGroup = "B-";
        } else if (checkBoxChecked(rbOp)) {
            selectedBloodGroup = "O+";
        } else if (checkBoxChecked(rbOm)) {
            selectedBloodGroup = "O-";
        } else if (checkBoxChecked(rbABp)) {
            selectedBloodGroup = "AB+";
        } else if (checkBoxChecked(rbABm)) {
            selectedBloodGroup = "AB-";
        }
        String selectedMaritalStatus = "";
        if (checkBoxChecked(rbmarried)) {
            selectedMaritalStatus = "1";
        } else if (checkBoxChecked(rbsingle)) {
            selectedMaritalStatus = "2";
        }

        String selectedBusinessOrJob = "";
        if (checkBoxChecked(rbbusiness)) {
            selectedBusinessOrJob = "business";
        } else if (checkBoxChecked(rbjob)) {
            selectedBusinessOrJob = "job";
        } else if (checkBoxChecked(rbother)) {
            selectedBusinessOrJob = "other";
        }

        String selectedGender = "";
        if (checkBoxChecked(rbMale)) {
            selectedGender = "1";
        } else if (checkBoxChecked(rbFemale)) {
            selectedGender = "2";
        }

        String selectedCategory = "";
        if (selectedCategoryData != null) {
            selectedCategory = selectedCategoryData.getCategory_id();
        }


        RegistationMemberRequest request = new RegistationMemberRequest();
        request.setFirst_name(RequestBody.create(MEDIA_TYPE_TEXT_PLAIN, editFname.getText().toString().trim()));
        request.setFather_name(RequestBody.create(MEDIA_TYPE_TEXT_PLAIN, editFathername.getText().toString()));
        request.setSurname(RequestBody.create(MEDIA_TYPE_TEXT_PLAIN, editLname.getText().toString().trim()));
        request.setGender(RequestBody.create(MEDIA_TYPE_TEXT_PLAIN, selectedGender));
        request.setDate_of_birth(RequestBody.create(MEDIA_TYPE_TEXT_PLAIN, editDOB.getText().toString().trim()));
        request.setAddress(RequestBody.create(MEDIA_TYPE_TEXT_PLAIN, editAddress.getText().toString().trim()));
        request.setBusiness_categroy_id(RequestBody.create(MEDIA_TYPE_TEXT_PLAIN, selectedCategory));
        request.setBusiness_or_job_or_any(RequestBody.create(MEDIA_TYPE_TEXT_PLAIN, selectedBusinessOrJob));
        request.setBusiness_details(RequestBody.create(MEDIA_TYPE_TEXT_PLAIN, editBusinessDetail.getText().toString().trim()));
        request.setEducation(RequestBody.create(MEDIA_TYPE_TEXT_PLAIN, txtStandard.getText().toString().trim()));
        request.setBlood_group(RequestBody.create(MEDIA_TYPE_TEXT_PLAIN, selectedBloodGroup));
        request.setMarital_status(RequestBody.create(MEDIA_TYPE_TEXT_PLAIN, selectedMaritalStatus));
        request.setEmail_id(RequestBody.create(MEDIA_TYPE_TEXT_PLAIN, editEmail.getText().toString().trim()));
        request.setPhone_number(RequestBody.create(MEDIA_TYPE_TEXT_PLAIN, editPhonenumber.getText().toString().trim()));
        request.setNumber_of_members(RequestBody.create(MEDIA_TYPE_TEXT_PLAIN, editNumberOfMember.getText().toString()));
        request.setRelation_ship(RequestBody.create(MEDIA_TYPE_TEXT_PLAIN, Constant.reletion_eng[selectedReletionShipPosition]));

        if (addUpdateMember) {
            request.setUser_id(RequestBody.create(MEDIA_TYPE_TEXT_PLAIN, data.getLogins().getProfileData().getUser_id()));
            request.setFamily_sr_id(RequestBody.create(MEDIA_TYPE_TEXT_PLAIN, data.getLogins().getProfileData().getFamily_sr_id()));
            if (editMember) {
                request.setMembers_id(RequestBody.create(MEDIA_TYPE_TEXT_PLAIN, Constant.committeeMemberData.getMembers_id()));
            }else {
                request.setMembers_id(RequestBody.create(MEDIA_TYPE_TEXT_PLAIN, ""));
            }
        } else {
            request.setRelation_ship(RequestBody.create(MEDIA_TYPE_TEXT_PLAIN, "Self"));
            request.setPassword(RequestBody.create(MEDIA_TYPE_TEXT_PLAIN, password));
        }
        if (selectedPicImagepath != null) {

            // File file1 = null;
//
            // Bitmap largeImage = Constant.saveLargeBitmap(BitmapFactory.decodeFile(selectedPicImagepath), selectedPicImagepath, this);
            // file1 = Constant.savePreviewBitmap(largeImage, this);

            request.setProfile_image(RequestBody.create(MEDIA_TYPE_FORM_DATA, new File(selectedPicImagepath)));
        }
        if (selectedProofImagepath != null) {
            // File file1 = null;
//
            // Bitmap largeImage = Constant.saveLargeBitmap(BitmapFactory.decodeFile(selectedProofImagepath), selectedProofImagepath, this);
            // file1 = Constant.savePreviewBitmap(largeImage, this);


            request.setId_proof(RequestBody.create(MEDIA_TYPE_FORM_DATA, new File(selectedProofImagepath)));
        }

        if (addUpdateMember) {
            mAPIService.member_add_edit(request.getRelation_ship(), request.getMembers_id(), request.getFamily_sr_id(), request.getUser_id(), request.getFirst_name(), request.getFather_name(), request.getSurname(), request.getGender(), request.getDate_of_birth(),
                    request.getAddress(), request.getPhone_number(), request.getBusiness_categroy_id(), request.getBusiness_or_job_or_any(), request.getBusiness_details(),
                    request.getEducation(), request.getBlood_group(), request.getMarital_status(), request.getEmail_id(), request.getProfile_image(), request.getId_proof()).enqueue(new Callback<LoginResponce>() {
                @Override
                public void onResponse(Call<LoginResponce> call, Response<LoginResponce> response) {
                    stopprogressdialog();
                    if (response.isSuccessful()) {
                        Toast.makeText(RegistationActivity.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();

                        if (response.body().getSuccess().equalsIgnoreCase("1")) {
                            if (verifyMember) {
                                Intent intent = new Intent(RegistationActivity.this, HomeActivity.class);
                                startActivity(intent);
                            } else {
                                setResult(RESULT_OK);
                            }
                            finish();
                        }

                    }
                }

                @Override
                public void onFailure(Call<LoginResponce> call, Throwable t) {
                    stopprogressdialog();
                    Constant.ErrorMessage(RegistationActivity.this, t);
                }
            });
        } else {
            mAPIService.add_member(request.getRelation_ship(), request.getFirst_name(), request.getFather_name(), request.getSurname(), request.getGender(), request.getDate_of_birth(),
                    request.getAddress(), request.getPhone_number(), request.getBusiness_categroy_id(), request.getBusiness_or_job_or_any(), request.getBusiness_details(),
                    request.getEducation(), request.getBlood_group(), request.getMarital_status(), request.getPassword(), request.getNumber_of_members(), request.getEmail_id(), request.getProfile_image(), request.getId_proof()).enqueue(new Callback<LoginResponce>() {
                @Override
                public void onResponse(Call<LoginResponce> call, Response<LoginResponce> response) {
                    stopprogressdialog();
                    if (response.isSuccessful()) {
                        Toast.makeText(RegistationActivity.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                        if (response.body().getSuccess().equalsIgnoreCase("1")) {
                            application.setUserLoginData(response.body().getData());
                            Intent intent = new Intent(RegistationActivity.this, HomeActivity.class);
                            startActivity(intent);
                            finish();

                        }
                    }
                }

                @Override
                public void onFailure(Call<LoginResponce> call, Throwable t) {
                    stopprogressdialog();
                    Constant.ErrorMessage(RegistationActivity.this, t);
                }
            });
        }




    }


    public boolean checkBoxChecked(RadioButton radioButton) {
        if (radioButton.isChecked()) {
            return true;
        }
        return false;
    }

    public boolean checkVelidation() {
        if (editFname.getText().toString().trim().equalsIgnoreCase("")) {
            showToast("Enter first name", true);
            return false;
        } else if (editLname.getText().toString().trim().equalsIgnoreCase("")) {
            showToast("Enter last name", true);
            return false;
        } else if (editFathername.getText().toString().trim().equalsIgnoreCase("")) {
            showToast("Enter father name", true);
            return false;
        } else if (editDOB.getText().toString().trim().equalsIgnoreCase("")) {
            showToast("Enter DOB name", true);
            return false;
        } else if (editPhonenumber.getText().toString().trim().equalsIgnoreCase("")) {
            showToast("Enter phone number", true);
            return false;
        } else if (editAddress.getText().toString().trim().equalsIgnoreCase("")) {
            showToast("Enter address", true);
            return false;
        } else {
            return true;
        }


    }

    private void ProfileimagesetDialog() {

        final Dialog dialog = new Dialog(RegistationActivity.this);
        dialog.setCancelable(true);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.setContentView(R.layout.changeprofilepic_dialog);

        Button buttoncamera = dialog.findViewById(R.id.buttoncamera);
        Button buttongallery = dialog.findViewById(R.id.buttongallery);
        Button buttoncancel = dialog.findViewById(R.id.buttoncancel);

        buttoncamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                if (checkAndRequestPermissionsCamera()) {
                    //openCamera();
                    openCamera();
                }
            }
        });
        buttongallery.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                if (checkAndRequestPermissionsGallary()) {
                    pickImage();
                }
            }
        });
        buttoncancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        try {
            dialog.show();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    public void openCamera() {

        Intent intent = new Intent(RegistationActivity.this, CameraActivity.class);
        intent.putExtra("isFountCamera", isClickProfileId);
        startActivityForResult(intent, PICK_CAMERA);
    }

    public void pickImage() {

        Intent pictureActionIntent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(pictureActionIntent, PICK_PHOTO_FOR_AVATAR);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        bitmap = null;
        selectedImagePath = null;
        switch (requestCode) {
            case 0:
                if (data != null) {

                    Uri selectedImage = data.getData();
                    String[] filePath = {MediaStore.Images.Media.DATA};
                    Cursor c = getActivity().getContentResolver().query(selectedImage, filePath,
                            null, null, null);
                    c.moveToFirst();
                    int columnIndex = c.getColumnIndex(filePath[0]);
                    selectedImagePath = c.getString(columnIndex);
                    c.close();

                    bitmap = BitmapFactory.decodeFile(selectedImagePath); // load
                    bitmap = Bitmap.createScaledBitmap(bitmap, 400, 400, false);

                    if (bitmap != null) {
                        if (isClickProfileId) {
                            isClickProfileId = false;
                            imagProfilePic.setImageBitmap(bitmap);
                            selectedPicImagepath = selectedImagePath;
                        } else if (isClickProof) {
                            isClickProof = false;
                            imagIdProof.setImageBitmap(bitmap);
                            selectedProofImagepath = selectedImagePath;
                        }
                    }

                } else {
                    Toast.makeText(getActivity(), "Cancelled", Toast.LENGTH_SHORT).show();
                }


                break;
            case 1:

               /* File f = new File(Environment.getExternalStorageDirectory().toString());
                for (File temp : f.listFiles()) {
                    if (temp.getName().equals("temp.jpg")) {
                        f = temp;
                        break;
                    }
                }
                if (!f.exists()) {
                    Toast.makeText(getActivity(), "Error while capturing image", Toast.LENGTH_LONG).show();
                    return;
                }
                try {

                    bitmap = BitmapFactory.decodeFile(f.getAbsolutePath());
                    bitmap = Bitmap.createScaledBitmap(bitmap, 400, 400, true);

                    int rotate = 0;
                    try {
                        ExifInterface exif = new ExifInterface(f.getAbsolutePath());
                        int orientation = exif.getAttributeInt(
                                ExifInterface.TAG_ORIENTATION,
                                ExifInterface.ORIENTATION_NORMAL);

                        switch (orientation) {
                            case ExifInterface.ORIENTATION_ROTATE_270:
                                rotate = 270;
                                break;
                            case ExifInterface.ORIENTATION_ROTATE_180:
                                rotate = 180;
                                break;
                            case ExifInterface.ORIENTATION_ROTATE_90:
                                rotate = 90;
                                break;
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotate);
                    bitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);

                    if (bitmap != null) {
                        if (isClickProfileId) {
                            isClickProfileId = false;
                            imagProfilePic.setImageBitmap(bitmap);
                            selectedPicImagepath = f.getAbsolutePath();
                        } else if (isClickProof) {
                            isClickProof = false;
                            imagIdProof.setImageBitmap(bitmap);
                            selectedProofImagepath = f.getAbsolutePath();
                        }
                    }

                    //storeImageTosdCard(bitmap);
                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }*/
                if (Constant.bitmap != null) {
                    bitmap = Constant.bitmap;

                    if (isClickProfileId) {
                        isClickProfileId = false;
                        imagProfilePic.setImageBitmap(bitmap);
                        selectedPicImagepath = Constant.path;
                    } else if (isClickProof) {
                        isClickProof = false;
                        imagIdProof.setImageBitmap(bitmap);
                        selectedProofImagepath = Constant.path;
                    }
                    Constant.path = "";
                    Constant.bitmap = null;
                }

                break;
        }
    }

    public void getCategory() {

        startprogressdialog(this);
        HashMap<String, String> dataParams = new HashMap<>();
        mAPIService.get_category(dataParams).enqueue(new Callback<CategoryResponce>() {
            @Override
            public void onResponse(Call<CategoryResponce> call, Response<CategoryResponce> response) {
                stopprogressdialog();
                if (response.isSuccessful()) {
                    if (response.body().getSuccess().equalsIgnoreCase("1")) {
                        Constant.categoryDataArrayList = response.body().getData();
                        setCategory();
                    }
                }
            }

            @Override
            public void onFailure(Call<CategoryResponce> call, Throwable t) {
                stopprogressdialog();
                Constant.ErrorMessage(RegistationActivity.this, t);
            }
        });
    }

    public void setCategory() {
        categoryArrayList = new ArrayList<>();
        categoryArrayList.addAll(Constant.categoryDataArrayList);

        CategoryData categoryData = new CategoryData();
        categoryData.setCategory_id("");
        categoryData.setCategory_name("Select Business Category");
        categoryArrayList.add(0, categoryData);

        DialogAdapter tatusAdapter = new DialogAdapter(RegistationActivity.this, categoryArrayList);
        spinnerBusinessCategroy.setAdapter(tatusAdapter);

        spinnerBusinessCategroy.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                txtBusinessCategroy.setText("" + categoryArrayList.get(i).getCategory_name());
                selectedCategoryData = categoryArrayList.get(i);

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        DialogReletionAdapter reletionAdepter = new DialogReletionAdapter(RegistationActivity.this, reletionArray);
        spinnereletionShip.setAdapter(reletionAdepter);

        spinnereletionShip.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                txtreletionShip.setText("" + reletionArray[i]);
                selectedReletionShipPosition = i;

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        if (addUpdateMember && editMember) {
            if (Constant.committeeMemberData != null) {
                for (int i = 0; i < categoryArrayList.size(); i++) {
                    if (categoryArrayList.get(i).getCategory_id().equalsIgnoreCase(Constant.committeeMemberData.getBusiness_categroy_id())) {
                        spinnerBusinessCategroy.setSelection(i);
                    }
                }

                for (int i = 0; i < reletionArray.length; i++) {
                    if (reletionArray[i].equalsIgnoreCase(Constant.committeeMemberData.getRelation_ship())) {
                        spinnereletionShip.setSelection(i);
                    }
                }
            }


        }
    }

    public void setMemberData(LoginUserFamilyMemberInfo memberData) {
        editPhonenumber.setEnabled(false);
        editFname.setText(memberData.getFirst_name());
        editLname.setText(memberData.getSurname());
        editFathername.setText(memberData.getFather_name());
        editDOB.setText(memberData.getDate_of_birth());
        editAddress.setText(memberData.getAddress());
        editPhonenumber.setText(memberData.getPhone_number());
        editBusinessDetail.setText(memberData.getBusiness_details());
        txtStandard.setText(memberData.getEducation());
        editEmail.setText(memberData.getEmail_id());


        if (memberData.getBusiness_or_job_or_any().equalsIgnoreCase("business")) {
            rbbusiness.setChecked(true);
        } else if (memberData.getBusiness_or_job_or_any().equalsIgnoreCase("job")) {
            rbjob.setChecked(true);
        } else if (memberData.getBusiness_or_job_or_any().equalsIgnoreCase("other")) {
            rbother.setChecked(true);
        }
        if (memberData.getMarital_status().equalsIgnoreCase("1")) {
            rbmarried.setChecked(true);
        } else if (memberData.getMarital_status().equalsIgnoreCase("2")) {
            rbsingle.setChecked(true);
        }

        if (memberData.getGender().equalsIgnoreCase("1")) {
            rbMale.setChecked(true);
        } else if (memberData.getGender().equalsIgnoreCase("2")) {
            rbFemale.setChecked(true);
        }

        if (memberData.getBlood_group().equalsIgnoreCase("A+")) {
            rbAp.setChecked(true);
        } else if (memberData.getBlood_group().equalsIgnoreCase("A-")) {
            rbAm.setChecked(true);
        } else if (memberData.getBlood_group().equalsIgnoreCase("B+")) {
            rbBp.setChecked(true);
        } else if (memberData.getBlood_group().equalsIgnoreCase("B-")) {
            rbBm.setChecked(true);
        } else if (memberData.getBlood_group().equalsIgnoreCase("O+")) {
            rbOp.setChecked(true);
        } else if (memberData.getBlood_group().equalsIgnoreCase("O-")) {
            rbOm.setChecked(true);
        } else if (memberData.getBlood_group().equalsIgnoreCase("AB+")) {
            rbABp.setChecked(true);
        } else if (memberData.getBlood_group().equalsIgnoreCase("AB-")) {
            rbABm.setChecked(true);
        }

        if (!memberData.getId_proof().equalsIgnoreCase("")) {
            Glide.with(getApplicationContext()).load(Constant.BASE_IMAGE_URL+memberData.getId_proof()).into(imagIdProof);
        }
        if (!memberData.getProfile_image().equalsIgnoreCase("")) {
            Glide.with(getApplicationContext()).load(Constant.BASE_IMAGE_URL+memberData.getProfile_image()).into(imagProfilePic);
        }

        btnSubmit.setText("Update");
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case REQ_ALL_PERMISSIONS_GALLARY:
                if (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(), Manifest.permission.WRITE_EXTERNAL_STORAGE)) {

                    } else {
                        Log.e(TAG, "onRequestPermissionsResult: WRITE_EXTERNAL_STORAGE >> dont ask again");
                    }
                } else {
                    pickImage();
                }

                break;
            case REQ_ALL_PERMISSIONS_CAMERA:
                if (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(), Manifest.permission.WRITE_EXTERNAL_STORAGE)) {


                    } else {

                    }
                } else if (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {

                } else {

                    openCamera();
                }

                break;
        }

    }



}
