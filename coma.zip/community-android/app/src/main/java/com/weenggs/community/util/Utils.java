package com.weenggs.community.util;

import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.PixelFormat;
import android.graphics.drawable.Drawable;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import com.weenggs.community.R;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Utils {

    private static String TAG = "TAG " + Utils.class.getSimpleName();

    public static String saveBitmap(Bitmap bitmap) {
        File fullCacheDir = new File(Environment.getExternalStorageDirectory().toString(), cacheDir);
        if (!fullCacheDir.exists()) {
            Log.e("TAG ConstantValue", "CACHE Directory doesn't exist");
            fullCacheDir.mkdirs();
        }
        // Create a media file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss",
                Locale.getDefault()).format(new Date());
        File mediaFile;
        mediaFile = new File(fullCacheDir.getPath() + File.separator
                + "_" + "I" + "_" + timeStamp + ".jpeg");


        if (mediaFile.exists()) {
            mediaFile.delete();
            try {
                mediaFile.createNewFile();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }


        FileOutputStream out = null;
        try {
            out = new FileOutputStream(mediaFile);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, out); // bmp is your Bitmap instance
            // PNG is a lossless format, the compression factor (100) is ignored
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (out != null) {
                    out.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return mediaFile.getAbsolutePath();
    }

    public static final String cacheDir = "/Android/data/" + R.string.app_name + "/";


    public static void setStatusBarColor(Activity activity, int statusBarColor) {
        if (android.os.Build.VERSION.SDK_INT > 21) {
            Window window = activity.getWindow();
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(statusBarColor);

            int newUiVisibility = window.getDecorView().getSystemUiVisibility();

            //Dark Text to show up on your light status bar
            newUiVisibility |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;

            //Light Text to show up on your dark status bar
//            newUiVisibility &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;

            // TODO: 2019-08-31 For full screen transparent
//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
//                dialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
//                dialog.getWindow().setStatusBarColor(Color.WHITE);
//            }

            window.getDecorView().setSystemUiVisibility(newUiVisibility);
        }
    }

    public static boolean isPackageInstalled(Context context, String packageName) {
        PackageManager pm = context.getPackageManager();
        if (pm != null) {
            try {
                pm.getPackageInfo(packageName, 0);
                return true;
            } catch (PackageManager.NameNotFoundException e) {
                e.printStackTrace();
            }
        }
        return false;
    }


    /**
     * convert drawable to bitmap
     *
     * @param drawable
     * @return
     */
    public static Bitmap drawableToBitmap(Drawable drawable) {
        int width = drawable.getIntrinsicWidth();
        int height = drawable.getIntrinsicHeight();
        Bitmap bitmap = Bitmap.createBitmap(width, height, drawable.getOpacity() != PixelFormat.OPAQUE ? Bitmap.Config.ARGB_8888 : Bitmap.Config.RGB_565);
        Canvas canvas = new Canvas(bitmap);
        drawable.setBounds(0, 0, width, height);
        drawable.draw(canvas);
        return bitmap;

    }


}
