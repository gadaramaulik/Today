package com.weenggs.community.adepter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.weenggs.community.R;
import com.weenggs.community.fragment.MarkSheetFragment;
import com.weenggs.community.model.MarkSheetListData;
import com.weenggs.community.widget.DTextView;

import java.util.ArrayList;

import androidx.recyclerview.widget.RecyclerView;

public class MarkSheetAdepter extends RecyclerView.Adapter<MarkSheetAdepter.ViewHolder> {

    MarkSheetFragment deviceListFragment;
    private ArrayList<MarkSheetListData> items = new ArrayList<>();
    Context context;
    public MarkSheetAdepter(MarkSheetFragment context, ArrayList<MarkSheetListData> memberDataArrayList) {
        this.deviceListFragment = context;
        this.items = memberDataArrayList;
    }

    public void addAll(ArrayList<MarkSheetListData> data) {
        items.clear();
        items.addAll(data);
        notifyDataSetChanged();
    }

    public void add(MarkSheetListData data) {
        items.add(data);
        notifyDataSetChanged();
    }


    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.marksheet_adepter_row, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {

        final MarkSheetListData data = items.get(position);


        holder.txtName.setText(data.getFirst_name() + " " + data.getSurname());
        holder.txtStatus.setText(data.getPercentage() + "%");

        if (data.getMarksheet_status().equalsIgnoreCase("0")) {
            holder.txt_Approve.setText("Pending");
        } else if (data.getMarksheet_status().equalsIgnoreCase("1")) {
            holder.txt_Approve.setText("Approved");
        } else if (data.getMarksheet_status().equalsIgnoreCase("2")) {
            holder.txt_Approve.setText("Reject");
        }

        holder.layoutmain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    deviceListFragment.editMember(data);
            }
        });

    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public static final class ViewHolder extends RecyclerView.ViewHolder {

        private DTextView txtName, txtStatus, txt_Approve;
        private LinearLayout layoutmain;


        private ViewHolder(View itemView) {
            super(itemView);
            txtName = (DTextView) itemView.findViewById(R.id.txt_name);
            txtStatus = (DTextView) itemView.findViewById(R.id.txtStatus);
            txt_Approve = (DTextView) itemView.findViewById(R.id.txt_Approve);
            layoutmain = (LinearLayout) itemView.findViewById(R.id.layoutmain);

        }
    }
}

