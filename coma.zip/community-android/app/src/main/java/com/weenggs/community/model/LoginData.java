package com.weenggs.community.model;

import java.util.ArrayList;

public class LoginData {

    LoginUserinfo logins;
    LoginUserFamilyinfo familyInfo;
    ArrayList<LoginUserFamilyMemberInfo> memberInfo;


    public LoginUserinfo getLogins() {
        return logins;
    }

    public void setLogins(LoginUserinfo logins) {
        this.logins = logins;
    }

    public LoginUserFamilyinfo getFamilyInfo() {
        return familyInfo;
    }

    public void setFamilyInfo(LoginUserFamilyinfo familyInfo) {
        this.familyInfo = familyInfo;
    }

    public ArrayList<LoginUserFamilyMemberInfo> getMemberInfo() {
        return memberInfo;
    }

    public void setMemberInfo(ArrayList<LoginUserFamilyMemberInfo> memberInfo) {
        this.memberInfo = memberInfo;
    }
}
