package com.weenggs.community.activity;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.weenggs.community.R;
import com.weenggs.community.adepter.ImageSliderIncidentAdapter;
import com.weenggs.community.model.AppPostRequest;
import com.weenggs.community.model.ImageSelect;
import com.weenggs.community.model.LoginResponce;
import com.weenggs.community.model.PostData;
import com.weenggs.community.util.Constant;
import com.weenggs.community.util.FileUtil;
import com.weenggs.community.util.GetPathFromUri;
import com.weenggs.community.widget.DEditText;
import com.weenggs.community.widget.DTextView;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import in.myinnos.awesomeimagepicker.activities.AlbumSelectActivity;
import in.myinnos.awesomeimagepicker.helpers.ConstantsCustomGallery;
import in.myinnos.awesomeimagepicker.models.Image;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddNewsPostActivity extends BaseActivity implements View.OnClickListener {

    private ImageView cancel;
    private DTextView txtTitle;
    private DTextView txtresoun;
    private DEditText editTitle;
    private DEditText editDescribtion;
    private DTextView btnUploadImg;
    private RecyclerView listview;
    private DTextView btnSubmit;

    ImageSliderIncidentAdapter horizontalListAdapter;
    ArrayList<ImageSelect> imageSelectArrayList = new ArrayList<>();
    public static final int REQUEST_TAKE_GALLERY_VIDEO = 4000;
    String isAttechment = "";
    boolean isEdit;
    PostData postData;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_news_post_activity);
        isEdit = getIntent().getBooleanExtra("isEdit", false);
        findViews();
    }

    private void findViews() {
        cancel = findViewById(R.id.cancel);
        txtTitle = findViewById(R.id.txtTitle);
        txtresoun = findViewById(R.id.txtresoun);
        editTitle = findViewById(R.id.editTitle);
        editDescribtion = findViewById(R.id.editDescribtion);
        btnUploadImg = findViewById(R.id.btnUploadImg);
        listview = findViewById(R.id.listview);
        btnSubmit = findViewById(R.id.btnSubmit);

        btnUploadImg.setOnClickListener(this);
        btnSubmit.setOnClickListener(this);
        cancel.setOnClickListener(this);

        if (isEdit) {
            postData = Constant.postData;
            editTitle.setText(postData.getTitle());
            editDescribtion.setText(postData.getDescription());

            isAttechment = postData.getMedia_type();

            if (isAttechment.equalsIgnoreCase("video")) {
                ArrayList<ImageSelect> imageSelectArrayList = new ArrayList<>();


                ImageSelect imageSelect = new ImageSelect();
                imageSelect.setNew(false);
                imageSelect.setVideo(true);
                imageSelect.setUrl(postData.getMedia());
                imageSelect.setVideo_thaum_url(postData.getVideo_thumb());
                imageSelect.setId("");
                imageSelectArrayList.add(imageSelect);

                setImageAdepter(imageSelectArrayList);
            } else {
                ArrayList<ImageSelect> imageSelectArrayList = new ArrayList<>();

                for (int i = 0; i < postData.getMediaImage().size(); i++) {
                    ImageSelect imageSelect = new ImageSelect();
                    imageSelect.setNew(false);
                    imageSelect.setUrl(postData.getMediaImage().get(i).getMedia());
                    imageSelect.setId(postData.getMediaImage().get(i).getNews_image_id());
                    imageSelect.setNews_id(postData.getMediaImage().get(i).getNews_id());
                    imageSelectArrayList.add(imageSelect);
                }
                setImageAdepter(imageSelectArrayList);
            }

        }
    }

    private void AddAttechmentDailog() {

        final Dialog dialog = new Dialog(AddNewsPostActivity.this);
        dialog.setCancelable(true);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.setContentView(R.layout.add_attechment_dialog);

        Button buttoncamera = dialog.findViewById(R.id.buttoncamera);
        Button buttongallery = dialog.findViewById(R.id.buttongallery);
        Button buttoncancel = dialog.findViewById(R.id.buttoncancel);

        buttoncamera.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                if (checkAndRequestPermissionsGallary()) {
                    //openCamera();
                    addVideo();
                }
            }
        });
        buttongallery.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                if (checkAndRequestPermissionsGallary()) {
                    addImages();
                }
            }
        });
        buttoncancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        try {
            dialog.show();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    public void addVideo() {

        Intent intent = new Intent();
        intent.setType("video/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Video"), REQUEST_TAKE_GALLERY_VIDEO);

    }

    public void addImages() {
        Intent intent = new Intent(this, AlbumSelectActivity.class);
        intent.putExtra(ConstantsCustomGallery.INTENT_EXTRA_LIMIT, 5); // set limit for image selection
        startActivityForResult(intent, ConstantsCustomGallery.REQUEST_CODE);
    }

    @Override
    public void onClick(View view) {
        if (view == btnUploadImg) {
            AddAttechmentDailog();
        } else if (view == btnSubmit) {
            addpost();
        } else if (view == cancel) {
            finish();
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == ConstantsCustomGallery.REQUEST_CODE && resultCode == Activity.RESULT_OK && data != null) {
            //The array list has the image paths of the selected images
            ArrayList<Image> images = data.getParcelableArrayListExtra(ConstantsCustomGallery.INTENT_EXTRA_IMAGES);
            ArrayList<ImageSelect> imageSelectArrayList = new ArrayList<>();

            for (int i = 0; i < images.size(); i++) {
                ImageSelect imageSelect = new ImageSelect();
                // Uri uri = Uri.fromFile(new File(images.get(i).path));
                imageSelect.setNew(true);
                imageSelect.setPath(images.get(i).path);
                imageSelectArrayList.add(imageSelect);
            }
            isAttechment = "image";
            setImageAdepter(imageSelectArrayList);
        } else if (requestCode == REQUEST_TAKE_GALLERY_VIDEO && resultCode == Activity.RESULT_OK && data != null) {
            if (requestCode == REQUEST_TAKE_GALLERY_VIDEO) {
                Uri selectedImageUri = data.getData();
                ArrayList<ImageSelect> imageSelectArrayList = new ArrayList<>();
                String selectedImagePath = GetPathFromUri.getPath(AddNewsPostActivity.this, selectedImageUri);
                if (selectedImagePath != null) {
                    ImageSelect imageSelect = new ImageSelect();
                    // Uri uri = Uri.fromFile(new File(images.get(i).path));
                    imageSelect.setNew(true);
                    imageSelect.setPath(selectedImagePath);
                    imageSelect.setVideo(true);
                    imageSelectArrayList.add(imageSelect);
                    isAttechment = "video";
                    setImageAdepter(imageSelectArrayList);
                }

            }
        }
    }

    public void imageDelete(int position) {
        if (imageSelectArrayList.get(position).isNew()) {
            imageSelectArrayList.remove(position);
            if (horizontalListAdapter != null)
                horizontalListAdapter.notifyDataSetChanged();
            Toast.makeText(AddNewsPostActivity.this, "Images deleted successfully ", Toast.LENGTH_SHORT).show();

        } else {
            deleteimage(imageSelectArrayList.get(position).getId(), imageSelectArrayList.get(position).getNews_id());
            imageSelectArrayList.remove(position);
            if (horizontalListAdapter != null)
                horizontalListAdapter.notifyDataSetChanged();

        }
    }


    public void deleteimage(String id, String news_id) {
        startprogressdialog(this);
        HashMap<String, String> dataParams = new HashMap<>();

        dataParams.put("news_id", news_id);
        dataParams.put("user_id", data.getMemberInfo().get(0).getUser_id());
        dataParams.put("news_image_id", id);

        mAPIService.news_image_delete(dataParams).enqueue(new Callback<LoginResponce>() {
            @Override
            public void onResponse(Call<LoginResponce> call, Response<LoginResponce> response) {
                stopprogressdialog();
                if (response.isSuccessful()) {
                    Toast.makeText(AddNewsPostActivity.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<LoginResponce> call, Throwable t) {
                stopprogressdialog();
                Constant.ErrorMessage(AddNewsPostActivity.this, t);
            }
        });
    }

    public void setImageAdepter(ArrayList<ImageSelect> imageAdepter) {
        listview.setVisibility(View.VISIBLE);
        if (isAttechment.equalsIgnoreCase("video")) {
            imageSelectArrayList.clear();
        }
        imageSelectArrayList.addAll(imageAdepter);
        horizontalListAdapter = new ImageSliderIncidentAdapter(this, imageSelectArrayList);
        listview.setHasFixedSize(true);
        listview.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        listview.setAdapter(horizontalListAdapter);
        listview.setNestedScrollingEnabled(false);

    }


    public void addpost() {

        if (editTitle.getText().toString().trim().equalsIgnoreCase("")) {
            Toast.makeText(this, "Enter Title", Toast.LENGTH_SHORT).show();
        } else if (editDescribtion.getText().toString().trim().equalsIgnoreCase("")) {
            Toast.makeText(this, "Enter Title", Toast.LENGTH_SHORT).show();
        } else {
            startprogressdialog(AddNewsPostActivity.this);
            List<MultipartBody.Part> parts = new ArrayList<>();

            AppPostRequest appPostRequest = new AppPostRequest();
            appPostRequest.setTitle(RequestBody.create(MEDIA_TYPE_TEXT_PLAIN, editTitle.getText().toString().trim()));
            appPostRequest.setDescription(RequestBody.create(MEDIA_TYPE_TEXT_PLAIN, editDescribtion.getText().toString().trim()));
            appPostRequest.setMembers_id(RequestBody.create(MEDIA_TYPE_TEXT_PLAIN, data.getMemberInfo().get(0).getMembers_id()));
            appPostRequest.setUser_id(RequestBody.create(MEDIA_TYPE_TEXT_PLAIN, data.getMemberInfo().get(0).getUser_id()));
            appPostRequest.setMedia_type(RequestBody.create(MEDIA_TYPE_TEXT_PLAIN, isAttechment));

            if (isEdit) {
                appPostRequest.setNews_id(RequestBody.create(MEDIA_TYPE_TEXT_PLAIN, postData.getNews_id()));
            }

            if (isAttechment.equalsIgnoreCase("video")) {
                if (imageSelectArrayList.size() != 0 && imageSelectArrayList.get(0).isNew()) {
                    appPostRequest.setMedia(RequestBody.create(MEDIA_TYPE_FORM_DATA, new File(imageSelectArrayList.get(0).getPath())));
                    appPostRequest.setVideo_thumb(RequestBody.create(MEDIA_TYPE_FORM_DATA,
                            new File(imageSelectArrayList.get(0).getPath())));

                    Bitmap thumbVideo = ThumbnailUtils.createVideoThumbnail(imageSelectArrayList.get(0).getPath(),
                            MediaStore.Images.Thumbnails.MINI_KIND);

                    try {
                        File file = FileUtil.getNewFile(AddNewsPostActivity.this, getString(R.string.app_name));
                        if (file != null) {

                            saveImageToGallery(file, thumbVideo);
                            appPostRequest.setVideo_thumb(RequestBody.create(MEDIA_TYPE_FORM_DATA, file));

                        } else {
                            Toast.makeText(AddNewsPostActivity.this, "the file is null", Toast.LENGTH_SHORT).show();
                        }
                    } catch (OutOfMemoryError outOfMemoryError) {
                        outOfMemoryError.printStackTrace();
                        Log.e(TAG, "saveSticker: OutOfMemoryError >>>>>>>>>>> ");
                    }



                }
            } else {
                for (int i = 0; i < imageSelectArrayList.size(); i++) {

                    if (imageSelectArrayList.get(i).isNew()) {
                        final int random = new Random().nextInt(61) + 20; // [0, 60] + 20 => [20, 80]

                        RequestBody requestImageFile = RequestBody.create(MediaType.parse("image/jpeg"),
                                new File(imageSelectArrayList.get(i).getPath()));
                        parts.add(MultipartBody.Part.createFormData("media[]", "video_" + random + ".mp4", requestImageFile));
                    }
                }

            }

            if (isEdit) {
                mAPIService.edit_post(appPostRequest.getNews_id(), appPostRequest.getUser_id(),
                        appPostRequest.getMembers_id(), appPostRequest.getTitle(),
                        appPostRequest.getDescription(), appPostRequest.getMedia_type(),
                        appPostRequest.getVideo_thumb(), appPostRequest.getMedia(), parts).enqueue(new Callback<LoginResponce>() {
                    @Override
                    public void onResponse(Call<LoginResponce> call, Response<LoginResponce> response) {
                        stopprogressdialog();
                        if (response.isSuccessful()) {
                            Toast.makeText(AddNewsPostActivity.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();

                            if (response.body().getSuccess().equalsIgnoreCase("1")) {

                                setResult(RESULT_OK);
                                finish();
                            }

                        }
                    }

                    @Override
                    public void onFailure(Call<LoginResponce> call, Throwable t) {
                        stopprogressdialog();
                        Constant.ErrorMessage(AddNewsPostActivity.this, t);
                    }
                });
            } else {
                mAPIService.add_post(appPostRequest.getUser_id(),
                        appPostRequest.getMembers_id(), appPostRequest.getTitle(),
                        appPostRequest.getDescription(), appPostRequest.getMedia_type(),
                        appPostRequest.getVideo_thumb(), appPostRequest.getMedia(), parts).enqueue(new Callback<LoginResponce>() {
                    @Override
                    public void onResponse(Call<LoginResponce> call, Response<LoginResponce> response) {
                        stopprogressdialog();
                        if (response.isSuccessful()) {
                            Toast.makeText(AddNewsPostActivity.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();

                            if (response.body().getSuccess().equalsIgnoreCase("1")) {

                                setResult(RESULT_OK);
                                finish();
                            }

                        }
                    }

                    @Override
                    public void onFailure(Call<LoginResponce> call, Throwable t) {
                        stopprogressdialog();
                        Constant.ErrorMessage(AddNewsPostActivity.this, t);
                    }
                });
            }

        }
    }
}
