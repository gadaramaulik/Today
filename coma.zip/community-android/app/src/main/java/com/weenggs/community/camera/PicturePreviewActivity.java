package com.weenggs.community.camera;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import com.otaliastudios.cameraview.BitmapCallback;
import com.otaliastudios.cameraview.CameraUtils;
import com.otaliastudios.cameraview.FileCallback;
import com.otaliastudios.cameraview.PictureResult;
import com.weenggs.community.R;
import com.weenggs.community.util.Constant;

import java.io.File;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;


public class PicturePreviewActivity extends AppCompatActivity {

    private static PictureResult picture;
    ImageButton img_right;
    Bitmap bit;

    public static void setPictureResult(@Nullable PictureResult pictureResult) {
        picture = pictureResult;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_picture_preview);
        final PictureResult result = picture;
        if (result == null) {
            finish();
            return;
        }

        final ImageView imageView = findViewById(R.id.image);
        final ImageView img_right = findViewById(R.id.img_right);
        final ImageView cancel = findViewById(R.id.cancel);
        final ImageView img_wrong = findViewById(R.id.img_wrong);

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        try {
            result.toBitmap(1000, 1000, new BitmapCallback() {
                @Override
                public void onBitmapReady(Bitmap bitmap) {
                    imageView.setImageBitmap(bitmap);
                    bit = bitmap;
                }
            });
        } catch (UnsupportedOperationException e) {
            imageView.setImageDrawable(new ColorDrawable(Color.GREEN));
            Toast.makeText(this, "Can't preview this format: " + picture.getFormat(), Toast.LENGTH_LONG).show();
        }

        img_right.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String extension;
                switch (picture.getFormat()) {
                    case JPEG:
                        extension = "jpg";
                        break;
                    case DNG:
                        extension = "dng";
                        break;
                    default:
                        throw new RuntimeException("Unknown format.");
                }
                Constant.bitmap = bit;
                File file = new File(getFilesDir(), "picture." + extension);
                CameraUtils.writeToFile(picture.getData(), file, new FileCallback() {
                    @Override
                    public void onFileReady(@Nullable File file) {
                        if (file != null) {
                            Intent intent = new Intent();
                            intent.setAction("add_images");
                            sendBroadcast(intent);
                            Constant.path = file.getAbsolutePath();
                            finish();
                        } else {
                            Toast.makeText(PicturePreviewActivity.this,
                                    "Error while writing file.",
                                    Toast.LENGTH_SHORT).show();
                        }
                    }
                });
                finish();
            }
        });
        img_wrong.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (!isChangingConfigurations()) {
            setPictureResult(null);
        }
    }


}
