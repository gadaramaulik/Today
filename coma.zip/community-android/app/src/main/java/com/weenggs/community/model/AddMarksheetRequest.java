package com.weenggs.community.model;

import okhttp3.RequestBody;

public class AddMarksheetRequest {

    private RequestBody members_id;
    private RequestBody standard_id;
    private RequestBody medium_id;
    private RequestBody percentage;
    private RequestBody grade_id;
    private RequestBody bu_id;
    private RequestBody years;
    private RequestBody marksheet_image;
    private RequestBody user_id;
    private RequestBody marksheet_id;

    public RequestBody getMarksheet_id() {
        return marksheet_id;
    }

    public void setMarksheet_id(RequestBody marksheet_id) {
        this.marksheet_id = marksheet_id;
    }

    public RequestBody getUser_id() {
        return user_id;
    }

    public void setUser_id(RequestBody user_id) {
        this.user_id = user_id;
    }

    public RequestBody getMembers_id() {
        return members_id;
    }

    public void setMembers_id(RequestBody members_id) {
        this.members_id = members_id;
    }

    public RequestBody getStandard_id() {
        return standard_id;
    }

    public void setStandard_id(RequestBody standard_id) {
        this.standard_id = standard_id;
    }

    public RequestBody getMedium_id() {
        return medium_id;
    }

    public void setMedium_id(RequestBody medium_id) {
        this.medium_id = medium_id;
    }

    public RequestBody getPercentage() {
        return percentage;
    }

    public void setPercentage(RequestBody percentage) {
        this.percentage = percentage;
    }

    public RequestBody getGrade_id() {
        return grade_id;
    }

    public void setGrade_id(RequestBody grade_id) {
        this.grade_id = grade_id;
    }

    public RequestBody getBu_id() {
        return bu_id;
    }

    public void setBu_id(RequestBody bu_id) {
        this.bu_id = bu_id;
    }

    public RequestBody getYears() {
        return years;
    }

    public void setYears(RequestBody years) {
        this.years = years;
    }

    public RequestBody getMarksheet_image() {
        return marksheet_image;
    }

    public void setMarksheet_image(RequestBody marksheet_image) {
        this.marksheet_image = marksheet_image;
    }
}

