package com.weenggs.community.activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.Target;
import com.github.vivchar.viewpagerindicator.ViewPagerIndicator;
import com.mikhaellopez.circularimageview.CircularImageView;
import com.weenggs.community.R;
import com.weenggs.community.model.LoginResponce;
import com.weenggs.community.model.MediaData;
import com.weenggs.community.model.PostData;
import com.weenggs.community.util.Constant;
import com.weenggs.community.widget.DTextView;

import java.util.ArrayList;
import java.util.HashMap;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PostFullDetailActivity extends BaseActivity implements View.OnClickListener {

    private RelativeLayout topLayout;
    private ImageView cancel;
    private DTextView txtTitle;
    private LinearLayout displayNameLayout;
    private CircularImageView profilePhoto;
    private DTextView userName, btndelete;
    private RelativeLayout mediaViewsImage;
    private ViewPager pager;
    private ViewPagerIndicator viewPagerIndicator;
    private RelativeLayout mediaViewsVideo;
    private ImageView mediaPost;
    private ProgressBar progressBar;
    private ImageView videoIndicater;
    private DTextView txtDesribtion, btnEdit, btnApprove;
    MyPagerAdapter myPagerAdapter;
    PostData postData;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.post_full_detail);
        postData = Constant.postData;
        findViews();
        if (postData != null)
            setData();
    }


    private void findViews() {
        topLayout = (RelativeLayout) findViewById(R.id.topLayout);
        cancel = (ImageView) findViewById(R.id.cancel);
        txtTitle = (DTextView) findViewById(R.id.txtTitle);
        displayNameLayout = (LinearLayout) findViewById(R.id.display_name_layout);
        profilePhoto = (CircularImageView) findViewById(R.id.profile_photo);
        txtTitle = (DTextView) findViewById(R.id.txt_title);
        btnApprove = (DTextView) findViewById(R.id.btnApprove);
        userName = (DTextView) findViewById(R.id.user_name);
        btndelete = (DTextView) findViewById(R.id.btndelete);
        btnEdit = (DTextView) findViewById(R.id.btnEdit);
        mediaViewsImage = (RelativeLayout) findViewById(R.id.media_views_image);
        pager = (ViewPager) findViewById(R.id.pager);
        viewPagerIndicator = (ViewPagerIndicator) findViewById(R.id.view_pager_indicator);
        mediaViewsVideo = (RelativeLayout) findViewById(R.id.media_views_video);
        mediaPost = (ImageView) findViewById(R.id.media_post);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        videoIndicater = (ImageView) findViewById(R.id.video_indicater);
        txtDesribtion = (DTextView) findViewById(R.id.txt_desribtion);

        cancel.setOnClickListener(this);
        btnEdit.setOnClickListener(this);
        btnApprove.setOnClickListener(this);
        btndelete.setOnClickListener(this);

        if (postData.getPosted_by().equalsIgnoreCase(data.getLogins().getProfileData().getMembers_id())) {
            btnEdit.setVisibility(View.VISIBLE);
            btndelete.setVisibility(View.VISIBLE);
        } else {
            btnEdit.setVisibility(View.GONE);
            btndelete.setVisibility(View.GONE);
        }

        if (data.getLogins().getProfileData().getIs_commitee_member().equalsIgnoreCase("1")
                && !postData.getIs_approved().equalsIgnoreCase("1")) {
            btnApprove.setVisibility(View.VISIBLE);
        } else {
            btnApprove.setVisibility(View.GONE);
        }
    }

    public void setData() {

        userName.setText(postData.getFullName());

        Glide.with(PostFullDetailActivity.this).load(Constant.BASE_IMAGE_URL + postData.getProfile_image()).into(profilePhoto);

        txtDesribtion.setText(postData.getDescription());
        txtTitle.setText(postData.getTitle());
        videoIndicater.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                videoPlay(postData);
            }
        });
        if (postData.getMedia_type().equalsIgnoreCase("video")) {
            mediaViewsVideo.setVisibility(View.VISIBLE);
            mediaViewsImage.setVisibility(View.GONE);


            Glide.with(PostFullDetailActivity.this)
                    .load(Constant.BASE_IMAGE_URL + postData.getVideo_thumb())
                    .transition(DrawableTransitionOptions.withCrossFade())
                    .centerCrop()
                    .apply(new RequestOptions()
                            .placeholder(R.color.streat_line))
                    .listener(new RequestListener<Drawable>() {
                        @Override
                        public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                            if (progressBar != null)
                                progressBar.setVisibility(View.GONE);
                            return false;
                        }

                        @Override
                        public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                            if (progressBar != null)
                                progressBar.setVisibility(View.GONE);
                            return false;
                        }
                    }).into(mediaPost);

        } else {
            mediaViewsVideo.setVisibility(View.GONE);
            mediaViewsImage.setVisibility(View.VISIBLE);

            if (postData.getMediaImage() != null) {
                myPagerAdapter = new MyPagerAdapter(postData.getMediaImage(), PostFullDetailActivity.this);
                pager.setAdapter(myPagerAdapter);
                pager.setCurrentItem(0);
                viewPagerIndicator.setupWithViewPager(pager);

                @NonNull final ViewPager.OnPageChangeListener mOnPageChangeListener = new ViewPager.OnPageChangeListener() {
                    @Override
                    public void onPageScrolled(final int position, final float positionOffset, final int positionOffsetPixels) {

                    }

                    @Override
                    public void onPageSelected(final int position) {
                    }

                    @Override
                    public void onPageScrollStateChanged(final int state) {

                    }
                };
                viewPagerIndicator.addOnPageChangeListener(mOnPageChangeListener);
            }

        }


    }

    public void videoPlay(PostData postData) {
        Intent intent = new Intent(getActivity(), VideoPlayderActivity.class);
        intent.putExtra("url", Constant.BASE_IMAGE_URL + postData.getMedia());
        startActivity(intent);
    }

    @Override
    public void onClick(View view) {

        if (view == cancel) {
            finish();
        } else if (view == btnEdit) {
            Intent intent = new Intent(PostFullDetailActivity.this, AddNewsPostActivity.class);
            intent.putExtra("isEdit", true);
            startActivityForResult(intent, 15);
        } else if (view == btnApprove) {
            approveNews();
        } else if (view == btndelete) {
            AlertDialog.Builder adb = new AlertDialog.Builder(PostFullDetailActivity.this);
            adb.setTitle("Delete?");
            adb.setMessage("Are you sure you want to delete? ");
            adb.setNegativeButton("Cancel", null);
            adb.setPositiveButton("Ok", new AlertDialog.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    deletenews();
                }
            });
            adb.show();

        }

    }

    public void deletenews() {
        startprogressdialog(this);
        HashMap<String, String> dataParams = new HashMap<>();

        dataParams.put("news_id", postData.getNews_id());
        dataParams.put("user_id", data.getMemberInfo().get(0).getUser_id());
        dataParams.put("members_id", data.getMemberInfo().get(0).getMembers_id());

        mAPIService.news_delete(dataParams).enqueue(new Callback<LoginResponce>() {
            @Override
            public void onResponse(Call<LoginResponce> call, Response<LoginResponce> response) {
                stopprogressdialog();
                if (response.isSuccessful()) {
                    Toast.makeText(PostFullDetailActivity.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    setResult(RESULT_OK);
                    finish();
                }
            }

            @Override
            public void onFailure(Call<LoginResponce> call, Throwable t) {
                stopprogressdialog();
                Constant.ErrorMessage(PostFullDetailActivity.this, t);
            }
        });
    }


    public void approveNews() {
        startprogressdialog(this);
        HashMap<String, String> dataParams = new HashMap<>();
        dataParams.put("user_id", data.getMemberInfo().get(0).getUser_id());
        dataParams.put("members_id", data.getMemberInfo().get(0).getMembers_id());
        dataParams.put("news_id", postData.getNews_id());
        mAPIService.approved_pending(dataParams).enqueue(new Callback<LoginResponce>() {
            @Override
            public void onResponse(Call<LoginResponce> call, Response<LoginResponce> response) {
                stopprogressdialog();
                if (response.isSuccessful()) {
                    Toast.makeText(PostFullDetailActivity.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    setResult(RESULT_OK);
                    finish();

                }
            }

            @Override
            public void onFailure(Call<LoginResponce> call, Throwable t) {
                stopprogressdialog();
                Constant.ErrorMessage(PostFullDetailActivity.this, t);
            }
        });

    }

    private class MyPagerAdapter extends PagerAdapter {
        ArrayList<MediaData> mdata;
        PostFullDetailActivity context1;

        @SuppressWarnings("unused")
        public MyPagerAdapter(ArrayList<MediaData> mdat, PostFullDetailActivity context) {
            // TODO Auto-generated constructor stub
            mdata = mdat;
            context1 = context;


        }


        @Override
        public int getCount() {
            return mdata.size();
        }

        @Override
        public boolean isViewFromObject(View view, Object object) {
            return view == object;
        }

        @Override
        public Object instantiateItem(ViewGroup container1, int position) {

            final MyPagerAdapter.ViewHolderNotification holder = new MyPagerAdapter.ViewHolderNotification();

            View container;

            container = context1.getLayoutInflater().inflate(R.layout.detail, null);
            holder.mediaPost = (ImageView) container.findViewById(R.id.media_post);
            holder.progressBar = (ProgressBar) container.findViewById(R.id.progressBar);

            holder.mediaPost.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Constant.mediaDataArrayList = mdata;
                    Intent intent = new Intent(context1, PhotoViewActivty.class);
                    startActivity(intent);
                }
            });
            container.setTag(R.layout.detail, holder);

            container.setTag(position);

            final MediaData employee = mdata.get(position);

            if (employee.getMedia() != null) {
                if (holder.progressBar != null)
                    holder.progressBar.setVisibility(View.VISIBLE);
                Glide.with(PostFullDetailActivity.this)
                        .load(Constant.BASE_IMAGE_URL + employee.getMedia())
                        .transition(DrawableTransitionOptions.withCrossFade())
                        .apply(new RequestOptions()
                                .placeholder(R.color.streat_line))
                        .listener(new RequestListener<Drawable>() {
                            @Override
                            public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                                if (holder.progressBar != null)
                                    holder.progressBar.setVisibility(View.GONE);
                                return false;
                            }

                            @Override
                            public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                                if (holder.progressBar != null)
                                    holder.progressBar.setVisibility(View.GONE);
                                return false;
                            }
                        }).into(holder.mediaPost);
            }


            container1.addView(container);

            return container;
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            container.removeView((RelativeLayout) object);
        }

        class ViewHolderNotification {

            private ImageView mediaPost;
            private ProgressBar progressBar;

        }

    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 15 && resultCode == RESULT_OK) {
            setResult(RESULT_OK);
            finish();
        }
    }

}
