package com.weenggs.community.util;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.net.Uri;
import android.provider.MediaStore;
import android.widget.Toast;

import com.weenggs.community.R;
import com.weenggs.community.model.CategoryData;
import com.weenggs.community.model.LoginData;
import com.weenggs.community.model.LoginUserFamilyMemberInfo;
import com.weenggs.community.model.MarkSheetListData;
import com.weenggs.community.model.MediaData;
import com.weenggs.community.model.PostData;
import com.weenggs.community.model.StandardMediumData;
import com.weenggs.community.retrofit.APIService;
import com.weenggs.community.retrofit.RetrofitClient;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;

public class Constant {
    public static Context context;
    public static String[] menu_eng;
    public static String[] menu_guj;
    public static String[] reletion_guj;
    public static String[] reletion_eng;
    public static int[] menuIcon = {R.drawable.ic_home, R.drawable.ic_home, R.drawable.ic_home, R.drawable.ic_home,R.drawable.ic_home,R.drawable.ic_home};


    public static final long CONNECTION_TIME_OUT = 30000;
    //public static final String BASE_URL = "http://192.168.0.145/SnehMilan/snehmilan-web/web/api1/";
    //public static final String BASE_IMAGE_URL = "http://192.168.0.145/SnehMilan/snehmilan-web/web/";
    public static final String BASE_URL = "https://php.weenggs.com/SnehMilan/api1/";
    public static final String BASE_IMAGE_URL = "https://php.weenggs.com/SnehMilan/";
    public static ArrayList<CategoryData> categoryDataArrayList;
    public static ArrayList<LoginUserFamilyMemberInfo> committeeMemberDataArrayList;
    public static ArrayList<PostData> postDataArrayList;
    public static ArrayList<LoginUserFamilyMemberInfo> familyMemberDataArrayList;
    public static ArrayList<MarkSheetListData> markSheetListDataArrayList;
    public static ArrayList<MediaData> mediaDataArrayList;
    public static LoginUserFamilyMemberInfo committeeMemberData;
    public static MarkSheetListData markSheetListData;
    public static StandardMediumData standardMediumData;
    public static LoginData loginData_registered_member;
    public static PostData postData;


    public static final String MOBILE_NO = "MOBILE_NO";
    public static final String PASSWORD = "PASSWORD";
    public static final String NUMBEROFMEMBER = "NUMBEROFMEMBER";
    public static final String VERIFIYMEMBER = "VERIFIYMEMBER";
    public static final String EDITMEMBER = "EDITMEMBER";
    public static final String MEMBER_REGISTERED = "MEMBER_REGISTERED";
    public static final String ADDUPDATEMEMBER = "ADDUPDATEMEMBER";
    public static final String ADDNEW = "ADDNEW";
    public static final String ISGUJARATI = "ISGUJARATI";
    public static Bitmap bitmap = null;
    public static String path = "";


    public static final String FIRSTNAME = "FIRSTNAME";
    public static final String LASTNAME = "LASTNAME";
    public static final String FATHERNAME = "FATHERNAME";
    public static final String EMAIL = "EMAIL";

    public static APIService getAPIService() {
        return RetrofitClient.getClient().create(APIService.class);
    }

    public Constant(Context ctx) {
        super();
        Constant.context = ctx;
        menu_eng = context.getResources().getStringArray(R.array.menu_eng);
        menu_guj = context.getResources().getStringArray(R.array.menu_guj);
        reletion_guj = context.getResources().getStringArray(R.array.reletion_guj);
        reletion_eng = context.getResources().getStringArray(R.array.reletion_eng);
        //menuName = new String[]{context.getString(R.string.home), context.getString(R.string.committee_members), ctx.getString(R.string.members_list), ctx.getString(R.string.logout)};
    }
    
    public static void ErrorMessage(Context context, Throwable error) {
        try {
            Toast.makeText(context, "" + error.getMessage(), Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static Bitmap getImageQuality(Bitmap decoded) {
        Bitmap newResizeBitmap = null;
        try {
            newResizeBitmap = null;
            if (decoded.getHeight() > 768 && decoded.getWidth() > 1024) {
                final int IMAGE_SIZE = 768;

                Float width = new Float(decoded.getWidth());
                Float height = new Float(decoded.getHeight());
                Float ratio = width / height;
                newResizeBitmap = Bitmap.createScaledBitmap(decoded, (int) (IMAGE_SIZE * ratio), IMAGE_SIZE, false);
                try {
                    if (decoded != null) {
                        decoded.recycle();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else {
                newResizeBitmap = decoded;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (newResizeBitmap == null) {
            newResizeBitmap = decoded;
        }

        return newResizeBitmap;
    }

    public static Bitmap saveLargeBitmap(Bitmap imageBitmap, String url, Context context) {


        Uri uri = getImageContentUri(context, new File(url));

//        Uri uri= Uri.fromFile(new File(url));

        int rotate = getOrientation(context, uri);
        Bitmap decoded = null;
        try {
            if (rotate > 0) {
                Matrix matrix = new Matrix();
                if (rotate != 0f) {
                    matrix.preRotate(rotate);
                }

                decoded = Bitmap.createBitmap(imageBitmap, 0, 0, imageBitmap.getWidth(), imageBitmap.getHeight(), matrix, true);
            } else {
                decoded = imageBitmap;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        Bitmap newResizeBitmap = getImageQuality(decoded);

        return newResizeBitmap;
    }

    public static File savePreviewBitmap(Bitmap bmp, Context context) {
        OutputStream outStream = null;
        File wallpaperDirectory = null;
        try {
            outStream = null;

            String root = "";
            try {
                root = context.getExternalCacheDir().toString();
            } catch (Exception e) {
                e.printStackTrace();
            }
            wallpaperDirectory = new File(root + "/" + R.string.app_name + "/Images");

            if (!wallpaperDirectory.exists()) {
                wallpaperDirectory.mkdirs();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        File file = new File(wallpaperDirectory, "img" + System.currentTimeMillis() + ".jpg");
        try {
            if (file.exists()) {
                file.delete();
                file = new File(wallpaperDirectory, "img" + System.currentTimeMillis() + ".jpg");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {

            outStream = new FileOutputStream(file);
            bmp.compress(Bitmap.CompressFormat.JPEG, 100, outStream);
            outStream.flush();
            outStream.close();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

        try {
            if (bmp != null) {
                bmp.recycle();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return file;
    }


    public static int getOrientation(Context context, Uri selectedImage) {
        int orientation = -1;

        try {
            Cursor cursor = context.getContentResolver().query(selectedImage,
                    new String[]{MediaStore.Images.ImageColumns.ORIENTATION}, null, null, null);
            if (cursor.getCount() != 1)
                return orientation;

            cursor.moveToFirst();
            orientation = cursor.getInt(0);
            cursor.close(); // ADD THIS LINE
        } catch (Exception e) {
            e.printStackTrace();
        }
        return orientation;
    }

    public static Uri getImageContentUri(Context context, File imageFile) {
        String filePath = imageFile.getAbsolutePath();
        Cursor cursor = context.getContentResolver().query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                new String[]{MediaStore.Images.Media._ID},
                MediaStore.Images.Media.DATA + "=? ",
                new String[]{filePath}, null);
        if (cursor != null && cursor.moveToFirst()) {
            int id = cursor.getInt(cursor.getColumnIndex(MediaStore.MediaColumns._ID));
            cursor.close();
            return Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "" + id);
        } else {
            if (imageFile.exists()) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DATA, filePath);
                return context.getContentResolver().insert(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            } else {
                return null;
            }
        }
    }


}
