package com.weenggs.community.model;

public class MarkSheetListData {

    private String marksheet_id;
    private String standard_id;
    private String gender;
    private String marksheet_status;
    private String created_at;
    private String marksheet_submit_date;
    private String title;
    private String medium_name;
    private String years;
    private String marksheet_image;
    private String marksheet_decline_reason;
    private String father_name;
    private String user_id;
    private String grade_id;
    private String surname;
    private String percentage;
    private String standard_name;
    private String members_id;
    private String medium_id;
    private String bu_id;
    private String first_name;
    private String grade_name;


    public String getMarksheet_id() {
        return marksheet_id;
    }

    public void setMarksheet_id(String marksheet_id) {
        this.marksheet_id = marksheet_id;
    }

    public String getStandard_id() {
        return standard_id;
    }

    public void setStandard_id(String standard_id) {
        this.standard_id = standard_id;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getMarksheet_status() {
        return marksheet_status;
    }

    public void setMarksheet_status(String marksheet_status) {
        this.marksheet_status = marksheet_status;
    }

    public String getCreated_at() {
        return created_at;
    }

    public void setCreated_at(String created_at) {
        this.created_at = created_at;
    }

    public String getMarksheet_submit_date() {
        return marksheet_submit_date;
    }

    public void setMarksheet_submit_date(String marksheet_submit_date) {
        this.marksheet_submit_date = marksheet_submit_date;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getMedium_name() {
        return medium_name;
    }

    public void setMedium_name(String medium_name) {
        this.medium_name = medium_name;
    }

    public String getYears() {
        return years;
    }

    public void setYears(String years) {
        this.years = years;
    }

    public String getMarksheet_image() {
        return marksheet_image;
    }

    public void setMarksheet_image(String marksheet_image) {
        this.marksheet_image = marksheet_image;
    }

    public String getMarksheet_decline_reason() {
        return marksheet_decline_reason;
    }

    public void setMarksheet_decline_reason(String marksheet_decline_reason) {
        this.marksheet_decline_reason = marksheet_decline_reason;
    }

    public String getFather_name() {
        return father_name;
    }

    public void setFather_name(String father_name) {
        this.father_name = father_name;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getGrade_id() {
        return grade_id;
    }

    public void setGrade_id(String grade_id) {
        this.grade_id = grade_id;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getPercentage() {
        return percentage;
    }

    public void setPercentage(String percentage) {
        this.percentage = percentage;
    }

    public String getStandard_name() {
        return standard_name;
    }

    public void setStandard_name(String standard_name) {
        this.standard_name = standard_name;
    }

    public String getMembers_id() {
        return members_id;
    }

    public void setMembers_id(String members_id) {
        this.members_id = members_id;
    }

    public String getMedium_id() {
        return medium_id;
    }

    public void setMedium_id(String medium_id) {
        this.medium_id = medium_id;
    }

    public String getBu_id() {
        return bu_id;
    }

    public void setBu_id(String bu_id) {
        this.bu_id = bu_id;
    }

    public String getFirst_name() {
        return first_name;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public String getGrade_name() {
        return grade_name;
    }

    public void setGrade_name(String grade_name) {
        this.grade_name = grade_name;
    }
}
