package com.weenggs.community.logically;

import android.os.Bundle;
import android.widget.Toast;

import com.weenggs.community.R;
import com.weenggs.community.activity.BaseActivity;

import java.util.ArrayList;
import java.util.Random;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class logicallyActivity extends BaseActivity {
    private RecyclerView recycleview;
    LinearLayoutManager mLayoutManager;
    logicalyAdepter adapter;
    ArrayList<SetGet> setGetArrayList = new ArrayList<>();
    int i = 20;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.logiclly_activity);
        findviewid();
    }

    public void findviewid() {
        recycleview = findViewById(R.id.recycleview);
        mLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        recycleview.setLayoutManager(new GridLayoutManager(this, 4));

        setAdepter();
        setArray(i);
    }

    public void setAdepter() {
        adapter = new logicalyAdepter(logicallyActivity.this, setGetArrayList);
        recycleview.setAdapter(adapter);
    }

    public void setArray(int number) {
        setGetArrayList.clear();
        for (int i = 0; i < number; i++) {
            SetGet setGet = new SetGet();
            setGetArrayList.add(setGet);
        }
        int a = getRendom();
        setGetArrayList.get(a).setIsblue(true);
    }


    public int getRendom() {
        ArrayList<SetGet> temp = new ArrayList<>();
        for (int j = 0; j < setGetArrayList.size(); j++) {
            if (!setGetArrayList.get(j).isRed && !setGetArrayList.get(j).isblue && !setGetArrayList.get(j).isdisable) {
                SetGet setGet = new SetGet();
                setGet.setPosition(j);
                temp.add(setGet);
            }
        }

        if (temp.size() > 0) {
            int random = new Random().nextInt(temp.size());
            return temp.get(random).getPosition();
        } else {
            Toast.makeText(this, "Completed", Toast.LENGTH_SHORT).show();
            return -1;
        }
    }


}
