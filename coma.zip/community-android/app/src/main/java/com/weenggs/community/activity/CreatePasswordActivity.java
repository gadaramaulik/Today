package com.weenggs.community.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.weenggs.community.R;
import com.weenggs.community.model.LoginData;
import com.weenggs.community.model.LoginResponce;
import com.weenggs.community.util.Constant;
import com.weenggs.community.widget.DEditText;
import com.weenggs.community.widget.DTextView;

import java.util.HashMap;

import androidx.annotation.Nullable;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CreatePasswordActivity extends BaseActivity implements View.OnClickListener {

    private ImageView cancel;
    private DTextView textTitle;
    private DTextView txtPhonenumber;
    private DEditText txtPassword;
    private DEditText txtCpassword, editNumberOfMember;
    private DTextView btnSubmit;
    private LinearLayout layoutFamilyInfo;
    private DTextView txtFamilyRegiNumber;
    private DTextView txtMemberName;

    String mobile_no = "";
    boolean memberRegistation = false;
    LinearLayout layoutNumberOfMember;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_password_activity);
        mobile_no = getIntent().getStringExtra(Constant.MOBILE_NO);
        memberRegistation = getIntent().getBooleanExtra(Constant.MEMBER_REGISTERED, false);

        findViews();
    }

    private void findViews() {
        cancel = findViewById(R.id.cancel);
        textTitle = findViewById(R.id.textTitle);
        txtPhonenumber = findViewById(R.id.txtPhonenumber);
        txtPassword = findViewById(R.id.txt_password);
        txtCpassword = findViewById(R.id.txt_cpassword);
        layoutNumberOfMember = findViewById(R.id.layoutNumberOfMember);
        editNumberOfMember = findViewById(R.id.editNumberOfMember);
        btnSubmit = (DTextView) findViewById(R.id.btnSubmit);
        layoutFamilyInfo = findViewById(R.id.layoutFamilyInfo);
        txtFamilyRegiNumber = findViewById(R.id.txtFamilyRegiNumber);
        txtMemberName = findViewById(R.id.txtMemberName);


        if (mobile_no != null) {
            txtPhonenumber.setText(mobile_no);
        }
        if (memberRegistation) {
            layoutNumberOfMember.setVisibility(View.GONE);
            layoutFamilyInfo.setVisibility(View.VISIBLE);
        }
        cancel.setOnClickListener(this);
        btnSubmit.setOnClickListener(this);
        getFamilyDetail();
    }

    @Override
    public void onClick(View view) {
        if (view == cancel) {
            hideSoftKeyboard(CreatePasswordActivity.this);
            onBackPressed();
        } else if (view == btnSubmit) {
            if (checkVelidation()) {
                hideSoftKeyboard(CreatePasswordActivity.this);
                if (memberRegistation) {
                    loginUser();
                } else {
                    Intent intent = new Intent(getApplicationContext(), RegistationActivity.class);
                    intent.putExtra(Constant.MOBILE_NO, txtPhonenumber.getText().toString().trim());
                    intent.putExtra(Constant.PASSWORD, txtPassword.getText().toString().trim());
                    intent.putExtra(Constant.NUMBEROFMEMBER, editNumberOfMember.getText().toString().trim());
                    startActivity(intent);
                }

            }
        }

    }

    public void getFamilyDetail() {
        if (Constant.loginData_registered_member != null) {
            LoginData loginData = Constant.loginData_registered_member;
            for (int i = 0; i < loginData.getMemberInfo().size(); i++) {
                if (loginData.getMemberInfo().get(i).getMember_type().equalsIgnoreCase("main")) {
                    String frn = getApplicationContext().getString(R.string.family_registration_number) + ": " + loginData.getMemberInfo().get(i).getFamily_sr_id();
                    String name = getApplicationContext().getString(R.string.members_name) + ": " + loginData.getMemberInfo().get(i).getFirst_name() + " " + loginData.getMemberInfo().get(i).getSurname();
                    txtFamilyRegiNumber.setText(frn);
                    txtMemberName.setText(name);
                }
            }
        }
    }


    public boolean checkVelidation() {
        if (txtPhonenumber.getText().toString().trim().equalsIgnoreCase("")) {
            showToast("Enter phone number", true);
            return false;
        } else if (txtPassword.getText().toString().trim().equalsIgnoreCase("")) {
            showToast("Enter password name", true);
            return false;
        } else if (txtCpassword.getText().toString().trim().equalsIgnoreCase("")) {
            showToast("Enter confirm name", true);
            return false;
        } else if (!txtPassword.getText().toString().equals(txtCpassword.getText().toString())) {
            showToast("Password and confirm password do not match", true);
            return false;
        } else {
            return true;
        }
    }

    public void loginUser() {

           startprogressdialog(this);
        HashMap<String, String> dataParams = new HashMap<>();

        dataParams.put("phone_number", txtPhonenumber.getText().toString().trim());
        dataParams.put("password", txtPassword.getText().toString().trim());
        dataParams.put("flag", "1");


        mAPIService.login_user(dataParams).enqueue(new Callback<LoginResponce>() {
            @Override
            public void onResponse(Call<LoginResponce> call, Response<LoginResponce> response) {
                stopprogressdialog();
                if (response.isSuccessful()) {
                    Toast.makeText(CreatePasswordActivity.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    if (response.body().getSuccess().equalsIgnoreCase("1")) {

                        application.setUserLoginData(response.body().getData());
                        Constant.committeeMemberData = response.body().getData().getLogins().getProfileData();

                        Intent intent = new Intent(getApplicationContext(), RegistationActivity.class);
                        intent.putExtra(Constant.EDITMEMBER, true);
                        intent.putExtra(Constant.ADDUPDATEMEMBER, true);
                        intent.putExtra(Constant.MOBILE_NO, txtPhonenumber.getText().toString().trim());
                        intent.putExtra(Constant.PASSWORD, txtPassword.getText().toString().trim());
                        intent.putExtra(Constant.NUMBEROFMEMBER, editNumberOfMember.getText().toString().trim());
                        intent.putExtra(Constant.VERIFIYMEMBER, true);
                        startActivity(intent);
                        finish();
                    }
                }
            }

            @Override
            public void onFailure(Call<LoginResponce> call, Throwable t) {
                stopprogressdialog();
                Constant.ErrorMessage(CreatePasswordActivity.this, t);
            }
        });
    }

}
