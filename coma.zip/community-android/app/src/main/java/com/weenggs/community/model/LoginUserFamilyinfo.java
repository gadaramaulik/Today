package com.weenggs.community.model;

public class LoginUserFamilyinfo {

    private String user_id="";
    private String number_of_members="";
    private String registered_on="";
    private String family_sr_id="";


    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getNumber_of_members() {
        return number_of_members;
    }

    public void setNumber_of_members(String number_of_members) {
        this.number_of_members = number_of_members;
    }

    public String getRegistered_on() {
        return registered_on;
    }

    public void setRegistered_on(String registered_on) {
        this.registered_on = registered_on;
    }

    public String getFamily_sr_id() {
        return family_sr_id;
    }

    public void setFamily_sr_id(String family_sr_id) {
        this.family_sr_id = family_sr_id;
    }
}
