package com.weenggs.community.activity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.makeramen.roundedimageview.RoundedImageView;
import com.weenggs.community.R;
import com.weenggs.community.adepter.DrawerAdapter;
import com.weenggs.community.fragment.CommitteememberFragment;
import com.weenggs.community.fragment.ListOfMemberFregment;
import com.weenggs.community.fragment.MainFragment;
import com.weenggs.community.fragment.MarkSheetFragment;
import com.weenggs.community.fragment.MyNewsPostFragment;
import com.weenggs.community.model.LoginResponce;
import com.weenggs.community.util.Constant;
import com.weenggs.community.util.callbackListener;
import com.weenggs.community.widget.DTextView;

import java.util.HashMap;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.view.Gravity.LEFT;

public class HomeActivity extends BaseActivity {

    ImageView btnOpenDrawer;
    RecyclerView navigarionrecyclerview;
    DrawerLayout drawerLayout;
    public DrawerAdapter drawerAdapter;
    TextView txtFragmentTitle;
    RoundedImageView img_userprofile;
    DTextView txtHeader;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_activity);

        navigarionrecyclerview = findViewById(R.id.navigarionrecyclerview);
        btnOpenDrawer = findViewById(R.id.btnOpenDrawer);
        drawerLayout = findViewById(R.id.drawerLayout);
        txtFragmentTitle = findViewById(R.id.txtFragmentTitle);
        img_userprofile = findViewById(R.id.img_userprofile);
        txtHeader = findViewById(R.id.txtHeader);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, null, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.setDrawerListener(toggle);

        btnOpenDrawer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openCloseDrawer();
            }
        });
        setMenuAdapter();

        drawerAdapter.setItemClickCallback(new callbackListener<Integer, String, String, String>() {
            @Override
            public void onClickCallBack(Integer position, String videoID, String tkn, String authentication) {

                switch (position) {
                    case 0:
                        replaceFragment(new MainFragment());
                        txtFragmentTitle.setText(R.string.home);
                        break;
                    case 1:
                        replaceFragment(new CommitteememberFragment());
                        txtFragmentTitle.setText(R.string.committee_members);
                        break;
                    case 2:
                        replaceFragment(new ListOfMemberFregment());
                        txtFragmentTitle.setText(R.string.family_detail);
                        break;
                    case 3:
                        replaceFragment(new MarkSheetFragment());
                        txtFragmentTitle.setText(R.string.upload_markSheet);
                        break;
                    case 4:
                        replaceFragment(new MyNewsPostFragment());
                        txtFragmentTitle.setText(R.string.my_post);
                        break;
                    case 5:
                        logoutDialog();
                        break;

                }
                openCloseDrawer();
            }
        });
        setDrawerHeader();
        loginUser();
    }

    public void setDrawerHeader() {
        if (data.getLogins().getProfileData().getProfile_image() != null || !data.getLogins().getProfileData().getProfile_image().equalsIgnoreCase("")) {
            Glide.with(getApplicationContext()).load(Constant.BASE_IMAGE_URL + data.getLogins().getProfileData().getProfile_image()).into(img_userprofile);
        }
        txtHeader.setText(data.getLogins().getProfileData().getFirst_name() + " " + data.getLogins().getProfileData().getSurname());
    }

    public void logoutDialog() {
        AlertDialog.Builder adb = new AlertDialog.Builder(HomeActivity.this);
        adb.setTitle(R.string.logout);
        adb.setMessage(R.string.logout_string);
        adb.setNegativeButton(R.string.no, null);
        adb.setPositiveButton(R.string.yes, new AlertDialog.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                Logout();
            }
        });
        adb.show();
    }

    public void Logout() {


        pref.clear();
        application.setUserLoginData(null);

        Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
        finish();
    }

    private void setMenuAdapter() {

        drawerAdapter = new DrawerAdapter(HomeActivity.this);
        navigarionrecyclerview.setLayoutManager(new LinearLayoutManager(this));
        navigarionrecyclerview.setAdapter(drawerAdapter);
        replaceFragment(new MainFragment());
        drawerAdapter.setItemClickCallback(new callbackListener<Integer, String, String, String>() {
            @Override
            public void onClickCallBack(Integer position, String videoID, String tkn, String authentication) {
                openCloseDrawer();
            }
        });


    }

    private void openCloseDrawer() {
        if (drawerLayout.isDrawerOpen(LEFT)) drawerLayout.closeDrawer(LEFT);
        else drawerLayout.openDrawer(LEFT);
    }

    public void replaceFragment(Fragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.framelayout, fragment)
                .commit();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Fragment fragment=getSupportFragmentManager().findFragmentById(R.id.framelayout);
        if(fragment!=null){
            fragment.onActivityResult(requestCode,resultCode,data);
        }
    }


    public void loginUser() {

        startprogressdialog(this);
        HashMap<String, String> dataParams = new HashMap<>();

        dataParams.put("phone_number", data.getLogins().getProfileData().getPhone_number());

        mAPIService.get_user_detail(dataParams).enqueue(new Callback<LoginResponce>() {
            @Override
            public void onResponse(Call<LoginResponce> call, Response<LoginResponce> response) {
                stopprogressdialog();
                if (response.isSuccessful()) {
                    // Toast.makeText(HomeActivity.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    if (response.body().getSuccess().equalsIgnoreCase("1")) {
                        application.setUserLoginData(response.body().getData());
                        setDrawerHeader();

                    }
                }
            }

            @Override
            public void onFailure(Call<LoginResponce> call, Throwable t) {
                stopprogressdialog();
                Constant.ErrorMessage(HomeActivity.this, t);
            }
        });
    }



}
