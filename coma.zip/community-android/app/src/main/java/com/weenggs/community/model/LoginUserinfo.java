package com.weenggs.community.model;

public class LoginUserinfo {

    private String is_active="";
    private String user_id="";
    private String registered_on="";
    private String phone_number="";
    LoginUserFamilyMemberInfo profileData;

    public LoginUserFamilyMemberInfo getProfileData() {
        return profileData;
    }

    public void setProfileData(LoginUserFamilyMemberInfo profileData) {
        this.profileData = profileData;
    }

    public String getIs_active() {
        return is_active;
    }

    public void setIs_active(String is_active) {
        this.is_active = is_active;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getRegistered_on() {
        return registered_on;
    }

    public void setRegistered_on(String registered_on) {
        this.registered_on = registered_on;
    }

    public String getPhone_number() {
        return phone_number;
    }

    public void setPhone_number(String phone_number) {
        this.phone_number = phone_number;
    }
}
