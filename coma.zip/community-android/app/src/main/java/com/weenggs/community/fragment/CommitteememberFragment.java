package com.weenggs.community.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.weenggs.community.R;
import com.weenggs.community.adepter.CommiteeMemberAdepter;
import com.weenggs.community.model.CommitteeMemberResponce;
import com.weenggs.community.model.LoginUserFamilyMemberInfo;
import com.weenggs.community.util.Constant;

import java.util.ArrayList;
import java.util.HashMap;

import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CommitteememberFragment extends BaseFragment {

    private RecyclerView recycleview;
    LinearLayoutManager mLayoutManager;
    ArrayList<LoginUserFamilyMemberInfo> memberDataArrayList;
    CommiteeMemberAdepter adapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.committee_member_fragment, container, false);

        findViews(view);
        getCommiteeMember();
        //if (Constant.committeeMemberDataArrayList == null) {
        //
        //} else {
        //    setPost();
        //}

        return view;
    }

    private void findViews(View view) {
        recycleview = (RecyclerView) view.findViewById(R.id.recycleview);
        recycleview.addItemDecoration(new DividerItemDecoration(recycleview.getContext(), DividerItemDecoration.VERTICAL));

        mLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        recycleview.setLayoutManager(mLayoutManager);


    }

    public void setMember() {
        memberDataArrayList = new ArrayList<>();
        memberDataArrayList.addAll(Constant.committeeMemberDataArrayList);
        adapter = new CommiteeMemberAdepter(CommitteememberFragment.this, memberDataArrayList);
        recycleview.setAdapter(adapter);

    }


    public void getCommiteeMember() {

        startprogressdialog(getActivity());
        HashMap<String, String> dataParams = new HashMap<>();
        dataParams.put("user_id", data.getMemberInfo().get(0).getUser_id());
        mAPIService.get_committee_member(dataParams).enqueue(new Callback<CommitteeMemberResponce>() {
            @Override
            public void onResponse(Call<CommitteeMemberResponce> call, Response<CommitteeMemberResponce> response) {
                stopprogressdialog();
                if (response.isSuccessful()) {
                    if (response.body().getSuccess().equalsIgnoreCase("1")) {
                        Constant.committeeMemberDataArrayList = response.body().getData();
                        setMember();
                    }
                }
            }

            @Override
            public void onFailure(Call<CommitteeMemberResponce> call, Throwable t) {
                stopprogressdialog();
                Constant.ErrorMessage(getActivity(), t);
            }
        });
    }


}
