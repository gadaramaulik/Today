package com.weenggs.community.retrofit;

import android.os.Build;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.weenggs.community.BuildConfig;
import com.weenggs.community.util.Constant;

import java.io.IOException;
import java.net.URLDecoder;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import okhttp3.HttpUrl;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitClient {


    public static int tryCount = 0;
    public static int maxLimit = 10;
    public static int waitThreshold = 3000;

    public static Retrofit getClient() {

        TimeZone tz = TimeZone.getDefault();
        String versionName = BuildConfig.VERSION_NAME;
        String timeZone = tz.getDisplayName(false, TimeZone.SHORT);
        String device_modeln = Build.MODEL;
        String manufauctuere = Build.MANUFACTURER;

        String releaseVersion = Build.VERSION.RELEASE;
        int sdkVersion = Build.VERSION.SDK_INT;

        String deviceInfo = "" + manufauctuere + "_" + device_modeln + "_" + sdkVersion + "(" + releaseVersion + ")";
        String timeZoneID = tz.getID();

        String v_Name = "";
        try {
            v_Name = URLDecoder.decode(versionName, "UTF-8");
        } catch (Exception e) {
            e.printStackTrace();
        }
        String DeviceInfo = "";
        try {
            DeviceInfo = URLDecoder.decode(deviceInfo, "UTF-8");
        } catch (Exception e) {
            e.printStackTrace();
        }

        String Tz = "";
        try {
            Tz = URLDecoder.decode(timeZone, "UTF-8");
        } catch (Exception e) {
            e.printStackTrace();
        }
        String TZid = "";
        try {
            TZid = URLDecoder.decode(timeZoneID, "UTF-8");
        } catch (Exception e) {
            e.printStackTrace();
        }


        final String finalV_Name = v_Name;
        final String finalTz = Tz;
        final String finalTZid = TZid;
        final String finalDInfo = DeviceInfo;

        Gson gson = new GsonBuilder().setLenient().create();
        OkHttpClient.Builder httpClient = new OkHttpClient.Builder();


        httpClient.addInterceptor(new Interceptor() {
            @Override
            public Response intercept(Chain chain) throws IOException {

                Request request = chain.request();
                HttpUrl url = request.url().newBuilder()
                        .addQueryParameter("version", finalV_Name)
                        .addQueryParameter("tz", finalTz)
                        .addQueryParameter("tzid", finalTZid)
                        .addQueryParameter("DeviceInfo", finalDInfo)

                        .addQueryParameter("from", "android").
                                build();

                request = request.newBuilder().url(url).build();
                Response response = chain.proceed(request);

                tryCount = 0;

                while (response == null && tryCount < maxLimit) {
                    Log.d("intercept", "Request failed - " + tryCount);
                    tryCount++;
                    try {
                        Thread.sleep(waitThreshold); // force wait the network thread for 5 seconds
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    response = sendReqeust(chain, request);
                }


                try {
                    String bodyString = response.body().string();
                    Log.d("TAG", "response" + bodyString);
                    return response.newBuilder()
                            .body(ResponseBody.create(response.body().contentType(), bodyString))
                            .build();

                } catch (Exception e) {
                    e.printStackTrace();
                }
                return response;

            }
        });

        httpClient.readTimeout(100, TimeUnit.SECONDS);
        httpClient.connectTimeout(Constant.CONNECTION_TIME_OUT, TimeUnit.MILLISECONDS);
        Retrofit.Builder builder = new Retrofit.Builder()
                .baseUrl(Constant.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create(gson));
        return builder.client(httpClient.build()).build();

    }


    public static Response sendReqeust(Interceptor.Chain chain, Request request) {
        try {
            Response response = chain.proceed(request);
            if (!response.isSuccessful())
                return null;
            else
                return response;
        } catch (Exception e) {
            return null;
        }
    }



}
